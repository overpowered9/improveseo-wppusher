<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly  

include_once IMPROVESEO_ROOT .'/modules/dashboard.php';
include_once IMPROVESEO_ROOT .'/modules/posting.php';
include_once IMPROVESEO_ROOT .'/modules/projects.php';
include_once IMPROVESEO_ROOT .'/modules/settings.php';
include_once IMPROVESEO_ROOT .'/modules/authors.php';
//include_once IMPROVESEO_ROOT .'/modules/shortcodes.php';
include_once IMPROVESEO_ROOT .'/modules/lists.php';

include_once IMPROVESEO_ROOT .'/modules/builder.php';
include_once IMPROVESEO_ROOT .'/modules/noindex.php';
include_once IMPROVESEO_ROOT .'/modules/ajax.php';