<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly  
/*
MySQL Data Transfer
Source Host: localhost
Source Database: fresnojazz2
Target Host: localhost
Target Database: fresnojazz2
Date: 9/18/2009 7:38:14 AM
*/
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Alaska', 'AK')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Alabama', 'AL')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Arkansas', 'AR')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Arizona', 'AZ')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('California', 'CA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Colorado', 'CO')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Connecticut', 'CT')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('District of Columbia', 'DC')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Delaware', 'DE')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Florida', 'FL')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Georgia', 'GA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Hawaii', 'HI')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Iowa', 'IA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Idaho', 'ID')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Illinois', 'IL')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Indiana', 'IN')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Kansas', 'KS')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Kentucky', 'KY')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Louisiana', 'LA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Massachusetts', 'MA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Maryland', 'MD')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Maine', 'ME')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Michigan', 'MI')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Minnesota', 'MN')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Missouri', 'MO')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Mississippi', 'MS')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Montana', 'MT')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('North Carolina', 'NC')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('North Dakota', 'ND')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Nebraska', 'NE')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('New Hampshire', 'NH')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('New Jersey', 'NJ')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('New Mexico', 'NM')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Nevada', 'NV')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('New York', 'NY')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Ohio', 'OH')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Oklahoma', 'OK')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Oregon', 'OR')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Pennsylvania', 'PA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Rhode Island', 'RI')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('South Carolina', 'SC')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('South Dakota', 'SD')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Tennessee', 'TN')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Texas', 'TX')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Utah', 'UT')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Virginia', 'VA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Vermont', 'VT')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Washington', 'WA')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Wisconsin', 'WI')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('West Virginia', 'WV')");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_us_states` VALUES ('Wyoming', 'WY')");
