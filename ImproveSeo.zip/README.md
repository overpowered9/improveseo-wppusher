*** INSTALLATION ***

1. Create directory "workhorse" in plugins dir.
2. Copy all files into "workhorse" directory.
3. Install plugin in WordPress plugins panel.
