<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly  


function improveseo_testimonials_settings(){
	$ob = new Improveseo_Testimonial;
	$ob->general_admin_notice();
    improveseo_wt_load_templates('cm-admin-settings.php');
}



add_action('admin_menu', 'improveseo_add_menu_items');
function improveseo_add_menu_items()
{
    //add_menu_page('Improve SEO', 'Improve SEO', 6, 'improveseo');
    add_menu_page('Improve SEO', 'Improve SEO', 'manage_options', 'improveseo_dashboard');
    
    add_submenu_page('improveseo_dashboard', 'Dashboard', 'Dashboard', 'manage_options', 'improveseo_dashboard', 'improveseo_dashboard');
    
    add_submenu_page('improveseo_dashboard', 'Posting', 'Posting', 'manage_options', 'improveseo_posting', 'improveseo_posting');

    add_submenu_page('improveseo_dashboard', 'Projects', 'Projects', 'manage_options', 'improveseo_projects', 'improveseo_projects');
    //add_submenu_page('improveseo', 'Shortcodes', 'Shortcodes', 'manage_options', 'improveseo_shortcodes', 'improveseo_shortcodes');
    add_submenu_page('improveseo_dashboard', 'Lists', 'Lists', 'manage_options', 'improveseo_lists', 'improveseo_lists');
    // add_submenu_page('improveseo_dashboard', 'Settings', 'Settings', 'manage_options', 'improveseo_settings', 'improveseo_settings');
    
    //add_submenu_page('improveseo', 'Builder', 'Builder', 'manage_options', 'improveseo_builder', 'improveseo_builder');
    //add_submenu_page('improveseo', 'BuilderUpdate', 'BuilderUpdate', 'manage_options', 'improveseo_update_builder', 'improveseo_update_builder');

    
    //add_submenu_page('improveseo', 'Noindex Tags', 'Noindex Tags', 'manage_options', 'improveseo_noindex', 'improveseo_noindex');
}
