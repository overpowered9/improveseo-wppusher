<?php
 if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly  
/*
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1, 1, 'Aberdeen', 'AB10', 57.13514, -2.11731);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2, 1, 'Aberdeen', 'AB11', 57.13875, -2.09089);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(3, 1, 'Aberdeen', 'AB12', 57.101, -2.1106);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(4, 1, 'Milltimber', 'AB13', 57.10801, -2.23776);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(5, 1, 'Peterculter', 'AB14', 57.10076, -2.27073);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(6, 1, 'Aberdeen', 'AB15', 57.13868, -2.16525);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(7, 1, 'Aberdeen', 'AB16', 57.16115, -2.15543);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(8, 1, 'Aberdeen Airport', 'AB21', 57.2096, -2.20033);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(9, 1, 'Bridge Of Don', 'AB22', 57.18724, -2.11913);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(10, 1, 'Aberdeen', 'AB23', 57.21242, -2.08776);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(11, 1, 'Aberdeen', 'AB25', 57.15311, -2.11241);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(12, 2, 'Laurencekirk', 'AB30', 56.84678, -2.47712);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(13, 2, 'Banchory', 'AB31', 57.07479, -2.52623);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(14, 2, 'Westhill', 'AB32', 57.15545, -2.31742);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(15, 2, 'Alford', 'AB33', 57.22464, -2.74203);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(16, 2, 'Aboyne', 'AB34', 57.09393, -2.81204);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(17, 2, 'Ballatar', 'AB35', 57.03829, -3.14869);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(18, 2, 'Strathdon', 'AB36', 57.19715, -3.06589);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(19, 3, 'Ballindalloch', 'AB37', 57.33098, -3.35051);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(20, 3, 'Aberlour', 'AB38', 57.48589, -3.2261);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(21, 2, 'Stonehaven', 'AB39', 56.97778, -2.21718);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(22, 2, 'Ellon', 'AB41', 57.37592, -2.10478);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(23, 2, 'Peterhead', 'AB42', 57.50079, -1.88819);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(24, 2, 'Fraserburgh', 'AB43', 57.65714, -2.04358);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(25, 2, 'Macduff', 'AB44', 57.66877, -2.49122);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(26, 2, 'Banff', 'AB45', 57.65139, -2.56639);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(27, 2, 'Inverurie', 'AB51', 57.28907, -2.40485);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(28, 2, 'Insch', 'AB52', 57.34396, -2.60651);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(29, 2, 'Turriff', 'AB53', 57.52537, -2.3941);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(30, 2, 'Huntly', 'AB54', 57.45361, -2.76333);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(31, 3, '', 'AB55', 57.5239, -2.99024);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(32, 3, '', 'AB56', 57.67442, -2.92559);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(33, 4, 'St Albans', 'AL1', 51.74836, -0.32237);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(34, 4, 'Hatfield', 'AL10', 51.75958, -0.2292);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(35, 4, 'St Albans', 'AL2', 51.72064, -0.33353);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(36, 4, 'Redbourn', 'AL3', 51.77781, -0.37057);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(37, 4, 'Sandridge', 'AL4', 51.77133, -0.29398);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(38, 4, 'Harpenden', 'AL5', 51.81622, -0.35177);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(39, 4, 'Welwyn', 'AL6', 51.83104, -0.19737);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(40, 4, 'Welwyn Garden City', 'AL7', 51.79669, -0.18569);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(41, 4, 'Welwyn Garden City', 'AL8', 51.80334, -0.20863);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(42, 4, 'Hatfield', 'AL9', 51.74472, -0.19791);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(43, 5, '', 'B1', 52.47872, -1.90723);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(44, 5, '', 'B10', 52.46967, -1.8513);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(45, 5, '', 'B11', 52.4544, -1.85871);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(46, 5, '', 'B12', 52.45982, -1.88225);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(47, 5, '', 'B13', 52.43644, -1.8779);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(48, 5, '', 'B14', 52.41757, -1.88824);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(49, 5, '', 'B15', 52.46615, -1.92345);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(50, 5, '', 'B16', 52.47604, -1.93374);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(51, 5, '', 'B17', 52.46077, -1.96026);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(52, 5, '', 'B18', 52.49132, -1.92341);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(53, 5, '', 'B19', 52.4967, -1.90425);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(54, 5, '', 'B2', 52.47871, -1.89692);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(55, 5, '', 'B20', 52.51379, -1.91747);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(56, 5, '', 'B21', 52.50661, -1.93959);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(57, 5, '', 'B23', 52.52812, -1.85405);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(58, 5, '', 'B24', 52.51909, -1.82755);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(59, 5, '', 'B25', 52.46513, -1.8204);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(60, 5, '', 'B26', 52.46059, -1.78951);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(61, 5, '', 'B27', 52.44446, -1.82196);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(62, 5, '', 'B28', 52.4265, -1.84115);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(63, 5, '', 'B29', 52.43739, -1.94704);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(64, 5, '', 'B3', 52.48051, -1.90134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(65, 5, '', 'B30', 52.42209, -1.92794);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(66, 5, '', 'B31', 52.40772, -1.97207);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(67, 5, '', 'B32', 52.44819, -1.99264);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(68, 5, '', 'B33', 52.48036, -1.78647);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(69, 5, '', 'B34', 52.49564, -1.78051);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(70, 5, '', 'B35', 52.51903, -1.78776);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(71, 6, 'Castle Bromwich', 'B36', 52.50373, -1.77899);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(72, 6, 'Chelmsley Wood', 'B37', 52.47847, -1.74083);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(73, 5, 'Tees Grove', 'B38', 52.39962, -1.93385);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(74, 5, '', 'B4', 52.48231, -1.89397);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(75, 6, 'Bickenhill', 'B40', 52.45865, -1.72181);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(76, 5, '', 'B42', 52.53357, -1.91154);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(77, 7, 'West Bromwich', 'B43', 52.54797, -1.92921);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(78, 5, '', 'B44', 52.54523, -1.88349);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(79, 5, '', 'B45', 52.38795, -2.00882);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(80, 8, 'Coleshill', 'B46', 52.50803, -1.69351);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(81, 9, 'Wythall', 'B47', 52.38699, -1.8795);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(82, 9, 'Alvechurch', 'B48', 52.35557, -1.9486);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(83, 8, 'Alcester', 'B49', 52.21704, -1.86679);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(84, 5, '', 'B5', 52.46972, -1.89547);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(85, 8, 'Bidford-on-Avon', 'B50', 52.16847, -1.85377);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(86, 5, '', 'B6', 52.50388, -1.88508);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(87, 9, 'Bromsgrove', 'B60', 52.3259, -2.04989);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(88, 9, 'Bromsgrove', 'B61', 52.34477, -2.06753);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(89, 10, 'Hurst Green', 'B62', 52.45628, -2.03238);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(90, 10, 'Hurst Green', 'B63', 52.45177, -2.06622);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(91, 7, 'West Bromwich', 'B64', 52.47244, -2.06773);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(92, 7, 'West Bromwich', 'B65', 52.48325, -2.04271);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(93, 7, 'West Bromwich', 'B66', 52.49314, -1.96465);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(94, 7, 'West Bromwich', 'B67', 52.48595, -1.97644);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(95, 7, 'West Bromwich', 'B68', 52.47876, -2);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(96, 7, 'West Bromwich', 'B69', 52.50213, -2.02799);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(97, 5, '', 'B7', 52.49307, -1.87185);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(98, 7, 'West Bromwich', 'B70', 52.52012, -2.00295);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(99, 7, 'West Bromwich', 'B71', 52.5354, -1.98968);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(100, 5, '', 'B72', 52.55145, -1.82153);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(101, 5, '', 'B73', 52.55238, -1.84217);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(102, 5, '', 'B74', 52.58297, -1.8583);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(103, 5, '', 'B75', 52.5784, -1.80813);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(104, 5, '', 'B76', 52.5451, -1.78616);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(105, 11, 'Tamworth', 'B77', 52.61855, -1.66762);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(106, 11, 'Tamworth', 'B78', 52.60598, -1.67362);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(107, 11, 'Wigginton', 'B79', 52.65005, -1.68069);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(108, 5, '', 'B8', 52.49034, -1.84092);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(109, 8, 'Studley', 'B80', 52.27641, -1.89593);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(110, 5, '', 'B9', 52.47776, -1.84833);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(111, 6, '', 'B90', 52.4004, -1.82361);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(112, 6, '', 'B91', 52.41382, -1.78238);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(113, 6, '', 'B92', 52.43628, -1.77345);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(114, 6, 'Dorridge', 'B93', 52.38048, -1.74288);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(115, 8, 'Tanworth-in-Arden', 'B94', 52.3509, -1.7915);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(116, 8, 'Henley-in-Arden', 'B95', 52.28524, -1.78008);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(117, 9, 'Redditch', 'B96', 52.25217, -1.96044);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(118, 9, 'Redditch', 'B97', 52.29893, -1.95454);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(119, 9, 'Redditch', 'B98', 52.3034, -1.91346);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(120, 12, 'Bath', 'BA1', 51.39109, -2.35934);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(121, 13, 'Bruton', 'BA10', 51.11291, -2.44576);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(122, 13, 'Frome', 'BA11', 51.23652, -2.32519);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(123, 14, 'Longbridge Deverill', 'BA12', 51.17117, -2.1874);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(124, 14, 'Westbury', 'BA13', 51.26201, -2.17917);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(125, 14, 'Trowbridge', 'BA14', 51.31863, -2.20092);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(126, 14, 'Bradford-on-Avon', 'BA15', 51.35088, -2.26425);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(127, 13, 'Street', 'BA16', 51.12489, -2.74313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(128, 12, 'Bath', 'BA2', 51.35957, -2.37633);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(129, 13, 'Yeovil', 'BA20', 50.93753, -2.64193);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(130, 13, 'Yeovil', 'BA21', 50.95107, -2.63358);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(131, 13, 'Mudford', 'BA22', 50.96814, -2.63666);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(132, 13, 'Kilmersdon', 'BA3', 51.27468, -2.47313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(133, 13, 'Shepton Mallet', 'BA4', 51.17102, -2.53073);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(134, 13, 'St Cuthbert Out', 'BA5', 51.21266, -2.65291);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(135, 13, 'Glastonbury', 'BA6', 51.14042, -2.70478);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(136, 13, 'Castle Cary', 'BA7', 51.08833, -2.51835);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(137, 13, 'Templecombe', 'BA8', 50.99883, -2.41046);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(138, 13, 'Wincanton', 'BA9', 51.05729, -2.40955);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(139, 15, 'Darwen', 'BB1', 53.75625, -2.46265);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(140, 16, 'Burnley', 'BB10', 53.79919, -2.21865);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(141, 16, 'Burnley', 'BB11', 53.78294, -2.25196);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(142, 16, 'Ightenhill', 'BB12', 53.80353, -2.29005);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(143, 16, 'Salterforth', 'BB18', 53.91433, -2.17053);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(144, 15, 'Darwen', 'BB2', 53.74171, -2.50039);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(145, 15, 'Darwen', 'BB3', 53.69781, -2.46503);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(146, 16, 'Rawtenstall', 'BB4', 53.70376, -2.28936);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(147, 16, 'Accrington', 'BB5', 53.75477, -2.37162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(148, 16, 'Accrington', 'BB6', 53.79238, -2.41598);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(149, 16, 'Clitheroe', 'BB7', 53.87338, -2.38636);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(150, 16, 'Newchurch', 'BB8', 53.85771, -2.1627);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(151, 16, 'Newchurch', 'BB9', 53.83695, -2.21429);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(152, 17, 'Queensbury', 'BD1', 53.79554, -1.75252);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(153, 17, 'Queensbury', 'BD10', 53.83143, -1.72496);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(154, 18, 'Dewsbury', 'BD11', 53.75131, -1.67543);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(155, 17, 'Queensbury', 'BD12', 53.74611, -1.76039);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(156, 17, 'Queensbury', 'BD13', 53.78582, -1.85883);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(157, 17, 'Queensbury', 'BD14', 53.78217, -1.81635);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(158, 17, 'Queensbury', 'BD15', 53.80917, -1.83597);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(159, 17, 'Bingley', 'BD16', 53.84871, -1.83278);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(160, 17, 'Queensbury', 'BD17', 53.84681, -1.76742);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(161, 17, 'Queensbury', 'BD18', 53.83154, -1.77662);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(162, 18, 'Dewsbury', 'BD19', 53.72713, -1.712);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(163, 17, 'Queensbury', 'BD2', 53.81438, -1.73418);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(164, 17, 'Steeton', 'BD20', 53.89646, -1.94673);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(165, 17, 'Keighley', 'BD21', 53.86407, -1.90571);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(166, 17, 'Keighley', 'BD22', 53.84522, -1.95288);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(167, 19, 'Thorlby', 'BD23', 53.99264, -2.05339);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(168, 19, 'Langcliffe', 'BD24', 54.07773, -2.27361);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(169, 17, 'Queensbury', 'BD3', 53.79818, -1.72669);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(170, 17, 'Queensbury', 'BD4', 53.77569, -1.71773);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(171, 17, 'Queensbury', 'BD5', 53.77847, -1.75717);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(172, 17, 'Queensbury', 'BD6', 53.76414, -1.78305);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(173, 17, 'Queensbury', 'BD7', 53.78301, -1.78143);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(174, 17, 'Queensbury', 'BD8', 53.80099, -1.78134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(175, 17, 'Queensbury', 'BD9', 53.81179, -1.78888);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(176, 20, '', 'BH1', 50.72427, -1.85973);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(177, 20, '', 'BH10', 50.75847, -1.89082);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(178, 20, '', 'BH11', 50.76119, -1.91634);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(179, 21, '', 'BH12', 50.73692, -1.9263);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(180, 21, '', 'BH13', 50.70993, -1.91785);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(181, 21, '', 'BH14', 50.72164, -1.94333);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(182, 21, '', 'BH15', 50.72165, -1.98442);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(183, 22, 'Upton', 'BH16', 50.73783, -2.04394);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(184, 21, '', 'BH17', 50.74593, -1.97449);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(185, 21, '', 'BH18', 50.75853, -1.99291);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(186, 22, 'Swanage', 'BH19', 50.61102, -1.9689);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(187, 20, '', 'BH2', 50.72159, -1.88099);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(188, 22, 'Wareham', 'BH20', 50.68648, -2.14582);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(189, 22, 'Colehill', 'BH21', 50.81248, -1.97303);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(190, 22, 'Ferndown', 'BH22', 50.80524, -1.88787);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(191, 22, 'Burton', 'BH23', 50.74567, -1.75335);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(192, 23, 'Ringwood', 'BH24', 50.84377, -1.78551);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(193, 23, 'New Milton', 'BH25', 50.75173, -1.65692);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(194, 20, '', 'BH3', 50.73508, -1.87954);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(195, 22, 'Verwood', 'BH31', 50.87537, -1.87207);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(196, 20, '', 'BH4', 50.72071, -1.89799);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(197, 20, '', 'BH5', 50.72513, -1.83422);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(198, 20, '', 'BH6', 50.72688, -1.80446);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(199, 20, '', 'BH7', 50.73502, -1.83135);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(200, 20, '', 'BH8', 50.74044, -1.85118);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(201, 20, '', 'BH9', 50.74946, -1.871);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(202, 24, 'Ramsbottom', 'BL0', 53.64526, -2.31468);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(203, 25, '', 'BL1', 53.59002, -2.44421);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(204, 25, '', 'BL2', 53.58749, -2.39432);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(205, 25, '', 'BL3', 53.56489, -2.43186);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(206, 25, '', 'BL4', 53.54702, -2.39999);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(207, 25, 'Westhoughton', 'BL5', 53.54928, -2.51473);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(208, 25, 'Horwich', 'BL6', 53.59142, -2.53941);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(209, 25, '', 'BL7', 53.62965, -2.42194);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(210, 24, '', 'BL8', 53.60478, -2.32647);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(211, 24, '', 'BL9', 53.5914, -2.28557);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(212, 26, 'Brighton', 'BN1', 50.839, -0.13786);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(213, 27, 'Peacehaven', 'BN10', 50.7953, 0.00232);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(214, 28, 'Worthing', 'BN11', 50.81288, -0.37599);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(215, 28, 'Worthing', 'BN12', 50.81354, -0.42423);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(216, 28, 'Worthing', 'BN13', 50.83037, -0.40521);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(217, 28, 'Worthing', 'BN14', 50.83181, -0.37959);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(218, 28, 'Lancing', 'BN15', 50.83013, -0.32426);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(219, 28, 'Rustington', 'BN16', 50.81446, -0.49377);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(220, 28, 'Littlehampton', 'BN17', 50.81408, -0.53495);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(221, 28, 'Arundel', 'BN18', 50.84881, -0.57933);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(222, 26, 'Brighton', 'BN2', 50.82405, -0.10296);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(223, 27, 'Eastbourne', 'BN20', 50.77449, 0.25536);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(224, 27, 'Eastbourne', 'BN21', 50.77228, 0.27653);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(225, 27, '', 'BN22', 50.78832, 0.2844);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(226, 27, 'Eastbourne', 'BN23', 50.79764, 0.31325);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(227, 27, 'Westham', 'BN24', 50.81618, 0.3312);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(228, 27, 'Seaford', 'BN25', 50.77633, 0.10932);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(229, 27, 'Long Man', 'BN26', 50.82098, 0.22352);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(230, 27, 'Hailsham', 'BN27', 50.87146, 0.2643);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(231, 26, 'Brighton', 'BN3', 50.83419, -0.17498);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(232, 26, 'Brighton', 'BN41', 50.8402, -0.21452);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(233, 28, 'Shoreham-by-Sea', 'BN42', 50.83686, -0.23169);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(234, 28, 'Shoreham-by-Sea', 'BN43', 50.83557, -0.26583);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(235, 28, 'Steyning', 'BN44', 50.89036, -0.3221);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(236, 28, 'Newtimber', 'BN45', 50.8892, -0.18421);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(237, 28, 'Henfield', 'BN5', 50.92645, -0.26815);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(238, 28, 'Clayton', 'BN6', 50.92918, -0.15276);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(239, 27, 'Lewes', 'BN7', 50.87719, 0.00014);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(240, 27, 'Ringmer', 'BN8', 50.91318, 0.05148);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(241, 27, 'Newhaven', 'BN9', 50.79536, 0.05058);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(242, 29, 'Bromley', 'BR1', 51.41107, 0.02192);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(243, 29, 'Bromley', 'BR2', 51.38858, 0.02237);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(244, 29, 'Bromley', 'BR3', 51.40297, -0.0302);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(245, 29, 'Bromley', 'BR4', 51.37559, -0.00695);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(246, 29, 'Bromley', 'BR5', 51.38983, 0.10436);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(247, 29, 'Bromley', 'BR6', 51.36575, 0.0932);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(248, 29, 'Bromley', 'BR7', 51.41019, 0.07222);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(249, 30, 'Swanley', 'BR8', 51.39751, 0.1766);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(250, 31, 'Bristol', 'BS1', 51.45309, -2.593);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(251, 31, 'Bristol', 'BS10', 51.50606, -2.60954);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(252, 31, 'Bristol', 'BS11', 51.49672, -2.67425);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(253, 31, 'Bristol', 'BS13', 51.41163, -2.61116);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(254, 31, 'Bristol', 'BS14', 51.41278, -2.56084);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(255, 32, 'Kingswood', 'BS15', 51.4589, -2.50527);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(256, 32, 'Kingswood', 'BS16', 51.48496, -2.50988);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(257, 31, 'Bristol', 'BS2', 51.45945, -2.58013);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(258, 33, 'Portbury', 'BS20', 51.47916, -2.75176);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(259, 33, 'Clevedon', 'BS21', 51.43443, -2.84886);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(260, 33, 'Weston-Super-Mare', 'BS22', 51.36008, -2.92936);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(261, 33, 'Weston-Super-Mare', 'BS23', 51.34266, -2.97065);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(262, 33, 'Hutton', 'BS24', 51.32769, -2.93158);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(263, 33, 'Winscombe', 'BS25', 51.32039, -2.82522);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(264, 13, 'Weare', 'BS26', 51.27971, -2.85461);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(265, 13, 'Cheddar', 'BS27', 51.27131, -2.76987);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(266, 13, 'Wedmore', 'BS28', 51.22515, -2.81349);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(267, 33, 'Banwell', 'BS29', 51.33081, -2.87709);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(268, 31, 'Bristol', 'BS3', 51.43776, -2.60144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(269, 32, 'Bitton', 'BS30', 51.44465, -2.47201);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(270, 12, 'Keynsham', 'BS31', 51.4077, -2.49176);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(271, 32, 'Bradley Stoke', 'BS32', 51.54228, -2.55955);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(272, 32, 'Stoke Gifford', 'BS34', 51.52338, -2.56364);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(273, 32, 'Aust', 'BS35', 51.59629, -2.54866);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(274, 32, 'Frampton Cotterell', 'BS36', 51.52553, -2.48582);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(275, 32, 'Yate', 'BS37', 51.53928, -2.41675);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(276, 12, 'Clutton', 'BS39', 51.32749, -2.53109);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(277, 31, 'Bristol', 'BS4', 51.43437, -2.56111);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(278, 12, 'Nempnett Thrubwell', 'BS40', 51.34644, -2.69071);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(279, 33, 'Long Ashton', 'BS41', 51.42221, -2.65158);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(280, 33, 'Nailsea', 'BS48', 51.42523, -2.748);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(281, 33, 'Yatton', 'BS49', 51.3798, -2.81767);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(282, 31, 'Bristol', 'BS5', 51.4614, -2.54992);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(283, 31, 'Bristol', 'BS6', 51.47015, -2.59898);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(284, 31, 'Bristol', 'BS7', 51.48643, -2.58047);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(285, 31, 'Bristol', 'BS8', 51.45745, -2.62041);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(286, 31, 'Bristol', 'BS9', 51.4871, -2.62513);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(287, 31, 'Bristol', 'BS99', 51.45769, -2.57291);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(288, 34, '', 'BT1', 54.59941, -5.92838);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(289, 34, '', 'BT10', 54.55983, -5.98338);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(290, 34, '', 'BT11', 54.57556, -5.9973);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(291, 34, '', 'BT12', 54.59223, -5.95557);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(292, 34, '', 'BT13', 54.60563, -5.95842);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(293, 34, '', 'BT14', 54.62082, -5.96144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(294, 34, '', 'BT15', 54.62362, -5.93071);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(295, 35, 'Dundonald', 'BT16', 54.591, -5.79746);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(296, 36, 'Dunmurry', 'BT17', 54.55423, -6.01688);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(297, 37, 'Holywood', 'BT18', 54.64154, -5.82079);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(298, 37, 'Bangor', 'BT19', 54.6517, -5.66663);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(299, 34, '', 'BT2', 54.59309, -5.92932);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(300, 37, 'Bangor', 'BT20', 54.65808, -5.6641);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(301, 38, 'Donaghadee', 'BT21', 54.63826, -5.54448);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(302, 38, '', 'BT22', 54.5032, -5.51886);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(303, 38, '', 'BT23', 54.56301, -5.71437);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(304, 39, '', 'BT24', 54.41683, -5.87232);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(305, 40, '', 'BT25', 54.39545, -6.11078);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(306, 36, '', 'BT26', 54.45201, -6.06088);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(307, 36, '', 'BT27', 54.51004, -6.02027);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(308, 36, '', 'BT28', 54.52305, -6.08804);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(309, 41, '', 'BT29', 54.62018, -6.1939);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(310, 34, '', 'BT3', 54.61999, -5.90401);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(311, 39, 'Downpatrick', 'BT30', 54.33396, -5.70444);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(312, 40, '', 'BT31', 54.27783, -5.96992);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(313, 40, '', 'BT32', 54.33502, -6.24483);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(314, 39, 'Newcastle', 'BT33', 54.22095, -5.89385);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(315, 42, '', 'BT34', 54.15466, -6.18034);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(316, 42, '', 'BT35', 54.16501, -6.44355);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(317, 43, '', 'BT36', 54.67682, -5.95448);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(318, 43, 'Whiteabbey', 'BT37', 54.67658, -5.90634);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(319, 44, '', 'BT38', 54.7295, -5.79799);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(320, 43, '', 'BT39', 54.74491, -6.0171);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(321, 34, '', 'BT4', 54.6023, -5.86668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(322, 45, '', 'BT40', 54.84659, -5.82146);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(323, 41, 'Mill Town', 'BT41', 54.73301, -6.25997);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(324, 46, '', 'BT42', 54.85458, -6.28215);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(325, 46, '', 'BT43', 54.89024, -6.26565);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(326, 46, '', 'BT44', 54.97416, -6.28394);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(327, 47, '', 'BT45', 54.76045, -6.63935);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(328, 47, '', 'BT46', 54.86568, -6.66393);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(329, 48, '', 'BT47', 54.97386, -7.21151);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(330, 48, 'Londonderry', 'BT48', 55.00933, -7.32731);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(331, 49, '', 'BT49', 55.04774, -6.95153);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(332, 34, '', 'BT5', 54.5887, -5.87004);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(333, 50, '', 'BT51', 55.05761, -6.68);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(334, 50, '', 'BT52', 55.13423, -6.65285);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(335, 51, '', 'BT53', 55.08519, -6.47305);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(336, 52, 'Ballycastle', 'BT54', 55.19997, -6.25787);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(337, 50, 'Portstewart', 'BT55', 55.17971, -6.71005);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(338, 50, 'Portrush', 'BT56', 55.19824, -6.64932);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(339, 52, 'Bushmills', 'BT57', 55.2014, -6.51755);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(340, 34, '', 'BT6', 54.57974, -5.89706);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(341, 53, '', 'BT60', 54.29219, -6.64951);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(342, 53, '', 'BT61', 54.3679, -6.62264);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(343, 54, 'Portadown', 'BT62', 54.41256, -6.46416);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(344, 54, '', 'BT63', 54.40362, -6.38916);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(345, 54, '', 'BT64', 54.44938, -6.39252);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(346, 54, '', 'BT65', 54.44496, -6.36581);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(347, 54, 'Lurgan', 'BT66', 54.45514, -6.33292);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(348, 54, '', 'BT67', 54.48713, -6.26832);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(349, 55, '', 'BT68', 54.36626, -6.84743);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(350, 55, '', 'BT69', 54.42425, -6.94843);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(351, 34, '', 'BT7', 54.58158, -5.92356);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(352, 55, '', 'BT70', 54.51495, -6.88672);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(353, 55, '', 'BT71', 54.51322, -6.70402);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(354, 56, '', 'BT74', 54.3432, -7.66425);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(355, 55, 'Fivemiletown', 'BT75', 54.37531, -7.31559);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(356, 55, '', 'BT76', 54.41941, -7.19167);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(357, 55, '', 'BT77', 54.42711, -7.11701);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(358, 57, '', 'BT78', 54.57165, -7.37371);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(359, 57, '', 'BT79', 54.62422, -7.20073);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(360, 35, 'Carryduff', 'BT8', 54.53994, -5.90409);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(361, 58, '', 'BT80', 54.64464, -6.74869);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(362, 59, '', 'BT81', 54.69395, -7.61369);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(363, 59, '', 'BT82', 54.82576, -7.42777);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(364, 34, '', 'BT9', 54.57176, -5.94894);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(365, 56, '', 'BT92', 54.22294, -7.46184);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(366, 56, '', 'BT93', 54.4651, -7.8264);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(367, 56, '', 'BT94', 54.37595, -7.54078);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(368, 60, 'Carlisle', 'CA1', 54.88535, -2.91046);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(369, 60, 'Cliburn', 'CA10', 54.61104, -2.65966);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(370, 60, 'Catterlen', 'CA11', 54.66422, -2.78611);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(371, 60, 'Keswick', 'CA12', 54.60214, -3.13326);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(372, 60, 'Cockermouth', 'CA13', 54.65997, -3.36589);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(373, 60, 'Workington', 'CA14', 54.63454, -3.53704);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(374, 60, 'Maryport', 'CA15', 54.71165, -3.48096);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(375, 60, 'Appleby-in-Westmorland', 'CA16', 54.57413, -2.48269);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(376, 60, 'Kirkby Stephen', 'CA17', 54.47841, -2.35037);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(377, 60, 'Muncaster', 'CA18', 54.35408, -3.38958);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(378, 60, 'Muncaster', 'CA19', 54.38651, -3.38297);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(379, 60, 'Carlisle', 'CA2', 54.88415, -2.9494);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(380, 60, 'Gosforth', 'CA20', 54.40987, -3.46081);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(381, 60, 'Beckermet', 'CA21', 54.44516, -3.51451);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(382, 60, 'Egremont', 'CA22', 54.48001, -3.53123);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(383, 60, 'Cleator Moor', 'CA23', 54.51465, -3.49236);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(384, 60, 'Egremont', 'CA24', 54.51493, -3.54181);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(385, 60, 'Cleator Moor', 'CA25', 54.52243, -3.51737);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(386, 60, 'Arlecdon', 'CA26', 54.54445, -3.48108);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(387, 60, 'St Bees', 'CA27', 54.49091, -3.59186);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(388, 60, 'Whitehaven', 'CA28', 54.54324, -3.57689);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(389, 60, 'Carlisle', 'CA3', 54.9076, -2.93904);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(390, 60, 'Wetheral', 'CA4', 54.84636, -2.83326);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(391, 60, 'Orton', 'CA5', 54.85485, -3.0157);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(392, 60, 'Kirklinton', 'CA6', 54.99423, -2.8926);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(393, 60, 'Waverton', 'CA7', 54.80696, -3.23702);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(394, 60, 'Brampton', 'CA8', 54.93895, -2.68531);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(395, 60, 'Alston', 'CA9', 54.80176, -2.4185);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(396, 61, 'Fulbourn', 'CB1', 52.17611, 0.18955);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(397, 62, 'Saffron Walden', 'CB10', 52.02989, 0.26551);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(398, 62, 'Newport', 'CB11', 51.99938, 0.21443);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(399, 61, 'Great Shelford', 'CB2', 52.16276, 0.13333);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(400, 61, 'Balsham', 'CB21', 52.13194, 0.29553);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(401, 61, 'Little Shelford', 'CB22', 52.12718, 0.12898);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(402, 61, 'Highfields', 'CB23', 52.21349, -0.02215);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(403, 61, 'Over', 'CB24', 52.31538, 0.02762);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(404, 61, 'Lode', 'CB25', 52.26083, 0.23615);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(405, 61, 'Hardwick', 'CB3', 52.21324, 0.02448);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(406, 61, 'Impington', 'CB4', 52.24312, 0.11521);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(407, 61, 'Stow cum Quy', 'CB5', 52.23868, 0.21021);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(408, 61, 'Downham', 'CB6', 52.40388, 0.22434);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(409, 61, 'Soham', 'CB7', 52.36606, 0.32087);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(410, 61, 'Woodditton', 'CB8', 52.23083, 0.42659);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(411, 63, 'Haverhill', 'CB9', 52.08212, 0.44187);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(412, 64, 'Butetown', 'CF10', 51.47387, -3.17648);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(413, 64, 'Grangetown', 'CF11', 51.47281, -3.19229);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(414, 64, 'Rhiwbina', 'CF14', 51.51947, -3.20216);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(415, 64, 'Pentyrch', 'CF15', 51.53401, -3.27319);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(416, 64, 'Pentwyn', 'CF23', 51.5155, -3.15016);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(417, 64, 'Adamsdown', 'CF24', 51.48479, -3.16379);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(418, 64, 'Trowbridge', 'CF3', 51.51947, -3.11134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(419, 65, '', 'CF31', 51.50876, -3.57514);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(420, 65, 'Garw Valley', 'CF32', 51.55992, -3.58268);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(421, 65, 'Cynffig', 'CF33', 51.52424, -3.69101);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(422, 65, 'Maesteg', 'CF34', 51.61024, -3.65087);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(423, 65, 'Pencoed', 'CF35', 51.52211, -3.51793);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(424, 65, 'Porthcawl', 'CF36', 51.48456, -3.69818);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(425, 66, 'Pontypridd', 'CF37', 51.6026, -3.33288);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(426, 66, 'Llantwit Fardre', 'CF38', 51.56034, -3.33164);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(427, 66, 'Cymmer', 'CF39', 51.60153, -3.42382);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(428, 66, 'Tonypandy', 'CF40', 51.62009, -3.45041);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(429, 66, 'Ystrad', 'CF41', 51.64758, -3.48164);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(430, 66, 'Treorchy', 'CF42', 51.66685, -3.52132);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(431, 66, 'Ferndale', 'CF43', 51.65788, -3.44872);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(432, 66, 'Aberdare', 'CF44', 51.71802, -3.45788);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(433, 66, 'Penrhiwceiber', 'CF45', 51.66882, -3.36085);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(434, 67, 'Treharris', 'CF46', 51.66501, -3.3);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(435, 67, 'Town', 'CF47', 51.75139, -3.37492);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(436, 67, 'Town', 'CF48', 51.74067, -3.3688);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(437, 64, 'Ely', 'CF5', 51.48219, -3.2415);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(438, 68, 'Llantwit Major', 'CF61', 51.40748, -3.47962);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(439, 68, 'Barry', 'CF62', 51.40412, -3.30841);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(440, 68, 'Barry', 'CF63', 51.4119, -3.25542);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(441, 68, 'Penarth', 'CF64', 51.43328, -3.18838);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(442, 68, 'Cowbridge', 'CF71', 51.46176, -3.45402);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(443, 66, 'Llanharan', 'CF72', 51.52989, -3.39852);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(444, 69, 'Bargoed', 'CF81', 51.6998, -3.24311);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(445, 69, 'Gelligaer', 'CF82', 51.65132, -3.236);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(446, 69, '', 'CF83', 51.58587, -3.2169);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(447, 70, 'Chester', 'CH1', 53.20173, -2.90732);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(448, 70, 'Upton', 'CH2', 53.2164, -2.86869);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(449, 70, 'Waverton', 'CH3', 53.1664, -2.8213);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(450, 71, 'Saltney', 'CH4', 53.16823, -2.93803);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(451, 72, 'Birkenhead', 'CH41', 53.39402, -3.03022);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(452, 72, 'Birkenhead', 'CH42', 53.37433, -3.02073);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(453, 72, 'Birkenhead', 'CH43', 53.38299, -3.05853);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(454, 72, 'Wallasey', 'CH44', 53.41554, -3.03676);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(455, 72, 'Wallasey', 'CH45', 53.42801, -3.05061);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(456, 72, 'Birkenhead', 'CH46', 53.40319, -3.11018);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(457, 72, 'Hoylake', 'CH47', 53.39634, -3.16866);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(458, 72, 'Hoylake', 'CH48', 53.37116, -3.16947);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(459, 72, 'Birkenhead', 'CH49', 53.38079, -3.10208);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(460, 71, 'Shotton', 'CH5', 53.20424, -3.04064);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(461, 71, 'Flint', 'CH6', 53.25003, -3.14518);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(462, 72, 'Heswall', 'CH60', 53.32602, -3.09466);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(463, 72, 'Heswall', 'CH61', 53.34754, -3.10122);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(464, 72, 'Birkenhead', 'CH62', 53.33421, -2.98072);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(465, 72, 'Birkenhead', 'CH63', 53.34474, -3.01101);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(466, 70, 'Ellesmere Port', 'CH64', 53.28779, -3.04717);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(467, 70, 'Ellesmere Port', 'CH65', 53.27729, -2.90142);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(468, 70, 'Ellesmere Port', 'CH66', 53.27704, -2.93442);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(469, 71, 'Mold', 'CH7', 53.16924, -3.13256);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(470, 71, 'Holywell', 'CH8', 53.28144, -3.24053);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(471, 62, 'Southminster', 'CM0', 51.66221, 0.83719);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(472, 62, 'Chelmsford', 'CM1', 51.74454, 0.45694);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(473, 62, '', 'CM11', 51.62335, 0.44605);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(474, 62, 'Billericay', 'CM12', 51.62757, 0.41593);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(475, 62, 'Brentwood', 'CM13', 51.61564, 0.33872);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(476, 62, 'Brentwood', 'CM14', 51.61835, 0.29263);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(477, 62, 'Brentwood', 'CM15', 51.64328, 0.30545);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(478, 62, 'Epping', 'CM16', 51.69981, 0.12161);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(479, 62, 'Harlow', 'CM17', 51.77043, 0.14522);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(480, 62, 'Harlow', 'CM18', 51.75584, 0.10685);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(481, 62, 'Harlow', 'CM19', 51.76, 0.07515);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(482, 62, 'Great Baddow', 'CM2', 51.72141, 0.48754);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(483, 62, 'Harlow', 'CM20', 51.77476, 0.10483);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(484, 4, 'Sawbridgeworth', 'CM21', 51.81177, 0.14718);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(485, 62, 'Great Hallingbury', 'CM22', 51.86164, 0.22218);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(486, 4, 'Bishops Stortford', 'CM23', 51.87178, 0.16021);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(487, 62, 'Stansted Mountfitchet', 'CM24', 51.8988, 0.20657);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(488, 62, 'Danbury', 'CM3', 51.71932, 0.58445);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(489, 62, 'Ingatestone', 'CM4', 51.67392, 0.39235);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(490, 62, 'Ongar', 'CM5', 51.72083, 0.24857);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(491, 62, 'Great Dunmow', 'CM6', 51.8768, 0.36678);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(492, 62, 'Braintree', 'CM7', 51.89752, 0.53797);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(493, 62, 'Witham', 'CM8', 51.80536, 0.6387);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(494, 62, 'Heybridge', 'CM9', 51.74097, 0.70159);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(495, 62, 'Colchester', 'CO1', 51.88891, 0.9096);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(496, 63, 'Sudbury', 'CO10', 52.05706, 0.72355);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(497, 62, 'Mistley', 'CO11', 51.94126, 1.0789);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(498, 62, 'Harwich', 'CO12', 51.93115, 1.25427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(499, 62, 'Frinton and Walton', 'CO13', 51.83802, 1.23884);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(500, 62, 'Frinton and Walton', 'CO14', 51.84979, 1.26873);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(501, 62, 'Clacton-on-Sea', 'CO15', 51.7962, 1.15605);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(502, 62, 'Little Clacton', 'CO16', 51.82039, 1.1258);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(503, 62, 'Colchester', 'CO2', 51.86947, 0.89527);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(504, 62, 'Colchester', 'CO3', 51.88466, 0.86281);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(505, 62, 'Colchester', 'CO4', 51.90654, 0.92383);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(506, 62, 'Layer Breton', 'CO5', 51.81459, 0.82209);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(507, 62, 'Fordham', 'CO6', 51.92419, 0.78968);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(508, 62, 'Elmstead', 'CO7', 51.8838, 1.0052);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(509, 62, 'Bures Hamlet', 'CO8', 51.97328, 0.76797);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(510, 62, 'Sible Hedingham', 'CO9', 51.96878, 0.61043);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(511, 29, 'Croydon', 'CR0', 51.37223, -0.07463);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(512, 29, 'Croydon', 'CR2', 51.34983, -0.07988);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(513, 73, 'Whyteleafe', 'CR3', 51.28687, -0.07964);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(514, 29, 'Merton', 'CR4', 51.40415, -0.15813);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(515, 29, 'Croydon', 'CR5', 51.31211, -0.13886);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(516, 73, 'Whyteleafe', 'CR6', 51.30799, -0.05149);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(517, 29, 'Croydon', 'CR7', 51.39517, -0.10242);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(518, 29, 'Croydon', 'CR8', 51.33594, -0.11061);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(519, 30, 'Canterbury', 'CT1', 51.27719, 1.08733);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(520, 30, 'Broadstairs', 'CT10', 51.36208, 1.43073);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(521, 30, 'Margate', 'CT11', 51.33557, 1.41438);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(522, 30, 'Manston', 'CT12', 51.34216, 1.37322);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(523, 30, 'Sandwich', 'CT13', 51.26692, 1.33042);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(524, 30, 'Dover', 'CT14', 51.21582, 1.38689);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(525, 30, 'Whitfield', 'CT15', 51.17109, 1.28343);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(526, 30, 'Dover', 'CT16', 51.13996, 1.30267);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(527, 30, 'Dover', 'CT17', 51.12845, 1.29613);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(528, 30, 'Hawkinge', 'CT18', 51.11447, 1.15078);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(529, 30, 'Folkestone', 'CT19', 51.08785, 1.1704);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(530, 30, 'Canterbury', 'CT2', 51.29261, 1.08262);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(531, 30, 'Folkestone', 'CT20', 51.07899, 1.16551);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(532, 30, 'Hythe', 'CT21', 51.07233, 1.07795);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(533, 30, 'Wingham', 'CT3', 51.27743, 1.21213);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(534, 30, 'Lower Hardres', 'CT4', 51.22462, 1.06805);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(535, 30, 'Canterbury', 'CT5', 51.35318, 1.03641);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(536, 30, 'Canterbury', 'CT6', 51.3642, 1.13054);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(537, 30, 'Birchington', 'CT7', 51.37122, 1.30062);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(538, 30, 'Margate', 'CT8', 51.37996, 1.3415);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(539, 30, 'Margate', 'CT9', 51.38304, 1.3906);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(540, 74, '', 'CV1', 52.40939, -1.506);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(541, 8, 'Nuneaton', 'CV10', 52.52535, -1.50028);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(542, 8, 'Nuneaton', 'CV11', 52.51885, -1.45318);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(543, 8, 'Bedworth', 'CV12', 52.47399, -1.47288);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(544, 75, 'Market Bosworth', 'CV13', 52.61217, -1.41362);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(545, 74, '', 'CV2', 52.4227, -1.46467);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(546, 8, 'Rugby', 'CV21', 52.36774, -1.27438);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(547, 8, 'Rugby', 'CV22', 52.35522, -1.28633);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(548, 8, 'Dunchurch', 'CV23', 52.36165, -1.30826);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(549, 74, '', 'CV3', 52.3931, -1.48119);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(550, 8, 'Leamington Spa', 'CV31', 52.27819, -1.52358);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(551, 8, 'Leamington Spa', 'CV32', 52.2962, -1.53072);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(552, 8, 'Radford Semele', 'CV33', 52.25735, -1.48424);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(553, 8, 'Warwick', 'CV34', 52.2829, -1.57924);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(554, 8, 'Wasperton', 'CV35', 52.229, -1.5944);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(555, 8, 'Shipston-on-Stour', 'CV36', 52.06726, -1.62504);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(556, 8, 'Stratford-Upon-Avon', 'CV37', 52.1853, -1.71328);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(557, 74, '', 'CV4', 52.39794, -1.56492);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(558, 8, 'Ladbroke', 'CV47', 52.23349, -1.38494);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(559, 74, '', 'CV5', 52.41227, -1.55008);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(560, 74, '', 'CV6', 52.43188, -1.50722);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(561, 74, 'Hawkes End', 'CV7', 52.44378, -1.563);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(562, 8, 'Kenilworth', 'CV8', 52.3511, -1.54336);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(563, 8, 'Atherstone', 'CV9', 52.58493, -1.55864);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(564, 76, 'Crewe', 'CW1', 53.10281, -2.43469);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(565, 76, 'Middlewich', 'CW10', 53.18907, -2.44604);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(566, 76, 'Sandbach', 'CW11', 53.1426, -2.36482);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(567, 76, 'Congleton', 'CW12', 53.16455, -2.21093);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(568, 76, 'Crewe', 'CW2', 53.08119, -2.44642);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(569, 76, 'Bridgemere', 'CW3', 52.99952, -2.40534);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(570, 76, 'Holmes Chapel', 'CW4', 53.20648, -2.34739);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(571, 76, 'Nantwich', 'CW5', 53.062, -2.52084);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(572, 70, 'Tarporley', 'CW6', 53.16197, -2.66565);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(573, 70, 'Winsford', 'CW7', 53.19054, -2.52688);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(574, 70, 'Weaverham', 'CW8', 53.2533, -2.56363);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(575, 70, 'Northwich', 'CW9', 53.25897, -2.50074);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(576, 30, 'Dartford', 'DA1', 51.44637, 0.20915);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(577, 30, 'Swanscombe', 'DA10', 51.44445, 0.30837);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(578, 30, 'Gravesend', 'DA11', 51.43455, 0.35392);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(579, 30, 'Gravesend', 'DA12', 51.42757, 0.38809);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(580, 30, 'Meopham Station', 'DA13', 51.38235, 0.35555);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(581, 29, 'Bexley', 'DA14', 51.42475, 0.11316);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(582, 29, 'Bexley', 'DA15', 51.44029, 0.09948);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(583, 29, 'Bexley', 'DA16', 51.4644, 0.10923);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(584, 29, 'Crayford', 'DA17', 51.48706, 0.14917);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(585, 29, 'Crayford', 'DA18', 51.49165, 0.14363);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(586, 30, 'Darenth', 'DA2', 51.4315, 0.23433);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(587, 30, 'Hartley', 'DA3', 51.38417, 0.30965);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(588, 30, 'Horton Kirby', 'DA4', 51.39106, 0.23236);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(589, 29, 'Bexley', 'DA5', 51.44033, 0.14698);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(590, 29, 'Bexley', 'DA6', 51.45484, 0.14046);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(591, 29, 'Crayford', 'DA7', 51.46552, 0.14672);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(592, 29, 'Crayford', 'DA8', 51.47574, 0.17745);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(593, 30, 'Stone', 'DA9', 51.44771, 0.27975);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(594, 77, 'Dundee', 'DD1', 56.4611, -2.97702);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(595, 2, '', 'DD10', 56.74724, -2.4268);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(596, 78, 'Kirkton', 'DD11', 56.57312, -2.59738);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(597, 77, 'Dundee', 'DD2', 56.46968, -3.02756);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(598, 77, 'Dundee', 'DD3', 56.48257, -2.98894);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(599, 77, 'Dundee', 'DD4', 56.48209, -2.93534);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(600, 77, 'Dundee', 'DD5', 56.47812, -2.86217);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(601, 79, '', 'DD6', 56.43723, -2.92612);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(602, 78, 'Carnoustie', 'DD7', 56.5033, -2.71814);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(603, 78, '', 'DD8', 56.6565, -2.92171);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(604, 78, '', 'DD9', 56.74798, -2.6672);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(605, 80, '', 'DE1', 52.91994, -1.47492);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(606, 81, 'Swadlincote', 'DE11', 52.77372, -1.55377);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(607, 81, 'Overseal', 'DE12', 52.72516, -1.55279);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(608, 11, 'Branston', 'DE13', 52.80741, -1.68844);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(609, 11, 'Burton upon Trent', 'DE14', 52.80457, -1.6395);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(610, 11, 'Burton upon Trent', 'DE15', 52.79908, -1.6084);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(611, 80, '', 'DE21', 52.93322, -1.43161);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(612, 80, '', 'DE22', 52.93351, -1.49559);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(613, 80, '', 'DE23', 52.90114, -1.49448);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(614, 80, '', 'DE24', 52.89016, -1.4515);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(615, 80, '', 'DE3', 52.90852, -1.54049);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(616, 81, 'Matlock Bath', 'DE4', 53.12707, -1.56357);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(617, 81, 'Bakewell', 'DE45', 53.21464, -1.6765);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(618, 81, 'Ripley', 'DE5', 53.04456, -1.4018);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(619, 81, 'Alfreton', 'DE55', 53.10104, -1.37114);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(620, 81, 'Belper', 'DE56', 53.02152, -1.47369);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(621, 81, 'Osmaston', 'DE6', 52.99358, -1.7169);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(622, 81, 'Hilton', 'DE65', 52.86651, -1.60927);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(623, 81, 'Ilkeston', 'DE7', 52.9722, -1.32089);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(624, 81, 'Draycott', 'DE72', 52.8933, -1.35929);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(625, 81, 'Swarkestone', 'DE73', 52.84694, -1.43571);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(626, 75, 'Lockington', 'DE74', 52.84368, -1.32884);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(627, 81, 'Heanor', 'DE75', 53.01284, -1.35305);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(628, 82, '', 'DG1', 55.07353, -3.58045);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(629, 82, '', 'DG10', 55.31977, -3.43735);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(630, 82, '', 'DG11', 55.11331, -3.33584);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(631, 82, 'Annan', 'DG12', 54.98928, -3.25044);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(632, 82, '', 'DG13', 55.17291, -3.02849);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(633, 82, '', 'DG14', 55.08069, -2.98539);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(634, 82, 'Gretna', 'DG16', 54.99731, -3.06777);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(635, 82, '', 'DG2', 55.06442, -3.65683);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(636, 82, '', 'DG3', 55.23678, -3.79927);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(637, 82, '', 'DG4', 55.37555, -3.95236);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(638, 82, 'Dalbeattie', 'DG5', 54.92201, -3.81016);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(639, 82, 'Kirkcudbright', 'DG6', 54.83721, -4.05555);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(640, 82, '', 'DG7', 54.96738, -4.01219);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(641, 82, '', 'DG8', 54.87259, -4.51567);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(642, 82, '', 'DG9', 54.87815, -5.02123);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(643, 83, 'Durham', 'DH1', 54.78103, -1.56616);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(644, 83, 'Chester-le-Street', 'DH2', 54.85933, -1.59648);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(645, 83, 'North Lodge', 'DH3', 54.87181, -1.56675);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(646, 84, 'Houghton-le-Spring', 'DH4', 54.85444, -1.4906);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(647, 84, 'Hetton', 'DH5', 54.82372, -1.45363);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(648, 83, 'Shadforth', 'DH6', 54.75276, -1.46391);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(649, 83, 'Esh', 'DH7', 54.78943, -1.66406);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(650, 83, 'Burnhope', 'DH8', 54.85541, -1.84422);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(651, 83, 'Stanley', 'DH9', 54.86773, -1.70704);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(652, 85, '', 'DL1', 54.53016, -1.53637);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(653, 19, 'Skeeby', 'DL10', 54.41381, -1.69025);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(654, 19, 'Marske', 'DL11', 54.43841, -1.8751);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(655, 83, 'Cotherstone', 'DL12', 54.57239, -1.98453);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(656, 83, 'Stanhope', 'DL13', 54.71619, -1.95343);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(657, 83, 'Lcp Stanhope and Wolsingham Parishes And', 'DL14', 54.65199, -1.68999);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(658, 83, 'Lcp Stanhope and Wolsingham Parishes And', 'DL15', 54.7096, -1.72836);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(659, 83, 'Spennymoor', 'DL16', 54.69848, -1.60429);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(660, 83, 'Ferryhill', 'DL17', 54.68118, -1.54086);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(661, 85, 'Halnaby Ave', 'DL2', 54.5286, -1.6013);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(662, 85, '', 'DL3', 54.53209, -1.57035);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(663, 83, 'Shildon', 'DL4', 54.63029, -1.64368);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(664, 83, 'Great Aycliffe', 'DL5', 54.61749, -1.57565);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(665, 19, 'Winton', 'DL6', 54.37042, -1.38885);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(666, 19, 'Yafforth', 'DL7', 54.33761, -1.48471);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(667, 19, 'Spennithorne', 'DL8', 54.29267, -1.78489);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(668, 19, 'Colburn', 'DL9', 54.37521, -1.70902);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(669, 86, '', 'DN1', 53.52205, -1.1296);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(670, 87, 'Everton', 'DN10', 53.42705, -0.94339);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(671, 86, 'Tickhill', 'DN11', 53.45158, -1.08284);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(672, 86, 'Conisbrough', 'DN12', 53.48313, -1.22082);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(673, 88, 'Airmyn', 'DN14', 53.70747, -0.93638);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(674, 89, '', 'DN15', 53.61469, -0.64994);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(675, 89, '', 'DN16', 53.56782, -0.63935);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(676, 89, 'Burringham', 'DN17', 53.5721, -0.70114);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(677, 89, 'Barton-Upon-Humber', 'DN18', 53.68055, -0.44643);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(678, 89, 'Barrow-Upon-Humber', 'DN19', 53.68387, -0.35847);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(679, 86, '', 'DN2', 53.53264, -1.10222);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(680, 89, 'Broughton', 'DN20', 53.55723, -0.50531);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(681, 90, 'Corringham', 'DN21', 53.41927, -0.70129);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(682, 87, 'Clumber and Hardwick', 'DN22', 53.32352, -0.92643);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(683, 86, 'Edenthorpe', 'DN3', 53.54578, -1.05817);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(684, 91, '', 'DN31', 53.57014, -0.08648);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(685, 91, '', 'DN32', 53.56266, -0.06869);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(686, 91, '', 'DN33', 53.53974, -0.09691);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(687, 91, '', 'DN34', 53.55705, -0.11123);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(688, 91, 'Cleethorpes', 'DN35', 53.55494, -0.03583);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(689, 90, 'Tetney', 'DN36', 53.51089, -0.03636);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(690, 91, 'Bradley', 'DN37', 53.54033, -0.13461);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(691, 90, 'Bigby', 'DN38', 53.56115, -0.39192);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(692, 89, 'Ulceby', 'DN39', 53.617, -0.33385);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(693, 86, '', 'DN4', 53.50581, -1.12088);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(694, 91, 'Immingham', 'DN40', 53.6208, -0.22331);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(695, 91, 'Stallingborough', 'DN41', 53.58351, -0.19466);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(696, 86, 'Brodsworth', 'DN5', 53.53763, -1.17153);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(697, 86, 'Owston', 'DN6', 53.5961, -1.17643);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(698, 86, 'Hatfield', 'DN7', 53.58139, -1.01508);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(699, 86, 'Thorne', 'DN8', 53.61415, -0.95535);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(700, 89, 'Haxey', 'DN9', 53.50661, -0.89316);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(701, 22, 'Dorchester', 'DT1', 50.71093, -2.44052);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(702, 22, 'Sturminster Newton', 'DT10', 50.93702, -2.33306);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(703, 22, 'Bryanston', 'DT11', 50.86091, -2.18047);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(704, 22, 'Charminster', 'DT2', 50.74955, -2.45365);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(705, 22, 'Weymouth', 'DT3', 50.64067, -2.46674);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(706, 22, 'Weymouth', 'DT4', 50.60921, -2.4636);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(707, 22, 'Portland', 'DT5', 50.54724, -2.44041);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(708, 22, 'Allington', 'DT6', 50.73886, -2.77528);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(709, 22, 'Lyme Regis', 'DT7', 50.7286, -2.94657);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(710, 22, 'Beaminster', 'DT8', 50.81632, -2.7581);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(711, 22, 'Castleton', 'DT9', 50.94086, -2.51529);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(712, 10, '', 'DY1', 52.51648, -2.0958);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(713, 9, 'Kidderminster', 'DY10', 52.38594, -2.22483);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(714, 9, 'Kidderminster', 'DY11', 52.38496, -2.26009);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(715, 9, 'Upper Arley', 'DY12', 52.38569, -2.32916);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(716, 9, 'Stourport-on-Severn', 'DY13', 52.33637, -2.28035);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(717, 92, 'Cleobury Mortimer', 'DY14', 52.37985, -2.46282);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(718, 10, '', 'DY2', 52.49671, -2.08102);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(719, 10, '', 'DY3', 52.52994, -2.12826);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(720, 7, 'West Bromwich', 'DY4', 52.53269, -2.05308);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(721, 10, '', 'DY5', 52.48049, -2.12223);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(722, 10, '', 'DY6', 52.49842, -2.16353);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(723, 11, 'Kinver', 'DY7', 52.46596, -2.22376);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(724, 10, '', 'DY8', 52.45978, -2.15455);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(725, 10, '', 'DY9', 52.43554, -2.1221);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(726, 29, 'Poplar', 'E1', 51.51766, -0.05841);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(727, 29, 'Walthamstow', 'E10', 51.56814, -0.01153);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(728, 29, 'Walthamstow', 'E11', 51.56769, 0.01443);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(729, 29, 'Stratford', 'E12', 51.54992, 0.05404);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(730, 29, 'East Ham', 'E13', 51.527, 0.02705);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(731, 29, 'Poplar', 'E14', 51.5062, -0.01855);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(732, 29, 'Stratford', 'E15', 51.53911, 0.00307);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(733, 29, 'East Ham', 'E16', 51.51083, 0.02633);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(734, 29, 'Walthamstow', 'E17', 51.58623, -0.01796);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(735, 29, 'Ilford', 'E18', 51.59176, 0.02705);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(736, 29, 'Poplar', 'E1W', 51.50775, -0.05739);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(737, 29, 'Poplar', 'E2', 51.52939, -0.0608);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(738, 29, 'Poplar', 'E3', 51.52789, -0.02482);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(739, 29, 'Walthamstow', 'E4', 51.62196, -0.00339);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(740, 29, 'Hackney', 'E5', 51.55893, -0.05233);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(741, 29, 'East Ham', 'E6', 51.5256, 0.05583);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(742, 29, 'Stratford', 'E7', 51.54678, 0.02793);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(743, 29, 'Hackney', 'E8', 51.54202, -0.06315);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(744, 29, 'Hackney', 'E9', 51.54258, -0.04293);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(745, 29, 'Islington', 'EC1', 51.52286, -0.10144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(746, 29, 'Islington', 'EC1A', 51.52019, -0.103);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(747, 29, 'Islington', 'EC1M', 51.52106, -0.10152);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(748, 29, 'Camden Town', 'EC1N', 51.52026, -0.10732);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(749, 29, 'Islington', 'EC1R', 51.52475, -0.10713);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(750, 29, 'Islington', 'EC1V', 51.52549, -0.09701);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(751, 29, 'Islington', 'EC1Y', 51.52272, -0.0928);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(752, 29, 'Islington', 'EC2', 51.51995, -0.08859);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(753, 29, 'Islington', 'EC2A', 51.5226, -0.0856);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(754, 93, '', 'EC2M', 51.51811, -0.08578);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(755, 93, '', 'EC2N', 51.51631, -0.08586);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(756, 93, '', 'EC2R', 51.5164, -0.09162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(757, 93, '', 'EC2V', 51.51553, -0.0931);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(758, 93, '', 'EC2Y', 51.52007, -0.09579);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(759, 93, '', 'EC3', 51.51357, -0.08309);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(760, 93, '', 'EC3A', 51.51534, -0.08158);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(761, 93, '', 'EC3M', 51.51267, -0.08313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(762, 93, '', 'EC3N', 51.5126, -0.07881);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(763, 29, 'Islington', 'EC3P', 51.52016, -0.10156);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(764, 93, '', 'EC3R', 51.51179, -0.08461);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(765, 93, '', 'EC3V', 51.51361, -0.08597);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(766, 93, '', 'EC4', 51.51475, -0.10034);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(767, 93, '', 'EC4A', 51.51576, -0.10751);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(768, 93, '', 'EC4M', 51.51475, -0.10034);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(769, 93, '', 'EC4N', 51.51463, -0.09314);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(770, 93, '', 'EC4R', 51.51191, -0.09181);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(771, 93, '', 'EC4V', 51.51293, -0.09897);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(772, 93, '', 'EC4Y', 51.51397, -0.10758);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(773, 94, 'Edinburgh', 'EH1', 55.95243, -3.1884);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(774, 94, 'Edinburgh', 'EH10', 55.92077, -3.20984);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(775, 94, 'Juniper Green', 'EH11', 55.93387, -3.24867);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(776, 94, 'Edinburgh', 'EH12', 55.94262, -3.27137);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(777, 94, 'Juniper Green', 'EH13', 55.90788, -3.24144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(778, 94, 'Juniper Green', 'EH14', 55.90925, -3.28308);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(779, 94, 'Edinburgh', 'EH15', 55.94686, -3.11136);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(780, 94, 'Edinburgh', 'EH16', 55.92221, -3.15387);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(781, 94, 'Edinburgh', 'EH17', 55.90704, -3.14222);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(782, 95, 'Bonnyrigg and Lasswade', 'EH18', 55.87667, -3.12215);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(783, 95, 'Bonnyrigg and Lasswade', 'EH19', 55.87324, -3.10446);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(784, 94, 'Edinburgh', 'EH2', 55.95417, -3.19486);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(785, 95, 'Loanhead', 'EH20', 55.87905, -3.15579);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(786, 96, 'Musselburgh', 'EH21', 55.93845, -3.04548);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(787, 95, 'Dalkeith', 'EH22', 55.88441, -3.06001);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(788, 95, 'Arniston', 'EH23', 55.83956, -3.05081);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(789, 95, '', 'EH24', 55.85051, -3.13257);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(790, 95, 'Roslin', 'EH25', 55.85821, -3.17434);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(791, 95, 'Penicuik', 'EH26', 55.83257, -3.22307);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(792, 97, 'Kirknewton', 'EH27', 55.89063, -3.42319);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(793, 94, '', 'EH28', 55.9306, -3.38624);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(794, 94, 'Kirkliston', 'EH29', 55.95652, -3.39838);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(795, 94, 'Edinburgh', 'EH3', 55.95412, -3.19967);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(796, 94, 'Queensferry', 'EH30', 55.98455, -3.38336);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(797, 96, 'Gullane', 'EH31', 56.03627, -2.82661);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(798, 96, 'Cockenzie and Port Seton', 'EH32', 55.96799, -2.94853);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(799, 96, 'Tranent', 'EH33', 55.94196, -2.94469);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(800, 96, 'Pencaitland', 'EH34', 55.90919, -2.8799);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(801, 96, 'Ormiston', 'EH35', 55.91053, -2.94233);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(802, 96, '', 'EH36', 55.85637, -2.85155);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(803, 95, '', 'EH37', 55.86188, -2.95873);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(804, 98, '', 'EH38', 55.78638, -2.96006);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(805, 96, 'North Berwick', 'EH39', 56.04766, -2.73052);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(806, 94, 'Edinburgh', 'EH4', 55.96253, -3.25761);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(807, 96, '', 'EH40', 55.99057, -2.6557);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(808, 96, '', 'EH41', 55.94854, -2.7751);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(809, 96, '', 'EH42', 55.99389, -2.52428);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(810, 98, 'Walkerburn', 'EH43', 55.62422, -3.0101);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(811, 98, '', 'EH44', 55.62015, -3.06558);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(812, 98, 'Peebles', 'EH45', 55.65494, -3.19209);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(813, 98, '', 'EH46', 55.73689, -3.3491);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(814, 97, '', 'EH47', 55.85976, -3.66336);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(815, 97, 'Bathgate', 'EH48', 55.9011, -3.66353);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(816, 97, 'Linlithgow', 'EH49', 55.97656, -3.59785);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(817, 94, 'Edinburgh', 'EH5', 55.97463, -3.21633);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(818, 99, 'Grangepans', 'EH51', 56.01153, -3.6041);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(819, 97, 'Broxburn', 'EH52', 55.93756, -3.48256);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(820, 97, 'Livingston', 'EH53', 55.8936, -3.47608);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(821, 97, 'Livingston', 'EH54', 55.89212, -3.524);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(822, 97, 'West Calder', 'EH55', 55.84748, -3.57178);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(823, 94, 'Edinburgh', 'EH6', 55.97144, -3.17456);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(824, 94, 'Edinburgh', 'EH7', 55.96075, -3.16463);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(825, 94, '', 'EH8', 55.94909, -3.16268);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(826, 94, 'Edinburgh', 'EH9', 55.9336, -3.18463);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(827, 29, 'Enfield', 'EN1', 51.6536, -0.06707);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(828, 4, 'Broxbourne', 'EN10', 51.74005, -0.01992);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(829, 4, 'Hoddesdon', 'EN11', 51.76502, -0.00723);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(830, 29, 'Enfield', 'EN2', 51.6585, -0.09144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(831, 29, 'Enfield', 'EN3', 51.65852, -0.03794);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(832, 29, 'Barnet', 'EN4', 51.6479, -0.15983);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(833, 29, 'Barnet', 'EN5', 51.64934, -0.19447);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(834, 4, 'Potters Bar', 'EN6', 51.69942, -0.17656);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(835, 4, 'Broxbourne', 'EN7', 51.71025, -0.0661);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(836, 4, 'Broxbourne', 'EN8', 51.69799, -0.03189);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(837, 62, 'Waltham Abbey', 'EN9', 51.69451, 0.01427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(838, 100, 'Exeter', 'EX1', 50.72543, -3.50479);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(839, 100, 'Sidmouth', 'EX10', 50.69252, -3.24461);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(840, 100, 'Ottery St Mary', 'EX11', 50.74603, -3.28714);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(841, 100, 'Seaton', 'EX12', 50.70585, -3.08066);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(842, 100, 'Axminster', 'EX13', 50.78655, -3.00733);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(843, 100, 'Honiton', 'EX14', 50.81272, -3.1896);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(844, 100, 'Kentisbeare', 'EX15', 50.87675, -3.33907);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(845, 100, 'Tiverton', 'EX16', 50.92258, -3.49122);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(846, 100, 'Sandford', 'EX17', 50.81176, -3.70205);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(847, 100, 'Chawleigh', 'EX18', 50.90155, -3.88739);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(848, 100, 'Dowland', 'EX19', 50.87712, -4.0044);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(849, 100, 'Exeter', 'EX2', 50.70998, -3.51705);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(850, 100, 'Okehampton Hamlets', 'EX20', 50.75004, -4.01882);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(851, 100, 'Black Torrington', 'EX21', 50.80507, -4.20857);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(852, 100, 'Holsworthy Hamlets', 'EX22', 50.82804, -4.3673);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(853, 101, 'Bude', 'EX23', 50.82366, -4.53323);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(854, 100, 'Colyton', 'EX24', 50.73816, -3.08849);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(855, 100, 'Exeter', 'EX3', 50.68645, -3.45824);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(856, 100, 'Barnstaple', 'EX31', 51.08566, -4.06339);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(857, 100, 'Barnstaple', 'EX32', 51.07115, -4.01849);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(858, 100, 'Braunton', 'EX33', 51.11343, -4.16894);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(859, 100, 'Ilfracombe', 'EX34', 51.19829, -4.10278);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(860, 100, 'Lynton', 'EX35', 51.2236, -3.82749);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(861, 100, 'Bishops Nympton', 'EX36', 51.01638, -3.79224);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(862, 100, 'High Bickington', 'EX37', 50.97875, -3.95179);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(863, 100, 'Little Torrington', 'EX38', 50.94376, -4.15107);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(864, 100, 'Abbotsham', 'EX39', 51.01394, -4.24557);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(865, 100, 'Exeter', 'EX4', 50.73055, -3.52621);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(866, 100, 'Broad Clyst', 'EX5', 50.75684, -3.43916);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(867, 100, 'Doddiscombsleigh', 'EX6', 50.67744, -3.59668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(868, 100, 'Dawlish', 'EX7', 50.59183, -3.47227);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(869, 100, 'Exmouth', 'EX8', 50.62958, -3.40133);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(870, 100, 'Budleigh Salterton', 'EX9', 50.6386, -3.32239);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(871, 99, '', 'FK1', 55.98555, -3.79381);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(872, 102, 'Alloa', 'FK10', 56.11516, -3.78053);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(873, 102, 'Menstrie', 'FK11', 56.15009, -3.84977);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(874, 102, 'Alva', 'FK12', 56.15263, -3.79998);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(875, 102, 'Tillicoultry', 'FK13', 56.15078, -3.74032);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(876, 102, '', 'FK14', 56.16536, -3.66044);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(877, 103, '', 'FK15', 56.20249, -3.94903);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(878, 103, 'Doune', 'FK16', 56.19081, -4.05966);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(879, 103, 'Callander', 'FK17', 56.24019, -4.21887);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(880, 103, 'Strathyre', 'FK18', 56.32448, -4.32728);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(881, 103, '', 'FK19', 56.37057, -4.3139);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(882, 99, 'Hope St', 'FK2', 56.00499, -3.75461);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(883, 103, '', 'FK20', 56.4065, -4.63059);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(884, 103, 'Killin', 'FK21', 56.46574, -4.31969);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(885, 99, 'Grangemouth', 'FK3', 56.01087, -3.71958);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(886, 99, 'Dennyloanhead', 'FK4', 55.99734, -3.90662);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(887, 99, '', 'FK5', 56.02564, -3.81814);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(888, 99, 'Stoneywood', 'FK6', 56.02149, -3.91423);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(889, 103, '', 'FK7', 56.09695, -3.91636);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(890, 103, '', 'FK8', 56.13075, -4.05001);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(891, 103, 'Bridge Of Allan', 'FK9', 56.14242, -3.93955);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(892, 104, '', 'FY1', 53.81551, -3.04509);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(893, 104, '', 'FY2', 53.84524, -3.03823);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(894, 104, '', 'FY3', 53.82111, -3.02092);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(895, 104, '', 'FY4', 53.79139, -3.02779);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(896, 16, 'Hardhorn and Thornton', 'FY5', 53.87415, -3.02069);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(897, 16, 'Hardhorn and Thornton', 'FY6', 53.86819, -2.981);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(898, 16, 'Hardhorn and Thornton', 'FY7', 53.91635, -3.02629);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(899, 16, 'Lytham Saint Annes', 'FY8', 53.75026, -3.001);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(900, 105, 'Glasgow', 'G1', 55.86038, -4.24671);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(901, 105, 'Glasgow', 'G11', 55.87356, -4.31142);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(902, 105, 'Glasgow', 'G12', 55.88006, -4.30061);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(903, 105, 'Glasgow', 'G13', 55.89358, -4.3462);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(904, 105, 'Glasgow', 'G14', 55.88095, -4.34864);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(905, 105, 'Glasgow', 'G15', 55.9094, -4.36476);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(906, 105, 'Glasgow', 'G2', 55.86382, -4.2549);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(907, 105, 'Glasgow', 'G20', 55.8858, -4.28176);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(908, 105, 'Glasgow', 'G21', 55.88063, -4.22069);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(909, 105, 'Glasgow', 'G22', 55.88998, -4.25002);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(910, 105, 'Glasgow', 'G23', 55.90193, -4.28431);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(911, 105, 'Glasgow', 'G3', 55.86619, -4.27262);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(912, 105, 'Glasgow', 'G31', 55.85748, -4.20819);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(913, 105, 'Glasgow', 'G32', 55.8484, -4.16293);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(914, 105, 'Glasgow', 'G33', 55.87351, -4.16593);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(915, 105, 'Glasgow', 'G34', 55.86817, -4.11128);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(916, 105, 'Glasgow', 'G4', 55.86837, -4.25196);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(917, 105, 'Glasgow', 'G40', 55.84824, -4.22204);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(918, 105, 'Glasgow', 'G41', 55.83815, -4.28216);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(919, 105, 'Glasgow', 'G42', 55.83234, -4.25627);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(920, 105, 'Glasgow', 'G43', 55.81825, -4.28898);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(921, 105, 'Glasgow', 'G44', 55.81438, -4.25523);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(922, 105, 'Glasgow', 'G45', 55.80494, -4.23074);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(923, 106, 'Thornliebank', 'G46', 55.80446, -4.30573);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(924, 105, 'Glasgow', 'G5', 55.84769, -4.25237);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(925, 105, 'Glasgow', 'G51', 55.85734, -4.31365);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(926, 105, 'Glasgow', 'G52', 55.8477, -4.34823);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(927, 105, 'Glasgow', 'G53', 55.82157, -4.35145);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(928, 107, 'Clydebank', 'G60', 55.92205, -4.45358);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(929, 108, 'Milngavie', 'G61', 55.91905, -4.33014);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(930, 108, 'Milngavie', 'G62', 55.94261, -4.32034);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(931, 103, 'Killearn', 'G63', 56.04243, -4.36487);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(932, 108, 'Bishopbriggs', 'G64', 55.91127, -4.21604);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(933, 109, 'Kilsyth', 'G65', 55.97334, -4.0577);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(934, 108, 'Kirkintilloch', 'G66', 55.94024, -4.15364);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(935, 109, 'Cumbernauld', 'G67', 55.94755, -3.98586);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(936, 109, 'Balloch', 'G68', 55.95345, -4.01019);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(937, 105, 'Glasgow', 'G69', 55.87372, -4.10199);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(938, 110, '', 'G71', 55.8221, -4.07206);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(939, 110, '', 'G72', 55.80406, -4.12856);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(940, 110, 'Cambuslang', 'G73', 55.81977, -4.20605);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(941, 110, 'East Kilbride', 'G74', 55.76912, -4.17289);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(942, 106, 'Thornliebank', 'G76', 55.77811, -4.27227);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(943, 106, 'Newton Mearns', 'G77', 55.77345, -4.32941);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(944, 106, '', 'G78', 55.79259, -4.40873);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(945, 107, 'Clydebank', 'G81', 55.91309, -4.4066);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(946, 107, 'Dumbarton', 'G82', 55.95195, -4.57403);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(947, 107, 'Alexandria', 'G83', 56.01196, -4.58444);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(948, 111, 'Helensburgh', 'G84', 56.0137, -4.75306);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(949, 112, 'Gloucester', 'GL1', 51.8599, -2.23962);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(950, 112, 'Stonehouse', 'GL10', 51.7429, -2.28391);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(951, 112, 'Dursley', 'GL11', 51.68875, -2.35591);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(952, 112, 'Kingswood', 'GL12', 51.62482, -2.3843);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(953, 112, 'Berkeley', 'GL13', 51.69289, -2.45867);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(954, 112, 'Littledean', 'GL14', 51.81691, -2.47879);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(955, 112, 'Lydney', 'GL15', 51.73656, -2.55036);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(956, 112, 'Coleford', 'GL16', 51.79561, -2.61054);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(957, 112, 'Drybrook', 'GL17', 51.85542, -2.51405);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(958, 112, 'Oxenhall', 'GL18', 51.94124, -2.41464);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(959, 112, 'Ashleworth', 'GL19', 51.94252, -2.28662);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(960, 112, 'Gloucester', 'GL2', 51.84635, -2.26714);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(961, 112, 'Ashchurch', 'GL20', 52.00304, -2.12966);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(962, 112, 'Hucclecote', 'GL3', 51.86451, -2.17719);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(963, 112, 'Gloucester', 'GL4', 51.84196, -2.2163);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(964, 112, 'Rodborough', 'GL5', 51.73855, -2.2187);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(965, 112, 'Cheltenham', 'GL50', 51.89968, -2.07995);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(966, 112, 'Cheltenham', 'GL51', 51.89876, -2.10756);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(967, 112, 'Prestbury', 'GL52', 51.91588, -2.05816);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(968, 112, 'Cheltenham', 'GL53', 51.88081, -2.06684);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(969, 112, 'Naunton', 'GL54', 51.89693, -1.86338);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(970, 112, 'Chipping Campden', 'GL55', 52.06043, -1.76806);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(971, 112, 'Moreton-in-Marsh', 'GL56', 51.98836, -1.70435);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(972, 112, 'Thrupp', 'GL6', 51.735, -2.19117);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(973, 112, 'Ampney St Mary', 'GL7', 51.71263, -1.89723);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(974, 112, 'Tetbury', 'GL8', 51.64151, -2.17054);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(975, 32, 'Hawkesbury', 'GL9', 51.55763, -2.29718);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(976, 73, 'Guildford', 'GU1', 51.24255, -0.56436);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(977, 73, 'Farnham', 'GU10', 51.1975, -0.79622);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(978, 23, 'Aldershot', 'GU11', 51.24841, -0.76194);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(979, 73, 'Ash', 'GU12', 51.25167, -0.73032);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(980, 23, 'Fleet', 'GU13', 51.27436, -0.83723);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(981, 23, 'Farnborough', 'GU14', 51.29246, -0.76075);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(982, 73, 'Camberley', 'GU15', 51.3345, -0.73952);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(983, 73, 'Camberley', 'GU16', 51.311, -0.72868);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(984, 23, 'Blackwater and Hawley', 'GU17', 51.32959, -0.78559);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(985, 73, 'Windlesham', 'GU18', 51.34813, -0.67021);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(986, 73, 'Windlesham', 'GU19', 51.35914, -0.69);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(987, 73, 'Guildford', 'GU2', 51.24468, -0.59152);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(988, 73, 'Windlesham', 'GU20', 51.36776, -0.65671);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(989, 73, 'Woking', 'GU21', 51.32006, -0.57773);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(990, 73, 'Woking', 'GU22', 51.31162, -0.54929);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(991, 73, 'Ripley', 'GU23', 51.29671, -0.50816);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(992, 73, 'Bisley', 'GU24', 51.32963, -0.62625);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(993, 73, 'Virginia Water', 'GU25', 51.4009, -0.56948);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(994, 73, 'Haslemere', 'GU26', 51.11243, -0.74557);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(995, 73, 'Haslemere', 'GU27', 51.08155, -0.71785);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(996, 28, 'Tillington', 'GU28', 50.99061, -0.62915);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(997, 28, 'Midhurst', 'GU29', 50.98383, -0.74619);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(998, 73, 'Worplesdon', 'GU3', 51.24596, -0.62301);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(999, 23, 'Liphook', 'GU30', 51.07435, -0.80228);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1000, 23, 'Petersfield', 'GU31', 50.9962, -0.90263);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1001, 23, 'Stroud', 'GU32', 51.00849, -0.96934);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1002, 23, 'Liss', 'GU33', 51.04915, -0.89139);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1003, 23, 'Alton', 'GU34', 51.13902, -0.98359);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1004, 23, 'Lindford', 'GU35', 51.11617, -0.84692);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1005, 73, 'Guildford', 'GU4', 51.24315, -0.53999);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1006, 23, 'Yateley', 'GU46', 51.3372, -0.82559);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1007, 113, 'Sandhurst', 'GU47', 51.34761, -0.78799);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1008, 73, 'Wonersh', 'GU5', 51.20237, -0.51551);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1009, 23, 'Fleet', 'GU51', 51.28338, -0.83987);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1010, 23, 'Fleet', 'GU52', 51.26447, -0.83748);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1011, 73, 'Cranleigh', 'GU6', 51.14078, -0.48174);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1012, 73, 'Godalming', 'GU7', 51.18915, -0.61039);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1013, 73, 'Witley', 'GU8', 51.15082, -0.64014);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1014, 73, 'Farnham', 'GU9', 51.21815, -0.79282);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1015, 114, 'St Peter Port', 'GY1', 49.45856, -2.53684);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1016, 114, 'St Sampson', 'GY2', 49.57871, -2.49362);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1017, 114, 'St Sampson', 'GY3', 49.52875, -2.45821);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1018, 114, 'Carmel', 'GY4', 49.52875, -2.45821);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1019, 114, 'ALBecq', 'GY5', 49.4826, -2.58101);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1020, 114, 'L\'Islet', 'GY6', 49.52875, -2.45821);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1021, 114, 'Richmond', 'GY7', 49.52875, -2.45821);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1022, 114, 'Mouilpied', 'GY8', 49.52875, -2.45821);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1023, 114, 'nr Mouilpied', 'GY9', 49.57183, -2.28244);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1024, 29, 'Brent', 'HA0', 51.55024, -0.3037);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1025, 29, 'Harrow', 'HA1', 51.57948, -0.33581);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1026, 29, 'Harrow', 'HA2', 51.57349, -0.35768);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1027, 29, 'Harrow', 'HA3', 51.59274, -0.31945);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1028, 29, 'Hillingdon', 'HA4', 51.56971, -0.40977);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1029, 29, 'Harrow', 'HA5', 51.59455, -0.38436);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1030, 29, 'Hillingdon', 'HA6', 51.61032, -0.41991);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1031, 29, 'Harrow', 'HA7', 51.60965, -0.30727);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1032, 29, 'Barnet', 'HA8', 51.61094, -0.27255);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1033, 29, 'Brent', 'HA9', 51.55898, -0.28606);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1034, 18, 'Huddersfield', 'HD1', 53.64639, -1.78819);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1035, 18, 'Huddersfield', 'HD2', 53.66794, -1.77446);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1036, 18, 'Huddersfield', 'HD3', 53.65274, -1.8275);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1037, 18, 'Huddersfield', 'HD4', 53.62662, -1.79585);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1038, 18, 'Huddersfield', 'HD5', 53.6472, -1.74583);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1039, 115, 'Halifax', 'HD6', 53.70121, -1.78186);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1040, 18, 'Huddersfield', 'HD7', 53.62404, -1.87601);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1041, 18, 'Kirkburton', 'HD8', 53.6012, -1.6796);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1042, 18, 'Holme', 'HD9', 53.57988, -1.79457);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1043, 19, 'Harrogate', 'HG1', 53.99983, -1.53313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1044, 19, 'Harrogate', 'HG2', 53.98722, -1.52565);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1045, 19, 'Clint', 'HG3', 54.03069, -1.61676);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1046, 19, 'North Stainley', 'HG4', 54.15636, -1.5666);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1047, 19, 'Knaresborough', 'HG5', 54.013, -1.45668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1048, 4, 'Hemel Hempstead', 'HP1', 51.75509, -0.48731);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1049, 116, 'Chepping Wycombe', 'HP10', 51.60928, -0.70159);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1050, 116, 'High Wycombe', 'HP11', 51.62413, -0.74451);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1051, 116, 'High Wycombe', 'HP12', 51.62538, -0.77771);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1052, 116, 'High Wycombe', 'HP13', 51.63309, -0.74137);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1053, 116, 'Bledlow-cum-Saunderton', 'HP14', 51.64839, -0.82913);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1054, 116, 'Hazlemere', 'HP15', 51.65615, -0.71182);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1055, 116, 'Great Missenden', 'HP16', 51.70208, -0.71775);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1056, 116, 'Dinton', 'HP17', 51.77558, -0.86933);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1057, 116, 'Ashendon', 'HP18', 51.81347, -0.98155);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1058, 116, 'Aylesbury', 'HP19', 51.8219, -0.82464);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1059, 4, 'Hemel Hempstead', 'HP2', 51.76273, -0.45227);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1060, 116, 'Aylesbury', 'HP20', 51.81898, -0.80295);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1061, 116, 'Aylesbury', 'HP21', 51.80641, -0.80473);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1062, 116, 'Weston Turville', 'HP22', 51.80601, -0.76558);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1063, 4, 'Tring', 'HP23', 51.79496, -0.66001);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1064, 116, 'Princes Risborough', 'HP27', 51.71944, -0.83019);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1065, 4, 'Hemel Hempstead', 'HP3', 51.73689, -0.47054);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1066, 4, 'Berkhamsted', 'HP4', 51.76688, -0.56663);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1067, 116, 'Chesham', 'HP5', 51.71251, -0.60744);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1068, 116, 'Amersham', 'HP6', 51.67823, -0.59836);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1069, 116, 'Amersham', 'HP7', 51.66487, -0.6089);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1070, 116, 'Chalfont St Giles', 'HP8', 51.64286, -0.57344);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1071, 116, 'Beaconsfield', 'HP9', 51.61035, -0.63801);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1072, 117, 'Hampton Bishop', 'HR1', 52.06415, -2.66963);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1073, 117, 'Allensmore', 'HR2', 52.0095, -2.78393);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1074, 117, 'Clifford', 'HR3', 52.09353, -3.07446);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1075, 117, 'Burghill', 'HR4', 52.08784, -2.76632);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1076, 117, 'Kington Rural', 'HR5', 52.19196, -3.02708);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1077, 117, 'Leominster', 'HR6', 52.23258, -2.77028);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1078, 117, 'Bromyard', 'HR7', 52.18629, -2.52079);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1079, 117, 'Ledbury', 'HR8', 52.04454, -2.44331);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1080, 117, 'Ross-on-Wye', 'HR9', 51.90816, -2.58153);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1081, 118, 'Stornoway', 'HS1', 58.21347, -6.38138);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1082, 118, '', 'HS2', 58.24916, -6.46768);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1083, 118, '', 'HS3', 57.87876, -6.85387);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1084, 118, '', 'HS4', 57.86961, -6.69056);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1085, 118, 'Leverburgh', 'HS5', 57.79992, -6.96123);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1086, 118, '', 'HS6', 57.6008, -7.29943);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1087, 118, '', 'HS7', 57.44703, -7.33888);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1088, 118, '', 'HS8', 57.23253, -7.34593);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1089, 118, '', 'HS9', 56.97148, -7.47153);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1090, 119, 'Hull', 'HU1', 53.74288, -0.33494);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1091, 88, 'Cottingham', 'HU10', 53.75149, -0.44078);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1092, 88, 'Ellerby', 'HU11', 53.82572, -0.21921);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1093, 88, 'Burstwick', 'HU12', 53.72369, -0.13105);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1094, 88, 'Hessle', 'HU13', 53.72446, -0.43572);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1095, 88, 'North Ferriby', 'HU14', 53.72799, -0.50078);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1096, 88, 'Ellerker', 'HU15', 53.74831, -0.62139);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1097, 88, 'Cottingham', 'HU16', 53.78179, -0.41993);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1098, 88, 'Cottingham', 'HU17', 53.8466, -0.42661);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1099, 88, 'Hornsea', 'HU18', 53.90944, -0.16692);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1100, 88, 'Withernsea', 'HU19', 53.72277, 0.03566);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1101, 119, 'Hull', 'HU2', 53.75011, -0.33769);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1102, 88, 'Rowley', 'HU20', 53.78836, -0.51229);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1103, 119, 'Hull', 'HU3', 53.74148, -0.36381);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1104, 119, 'Hull', 'HU4', 53.73568, -0.40043);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1105, 119, 'Hull', 'HU5', 53.75961, -0.37524);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1106, 119, 'Hull', 'HU6', 53.7811, -0.36834);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1107, 119, 'Hull', 'HU7', 53.7886, -0.32554);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1108, 119, 'Hull', 'HU8', 53.76845, -0.29903);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1109, 119, 'Hull', 'HU9', 53.75567, -0.28589);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1110, 115, 'Halifax', 'HX1', 53.72111, -1.86966);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1111, 115, 'Halifax', 'HX2', 53.73733, -1.90448);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1112, 115, 'Halifax', 'HX3', 53.72648, -1.84387);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1113, 115, 'Halifax', 'HX4', 53.67978, -1.88039);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1114, 115, 'Halifax', 'HX5', 53.68601, -1.83494);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1115, 115, 'Halifax', 'HX6', 53.69779, -1.92426);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1116, 115, 'Hebden Royd', 'HX7', 53.73916, -2.00758);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1117, 29, 'Ilford', 'IG1', 51.55855, 0.07463);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1118, 62, 'Loughton', 'IG10', 51.64775, 0.06569);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1119, 29, 'Barking', 'IG11', 51.53573, 0.09378);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1120, 29, 'Ilford', 'IG2', 51.57373, 0.08109);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1121, 29, 'Ilford', 'IG3', 51.56168, 0.10074);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1122, 29, 'Ilford', 'IG4', 51.57688, 0.05525);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1123, 29, 'Ilford', 'IG5', 51.58749, 0.06584);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1124, 29, 'Ilford', 'IG6', 51.59247, 0.08917);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1125, 62, 'Loughton', 'IG7', 51.61316, 0.08867);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1126, 29, 'Ilford', 'IG8', 51.60694, 0.0335);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1127, 62, 'Loughton', 'IG9', 51.62391, 0.04004);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1128, 120, 'Douglas, Braddan', 'IM1', 54.15048, -4.48174);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1129, 120, 'Douglas, Braddan', 'IM2', 54.17891, -4.46857);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1130, 120, 'Onchan', 'IM3', 54.17219, -4.45155);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1131, 120, 'Peel, German', 'IM4', 54.18407, -4.53302);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1132, 120, 'Baldrine, Loman', 'IM5', 54.19316, -4.7065);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1133, 120, 'Kirk Michael', 'IM6', 54.28659, -4.58037);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1134, 120, 'St Judes, Andreas', 'IM7', 54.32613, -4.41041);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1135, 120, 'Ramsay', 'IM8', 54.278, -4.08474);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1136, 120, 'Arbory', 'IM9', 54.09184, -4.68352);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1137, 63, 'Ipswich', 'IP1', 52.06644, 1.14151);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1138, 63, 'Levington', 'IP10', 52.01888, 1.26939);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1139, 63, 'Felixstowe', 'IP11', 51.97028, 1.3343);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1140, 63, 'Bromeswell', 'IP12', 52.09243, 1.37262);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1141, 63, 'Kettleburgh', 'IP13', 52.18475, 1.32107);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1142, 63, 'Stowupland', 'IP14', 52.20597, 1.03423);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1143, 63, 'Aldeburgh', 'IP15', 52.15686, 1.59688);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1144, 63, 'Leiston', 'IP16', 52.20397, 1.58604);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1145, 63, 'Kelsale', 'IP17', 52.22985, 1.50316);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1146, 63, 'Southwold', 'IP18', 52.32995, 1.67259);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1147, 63, 'Halesworth', 'IP19', 52.33982, 1.4957);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1148, 63, 'Ipswich', 'IP2', 52.04501, 1.13563);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1149, 121, 'Harleston', 'IP20', 52.40601, 1.3215);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1150, 63, 'Syleham', 'IP21', 52.36431, 1.23608);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1151, 63, 'Wortham', 'IP22', 52.37548, 1.05319);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1152, 63, 'Eye', 'IP23', 52.30615, 1.12472);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1153, 121, 'Thetford', 'IP24', 52.41869, 0.75903);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1154, 121, 'Ovington', 'IP25', 52.58588, 0.83892);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1155, 121, 'Methwold', 'IP26', 52.50733, 0.57739);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1156, 63, 'Brandon', 'IP27', 52.4298, 0.5861);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1157, 63, 'Tuddenham', 'IP28', 52.32627, 0.54924);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1158, 63, 'Whepstead', 'IP29', 52.19245, 0.66303);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1159, 63, 'Ipswich', 'IP3', 52.0418, 1.18792);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1160, 63, 'Hessett', 'IP30', 52.20909, 0.83679);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1161, 63, 'Pakenham', 'IP31', 52.29023, 0.82877);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1162, 63, 'Bury St Edmunds', 'IP32', 52.25326, 0.71797);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1163, 63, 'Bury St Edmunds', 'IP33', 52.24178, 0.70848);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1164, 63, 'Ipswich', 'IP4', 52.06, 1.18046);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1165, 63, 'Kesgrave', 'IP5', 52.06102, 1.24182);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1166, 63, 'Hemingstone', 'IP6', 52.131, 1.11536);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1167, 63, 'Aldham', 'IP7', 52.06872, 0.94901);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1168, 63, 'Sproughton', 'IP8', 52.06169, 1.0828);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1169, 63, 'Holbrook', 'IP9', 51.99067, 1.14931);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1170, 122, 'Inverness', 'IV1', 57.4874, -4.23059);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1171, 122, '', 'IV10', 57.58536, -4.12616);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1172, 122, 'Cromarty', 'IV11', 57.67758, -4.03762);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1173, 122, 'Nairn', 'IV12', 57.57422, -3.86458);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1174, 122, '', 'IV13', 57.3428, -4.01239);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1175, 122, 'Strathpeffer', 'IV14', 57.58564, -4.54783);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1176, 122, 'Dingwall', 'IV15', 57.59965, -4.42996);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1177, 122, 'Evanton', 'IV16', 57.66431, -4.33703);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1178, 122, 'Alness', 'IV17', 57.69985, -4.26043);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1179, 122, 'Invergordon', 'IV18', 57.70169, -4.15479);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1180, 122, 'Tain', 'IV19', 57.80478, -4.06162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1181, 122, '', 'IV2', 57.46833, -4.19107);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1182, 122, '', 'IV20', 57.78653, -3.90748);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1183, 122, 'Gairloch', 'IV21', 57.72377, -5.72019);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1184, 122, '', 'IV22', 57.74156, -5.50682);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1185, 122, '', 'IV23', 57.77322, -5.01018);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1186, 122, '', 'IV24', 57.89133, -4.35512);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1187, 122, '', 'IV25', 57.89135, -4.04295);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1188, 122, '', 'IV26', 57.91578, -5.17243);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1189, 122, '', 'IV27', 58.27684, -4.80032);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1190, 122, 'Rogart', 'IV28', 58.01527, -4.15668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1191, 122, 'Inverness', 'IV3', 57.47726, -4.24499);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1192, 3, 'Elgin', 'IV30', 57.65468, -3.32732);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1193, 3, 'Lossiemouth', 'IV31', 57.71706, -3.28931);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1194, 3, 'Mosstodloch', 'IV32', 57.63161, -3.11041);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1195, 3, 'Forres', 'IV36', 57.61104, -3.60363);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1196, 122, '', 'IV4', 57.44843, -4.53328);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1197, 122, '', 'IV40', 57.27446, -5.64981);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1198, 122, 'Kyleakin', 'IV41', 57.27372, -5.73605);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1199, 122, '', 'IV42', 57.23946, -5.82877);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1200, 122, '', 'IV43', 57.1555, -5.81015);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1201, 122, 'Saasaig', 'IV44', 57.11488, -5.87374);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1202, 122, '', 'IV45', 57.06714, -5.90508);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1203, 122, 'Ferrindonald', 'IV46', 57.1141, -5.98441);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1204, 122, '', 'IV47', 57.29467, -6.34284);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1205, 122, '', 'IV48', 57.31102, -6.09713);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1206, 122, '', 'IV49', 57.2277, -5.94693);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1207, 122, '', 'IV5', 57.4679, -4.4112);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1208, 122, '', 'IV51', 57.48055, -6.24636);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1209, 122, 'Plockton', 'IV52', 57.33737, -5.65106);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1210, 122, '', 'IV53', 57.34465, -5.55367);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1211, 122, '', 'IV54', 57.43101, -5.61538);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1212, 122, '', 'IV55', 57.45873, -6.611);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1213, 122, 'A863', 'IV56', 57.36636, -6.4279);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1214, 122, 'Muir Of Ord', 'IV6', 57.52634, -4.45682);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1215, 122, 'Lewiston', 'IV63', 57.32228, -4.50465);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1216, 122, '', 'IV7', 57.58435, -4.38376);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1217, 122, '', 'IV8', 57.55419, -4.26477);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1218, 122, 'Avoch', 'IV9', 57.56922, -4.17706);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1219, 123, 'St Helier', 'JE1', 49.19094, -2.11961);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1220, 123, 'St Helier', 'JE2', 49.20183, -2.10719);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1221, 123, 'St+F2813 Ouen', 'JE3', 49.18581, -2.13418);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1222, 123, 'St Helier', 'JE4', 49.19392, -2.09104);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1223, 124, 'Kilmarnock', 'KA1', 55.5958, -4.49509);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1224, 125, 'Troon', 'KA10', 55.54945, -4.64755);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1225, 126, 'Irvine', 'KA11', 55.61736, -4.62512);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1226, 126, 'Irvine', 'KA12', 55.61923, -4.66337);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1227, 126, 'Kilwinning', 'KA13', 55.6553, -4.69921);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1228, 126, 'Glengarnock', 'KA14', 55.74041, -4.67162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1229, 126, 'Beith', 'KA15', 55.74859, -4.62596);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1230, 124, 'Newmilns', 'KA16', 55.60713, -4.33065);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1231, 124, 'Darvel', 'KA17', 55.61075, -4.28164);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1232, 124, 'Cumnock', 'KA18', 55.45063, -4.23917);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1233, 125, '', 'KA19', 55.34585, -4.66707);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1234, 124, 'Gatehead', 'KA2', 55.59619, -4.56338);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1235, 126, 'Stevenston', 'KA20', 55.64157, -4.75072);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1236, 126, 'Ardrossan', 'KA21', 55.64176, -4.78253);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1237, 126, 'Ardrossan', 'KA22', 55.65019, -4.80697);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1238, 126, 'West Kilbride', 'KA23', 55.69135, -4.85449);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1239, 126, 'Dalry', 'KA24', 55.70981, -4.71412);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1240, 126, 'Kilbirnie', 'KA25', 55.75263, -4.6884);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1241, 125, '', 'KA26', 55.21894, -4.83313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1242, 126, '', 'KA27', 55.5388, -5.17162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1243, 126, 'Millport', 'KA28', 55.75447, -4.92287);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1244, 126, 'Fairlie', 'KA29', 55.75701, -4.85291);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1245, 124, '', 'KA3', 55.64435, -4.49499);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1246, 126, 'Largs', 'KA30', 55.79725, -4.86224);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1247, 124, 'Galston', 'KA4', 55.59894, -4.38256);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1248, 124, 'Mauchline', 'KA5', 55.50987, -4.38668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1249, 125, '', 'KA6', 55.41582, -4.50427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1250, 125, 'Ayr', 'KA7', 55.44739, -4.62805);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1251, 125, 'Ayr', 'KA8', 55.4711, -4.61222);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1252, 125, 'Ayr', 'KA9', 55.49734, -4.60446);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1253, 29, 'Kingston Upon Thames', 'KT1', 51.40713, -0.29606);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1254, 73, 'Esher', 'KT10', 51.36749, -0.35357);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1255, 73, 'Cobham', 'KT11', 51.32769, -0.40237);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1256, 73, 'West Molesey', 'KT12', 51.37721, -0.40639);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1257, 73, 'West Molesey', 'KT13', 51.36788, -0.44838);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1258, 73, '', 'KT14', 51.33869, -0.48526);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1259, 73, 'Addlestone', 'KT15', 51.36309, -0.49451);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1260, 73, '', 'KT16', 51.38312, -0.51398);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1261, 73, 'Epsom', 'KT17', 51.34078, -0.24827);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1262, 73, '', 'KT18', 51.3167, -0.2621);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1263, 73, 'Epsom', 'KT19', 51.35096, -0.26799);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1264, 29, 'Kingston Upon Thames', 'KT2', 51.41602, -0.28854);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1265, 73, 'Reigate and Banstead', 'KT20', 51.28564, -0.23029);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1266, 73, 'Leatherhead', 'KT21', 51.31098, -0.30106);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1267, 73, 'Leatherhead', 'KT22', 51.3007, -0.33731);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1268, 73, 'Dorking', 'KT23', 51.28137, -0.36956);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1269, 73, 'East Horsley', 'KT24', 51.26869, -0.42879);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1270, 29, 'Kingston Upon Thames', 'KT3', 51.39935, -0.25609);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1271, 29, 'Sutton', 'KT4', 51.37757, -0.24255);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1272, 29, 'Kingston Upon Thames', 'KT5', 51.39171, -0.28657);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1273, 29, 'Kingston Upon Thames', 'KT6', 51.3892, -0.2996);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1274, 73, 'Esher', 'KT7', 51.38959, -0.3269);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1275, 73, 'West Molesey', 'KT8', 51.40089, -0.36243);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1276, 29, 'Kingston Upon Thames', 'KT9', 51.36405, -0.30197);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1277, 122, '', 'KW1', 58.45801, -3.12092);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1278, 122, 'Golspie', 'KW10', 57.97509, -3.975);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1279, 122, '', 'KW11', 58.30505, -4.12991);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1280, 122, 'Halkirk', 'KW12', 58.50634, -3.49149);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1281, 122, '', 'KW13', 58.45518, -3.89556);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1282, 122, 'Thurso', 'KW14', 58.58913, -3.55523);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1283, 127, 'Kirkwall', 'KW15', 58.9803, -2.95862);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1284, 127, 'Stromness', 'KW16', 58.95963, -3.27278);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1285, 127, 'Gorseness', 'KW17', 59.04195, -3.00217);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1286, 122, 'Whaligoe', 'KW2', 58.34893, -3.16359);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1287, 122, 'Lybster', 'KW3', 58.30741, -3.27829);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1288, 122, '', 'KW5', 58.28747, -3.38163);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1289, 122, '', 'KW6', 58.24908, -3.44148);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1290, 122, '', 'KW7', 58.18641, -3.50018);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1291, 122, '', 'KW8', 58.11611, -3.6636);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1292, 122, 'Brora', 'KW9', 58.0137, -3.85692);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1293, 79, 'Kirkcaldy', 'KY1', 56.12815, -3.1375);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1294, 79, '', 'KY10', 56.23024, -2.70011);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1295, 79, '', 'KY11', 56.0471, -3.4145);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1296, 79, 'Dunfermline', 'KY12', 56.07674, -3.49272);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1297, 128, 'Kinross', 'KY13', 56.20866, -3.43173);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1298, 79, '', 'KY14', 56.31048, -3.23992);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1299, 79, '', 'KY15', 56.30055, -3.0505);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1300, 79, '', 'KY16', 56.34184, -2.81865);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1301, 79, 'Kirkcaldy', 'KY2', 56.12234, -3.18238);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1302, 79, 'Burntisland', 'KY3', 56.06346, -3.23037);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1303, 79, '', 'KY4', 56.11421, -3.36066);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1304, 79, '', 'KY5', 56.14548, -3.29416);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1305, 79, 'Glenrothes', 'KY6', 56.19678, -3.19756);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1306, 79, 'Glenrothes', 'KY7', 56.19719, -3.15405);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1307, 79, 'Leven', 'KY8', 56.19755, -3.01061);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1308, 79, 'Kilconquhar', 'KY9', 56.20965, -2.83356);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1309, 129, '', 'L1', 53.40254, -2.97928);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1310, 130, 'Aintree', 'L10', 53.47398, -2.92668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1311, 129, '', 'L11', 53.44801, -2.91407);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1312, 129, '', 'L12', 53.43467, -2.89421);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1313, 129, '', 'L13', 53.4174, -2.91943);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1314, 129, '', 'L14', 53.41861, -2.87883);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1315, 129, '', 'L15', 53.39763, -2.91901);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1316, 129, '', 'L16', 53.39876, -2.88744);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1317, 129, '', 'L17', 53.37769, -2.93962);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1318, 129, 'Garston', 'L18', 53.38064, -2.90661);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1319, 129, 'Garston', 'L19', 53.3591, -2.90165);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1320, 129, '', 'L2', 53.40696, -2.98841);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1321, 130, 'Southport', 'L20', 53.45281, -2.98797);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1322, 130, 'Southport', 'L21', 53.4707, -2.99893);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1323, 130, 'Southport', 'L22', 53.47676, -3.0262);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1324, 129, 'Crosby', 'L23', 53.49118, -3.02203);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1325, 129, 'Garston', 'L24', 53.34339, -2.83672);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1326, 129, 'Garston', 'L25', 53.37827, -2.86296);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1327, 131, 'Halewood', 'L26', 53.3641, -2.83262);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1328, 129, '', 'L27', 53.38744, -2.83758);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1329, 131, '', 'L28', 53.4349, -2.86411);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1330, 130, '', 'L29', 53.50679, -2.98319);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1331, 129, '', 'L3', 53.4088, -2.98394);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1332, 130, 'Southport', 'L30', 53.48442, -2.97062);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1333, 130, 'Maghull', 'L31', 53.51346, -2.93659);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1334, 131, 'Kirkby', 'L32', 53.47786, -2.88909);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1335, 131, 'Kirkby', 'L33', 53.48965, -2.87577);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1336, 131, '', 'L34', 53.43614, -2.81445);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1337, 132, 'Rainhill', 'L35', 53.41478, -2.78244);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1338, 131, 'Hyton', 'L36', 53.41439, -2.83962);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1339, 130, 'Southport', 'L37', 53.55735, -3.06288);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1340, 130, 'Southport', 'L38', 53.5242, -3.04998);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1341, 16, 'Ormskirk', 'L39', 53.56142, -2.89537);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1342, 129, '', 'L4', 53.43775, -2.96052);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1343, 16, 'Burscough', 'L40', 53.60227, -2.84032);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1344, 129, '', 'L5', 53.42505, -2.97529);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1345, 129, '', 'L6', 53.41896, -2.94956);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1346, 129, '', 'L69', 53.40709, -2.97337);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1347, 129, '', 'L7', 53.40549, -2.94776);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1348, 129, '', 'L70', 53.40891, -2.9704);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1349, 129, '', 'L8', 53.39009, -2.96246);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1350, 129, '', 'L9', 53.4612, -2.95201);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1351, 16, 'Lancaster', 'LA1', 54.04663, -2.79885);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1352, 60, 'Sedbergh', 'LA10', 54.31433, -2.49348);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1353, 60, 'Grange-over-Sands', 'LA11', 54.20034, -2.92446);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1354, 60, 'Ulverston', 'LA12', 54.20351, -3.08246);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1355, 60, 'Dalton-in-Furness', 'LA13', 54.11792, -3.19805);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1356, 60, 'Dalton-in-Furness', 'LA14', 54.1185, -3.2302);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1357, 60, 'Dalton Town with Newton', 'LA15', 54.15588, -3.1777);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1358, 60, 'Ireleth', 'LA16', 54.1862, -3.20155);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1359, 60, 'Kirkby Ireleth', 'LA17', 54.2386, -3.17545);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1360, 60, 'Millom', 'LA18', 54.21512, -3.27448);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1361, 60, 'Bootle', 'LA19', 54.29312, -3.37523);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1362, 16, 'Caton', 'LA2', 54.06537, -2.6739);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1363, 60, 'Broughton West', 'LA20', 54.29404, -3.20469);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1364, 60, 'Coniston', 'LA21', 54.3645, -3.07283);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1365, 60, 'Lakes', 'LA22', 54.42276, -2.98649);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1366, 60, 'Windermere', 'LA23', 54.37122, -2.91136);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1367, 16, 'Lancaster', 'LA3', 54.05058, -2.87683);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1368, 16, 'Lancaster', 'LA4', 54.06964, -2.85125);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1369, 16, 'Warton', 'LA5', 54.14287, -2.78998);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1370, 16, 'Whittingham', 'LA6', 54.17537, -2.61134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1371, 60, 'Milnthorpe', 'LA7', 54.22568, -2.77162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1372, 60, 'Kendal', 'LA8', 54.32373, -2.75961);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1373, 60, 'Kendal', 'LA9', 54.32563, -2.74273);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1374, 133, 'Llandrindod Wells', 'LD1', 52.26047, -3.3657);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1375, 133, 'Duhonw', 'LD2', 52.14145, -3.39275);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1376, 133, 'Llanddew', 'LD3', 51.96006, -3.37111);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1377, 133, 'Llangamarch', 'LD4', 52.11786, -3.55416);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1378, 133, 'Treflys', 'LD5', 52.12692, -3.61584);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1379, 133, 'Rhayader', 'LD6', 52.30909, -3.50804);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1380, 133, 'Knighton', 'LD7', 52.3524, -3.08513);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1381, 133, 'Presteigne', 'LD8', 52.26735, -3.04348);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1382, 134, '', 'LE1', 52.63379, -1.12812);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1383, 75, 'Hinckley', 'LE10', 52.53641, -1.36744);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1384, 75, 'Loughborough', 'LE11', 52.76927, -1.21584);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1385, 75, 'Loughborough', 'LE12', 52.76641, -1.19217);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1386, 75, 'Melton Mowbray', 'LE13', 52.76572, -0.88536);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1387, 75, 'Melton Mowbray', 'LE14', 52.7838, -0.89527);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1388, 135, 'Hambleton', 'LE15', 52.65594, -0.70037);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1389, 136, 'Dingley', 'LE16', 52.48616, -0.89244);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1390, 75, 'Gilmorton', 'LE17', 52.4669, -1.17706);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1391, 75, 'Oadby', 'LE18', 52.58332, -1.11141);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1392, 134, '', 'LE2', 52.60942, -1.11531);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1393, 134, '', 'LE3', 52.62876, -1.17993);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1394, 134, '', 'LE4', 52.66342, -1.12309);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1395, 134, '', 'LE5', 52.63616, -1.08521);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1396, 75, 'Groby', 'LE6', 52.66244, -1.24141);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1397, 75, 'Ashby-de-la-Zouch', 'LE65', 52.74819, -1.4681);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1398, 75, 'Coalville', 'LE67', 52.71619, -1.36041);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1399, 75, 'Barkby', 'LE7', 52.67739, -1.06808);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1400, 75, 'Kilby', 'LE8', 52.55264, -1.09728);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1401, 75, 'Hinckley', 'LE9', 52.57012, -1.28728);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1402, 137, 'Broughton', 'LL11', 53.06314, -3.03425);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1403, 137, 'Gresford', 'LL12', 53.08601, -2.98851);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1404, 137, 'Abenbury', 'LL13', 53.0359, -2.95902);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1405, 137, 'Ruabon', 'LL14', 52.99198, -3.05043);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1406, 138, 'Ruthin', 'LL15', 53.10263, -3.31455);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1407, 138, 'Denbigh', 'LL16', 53.18489, -3.43231);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1408, 138, 'St Asaph', 'LL17', 53.25319, -3.4346);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1409, 138, 'Rhyl', 'LL18', 53.31023, -3.47554);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1410, 138, 'Prestatyn', 'LL19', 53.33082, -3.40866);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1411, 138, 'Llangollen', 'LL20', 52.95949, -3.15982);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1412, 138, 'Corwen', 'LL21', 52.99006, -3.40947);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1413, 139, 'Betws-yn-Rhos', 'LL22', 53.26827, -3.59257);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1414, 140, 'Bala', 'LL23', 52.90493, -3.60003);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1415, 139, 'Bro Machno', 'LL24', 53.05695, -3.78474);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1416, 139, 'Dolwyddelan', 'LL25', 53.0546, -3.87866);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1417, 139, 'Llanrwst', 'LL26', 53.13877, -3.78514);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1418, 139, 'Trefriw', 'LL27', 53.14718, -3.82288);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1419, 139, 'Mochdre', 'LL28', 53.28749, -3.75983);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1420, 139, 'Old Colwyn', 'LL29', 53.28916, -3.70738);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1421, 139, 'Llandudno', 'LL30', 53.31813, -3.81514);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1422, 139, 'Deganwy', 'LL31', 53.29035, -3.80946);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1423, 139, 'Henryd', 'LL32', 53.26022, -3.83968);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1424, 139, 'Llanfairfechan', 'LL33', 53.24987, -3.98015);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1425, 139, 'Penmaenmawr', 'LL34', 53.27076, -3.91212);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1426, 140, 'Aberdovey', 'LL35', 52.54657, -4.04127);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1427, 140, 'Bryncrug', 'LL36', 52.60374, -4.06313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1428, 140, 'Llangelynin', 'LL37', 52.66546, -4.0823);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1429, 140, 'Arthog', 'LL38', 52.69767, -4.03943);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1430, 140, 'Arthog', 'LL39', 52.71076, -4.01043);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1431, 140, 'Brithdir', 'LL40', 52.75614, -3.87468);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1432, 140, 'Ffestiniog', 'LL41', 52.96914, -3.9375);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1433, 140, 'Barmouth', 'LL42', 52.7253, -4.05405);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1434, 140, 'Dyffryn Ardudwy', 'LL43', 52.77409, -4.09193);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1435, 140, 'Dyffryn Ardudwy', 'LL44', 52.79111, -4.09572);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1436, 140, 'Llanbedr', 'LL45', 52.81989, -4.09562);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1437, 140, 'Harlech', 'LL46', 52.85477, -4.10621);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1438, 140, 'Talsarnau', 'LL47', 52.9014, -4.06237);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1439, 140, 'Penrhyndeudraeth', 'LL48', 52.93544, -4.06994);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1440, 140, 'Porthmadog', 'LL49', 52.92883, -4.13808);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1441, 140, 'Dolbenmaen', 'LL51', 52.97377, -4.23712);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1442, 140, 'Criccieth', 'LL52', 52.92425, -4.24052);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1443, 140, 'Buan', 'LL53', 52.88418, -4.49117);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1444, 140, 'Llanllyfni', 'LL54', 53.05829, -4.28478);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1445, 140, 'Llanrug', 'LL55', 53.13355, -4.20355);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1446, 140, 'Y Felinheli', 'LL56', 53.18669, -4.19879);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1447, 140, 'Llandygai', 'LL57', 53.20718, -4.10998);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1448, 141, 'Beaumaris', 'LL58', 53.28022, -4.09857);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1449, 141, 'Cwm Cadnant', 'LL59', 53.23417, -4.15926);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1450, 141, 'Llanfihangel Ysgeifiog', 'LL60', 53.21505, -4.26915);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1451, 141, 'Llanidan', 'LL61', 53.1954, -4.26212);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1452, 141, 'Bodorgan', 'LL62', 53.21007, -4.38572);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1453, 141, 'Aberffraw', 'LL63', 53.21824, -4.47007);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1454, 141, 'Rhosneigr', 'LL64', 53.22805, -4.51709);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1455, 141, 'Valley', 'LL65', 53.30067, -4.5694);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1456, 141, 'Rhosybol', 'LL66', 53.38055, -4.40427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1457, 141, 'Llanbadrig', 'LL67', 53.41097, -4.45565);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1458, 141, 'Amlwch', 'LL68', 53.39818, -4.37668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1459, 141, 'Penysarn', 'LL69', 53.38583, -4.31883);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1460, 141, 'Moelfre', 'LL70', 53.36396, -4.28758);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1461, 141, 'Llannerch-Y-Medd', 'LL71', 53.32732, -4.36823);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1462, 141, 'Moelfre', 'LL72', 53.34957, -4.24023);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1463, 141, 'Llaneugrad', 'LL73', 53.33511, -4.24397);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1464, 141, 'Llanfair-Mathafarn-Eithaf', 'LL74', 53.31645, -4.23248);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1465, 141, 'Pentraeth', 'LL75', 53.28343, -4.21876);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1466, 141, 'Llanfair-Mathafarn-Eithaf', 'LL76', 53.30017, -4.23764);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1467, 141, 'Llangefni', 'LL77', 53.26011, -4.31053);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1468, 141, 'Llanfair-Mathafarn-Eithaf', 'LL78', 53.31678, -4.26253);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1469, 90, 'Burton', 'LN1', 53.25883, -0.58621);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1470, 90, 'Woodhall Spa', 'LN10', 53.15858, -0.21703);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1471, 90, 'Louth', 'LN11', 53.3732, 0.02496);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1472, 90, 'Mablethorpe', 'LN12', 53.3293, 0.2662);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1473, 90, 'Alford', 'LN13', 53.26518, 0.18482);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1474, 90, 'Nettleham', 'LN2', 53.25429, -0.5084);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1475, 90, 'Fiskerton', 'LN3', 53.24325, -0.41885);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1476, 90, 'Dunston', 'LN4', 53.15018, -0.38489);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1477, 90, 'Waddington', 'LN5', 53.17126, -0.55617);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1478, 90, 'Lincoln', 'LN6', 53.20319, -0.59403);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1479, 90, 'Caistor', 'LN7', 53.49216, -0.34327);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1480, 90, 'Linwood', 'LN8', 53.37321, -0.32384);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1481, 90, 'Horncastle', 'LN9', 53.21719, -0.11124);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1482, 142, '', 'LS1', 53.79674, -1.54754);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1483, 142, '', 'LS10', 53.76162, -1.53123);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1484, 142, '', 'LS11', 53.77609, -1.55535);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1485, 142, '', 'LS12', 53.79062, -1.59618);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1486, 142, '', 'LS13', 53.81052, -1.63396);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1487, 142, '', 'LS14', 53.82782, -1.45604);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1488, 142, '', 'LS15', 53.80619, -1.44417);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1489, 142, '', 'LS16', 53.85086, -1.60169);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1490, 142, 'Harewood', 'LS17', 53.85958, -1.52709);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1491, 142, '', 'LS18', 53.8402, -1.6413);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1492, 142, 'Guiseley', 'LS19', 53.8592, -1.6822);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1493, 142, '', 'LS2', 53.80123, -1.54597);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1494, 142, 'Guiseley', 'LS20', 53.87365, -1.71251);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1495, 142, 'Otley', 'LS21', 53.91132, -1.67876);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1496, 142, 'Wetherby', 'LS22', 53.93179, -1.39375);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1497, 142, 'Boston Spa', 'LS23', 53.90372, -1.35458);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1498, 19, 'Grimston', 'LS24', 53.86987, -1.25168);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1499, 142, 'Micklefield', 'LS25', 53.78584, -1.33059);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1500, 142, 'Rothwell', 'LS26', 53.75227, -1.44791);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1501, 142, 'Gildersome', 'LS27', 53.74839, -1.60266);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1502, 142, '', 'LS28', 53.80163, -1.66897);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1503, 17, 'Ilkley', 'LS29', 53.92058, -1.80356);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1504, 142, '', 'LS3', 53.80128, -1.55964);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1505, 142, '', 'LS4', 53.80944, -1.58082);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1506, 142, '', 'LS5', 53.81851, -1.60199);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1507, 142, '', 'LS6', 53.81928, -1.56704);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1508, 142, '', 'LS7', 53.81828, -1.53971);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1509, 142, '', 'LS8', 53.82445, -1.50926);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1510, 142, '', 'LS9', 53.79928, -1.50803);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1511, 143, '', 'LU1', 51.87476, -0.42373);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1512, 143, '', 'LU2', 51.89147, -0.39553);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1513, 143, '', 'LU3', 51.90829, -0.44291);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1514, 143, '', 'LU4', 51.89871, -0.4665);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1515, 144, 'Thorn', 'LU5', 51.90829, -0.5127);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1516, 144, 'Dunstable', 'LU6', 51.87711, -0.53552);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1517, 144, 'Leighton-Linslade', 'LU7', 51.90921, -0.66388);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1518, 145, 'Manchester', 'M1', 53.47734, -2.23508);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1519, 145, 'Manchester', 'M11', 53.47834, -2.17933);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1520, 145, 'Manchester', 'M12', 53.46482, -2.20187);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1521, 145, 'Manchester', 'M13', 53.4603, -2.21389);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1522, 145, 'Manchester', 'M14', 53.4477, -2.22437);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1523, 145, 'Manchester', 'M15', 53.46563, -2.25008);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1524, 145, 'Manchester', 'M16', 53.45481, -2.26357);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1525, 146, 'Urmston', 'M17', 53.46906, -2.31789);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1526, 145, 'Manchester', 'M18', 53.46127, -2.16871);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1527, 145, 'Manchester', 'M19', 53.43696, -2.19421);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1528, 145, 'Manchester', 'M2', 53.48003, -2.24263);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1529, 145, 'Manchester', 'M20', 53.42521, -2.23027);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1530, 145, 'Manchester', 'M21', 53.43771, -2.27099);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1531, 145, 'Manchester', 'M22', 53.3856, -2.25863);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1532, 145, 'Manchester', 'M23', 53.39902, -2.28729);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1533, 147, 'Middleton', 'M24', 53.55113, -2.19624);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1534, 24, '', 'M25', 53.5285, -2.27459);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1535, 24, '', 'M26', 53.56161, -2.33369);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1536, 148, '', 'M27', 53.51216, -2.33631);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1537, 148, 'Walkden', 'M28', 53.51467, -2.39666);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1538, 149, 'Pemberton', 'M29', 53.50816, -2.45692);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1539, 148, '', 'M3', 53.48361, -2.25018);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1540, 148, '', 'M30', 53.48424, -2.35418);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1541, 146, 'Partington', 'M31', 53.4193, -2.42136);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1542, 146, 'Urmston', 'M32', 53.45021, -2.30872);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1543, 146, '', 'M33', 53.4205, -2.32506);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1544, 150, 'Ashton-under-Lyne', 'M34', 53.45594, -2.11748);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1545, 151, '', 'M35', 53.50714, -2.1523);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1546, 148, 'Walkden', 'M38', 53.53167, -2.42096);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1547, 145, 'Manchester', 'M4', 53.48455, -2.22909);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1548, 145, 'Manchester', 'M40', 53.50349, -2.18999);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1549, 146, 'Urmston', 'M41', 53.45095, -2.36294);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1550, 150, 'Ashton-under-Lyne', 'M43', 53.48378, -2.1477);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1551, 148, '', 'M44', 53.44086, -2.42609);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1552, 24, '', 'M45', 53.54734, -2.28829);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1553, 149, 'Pemberton', 'M46', 53.52601, -2.49031);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1554, 148, '', 'M5', 53.47903, -2.28482);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1555, 148, '', 'M6', 53.49159, -2.29696);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1556, 145, 'Manchester', 'M60', 53.48635, -2.22759);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1557, 148, '', 'M7', 53.50516, -2.26086);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1558, 145, 'Manchester', 'M8', 53.5088, -2.23827);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1559, 145, 'Manchester', 'M9', 53.52143, -2.21269);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1560, 145, 'Ringway', 'M90', 53.36309, -2.27653);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1561, 152, 'Rochester', 'ME1', 51.37216, 0.50017);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1562, 30, 'Sittingbourne', 'ME10', 51.34258, 0.73697);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1563, 30, 'Queenborough', 'ME11', 51.41247, 0.74833);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1564, 30, 'Sittingbourne', 'ME12', 51.42282, 0.80507);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1565, 30, 'Faversham', 'ME13', 51.30275, 0.89675);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1566, 30, 'Maidstone', 'ME14', 51.28043, 0.54108);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1567, 30, 'Maidstone', 'ME15', 51.2545, 0.53392);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1568, 30, 'Maidstone', 'ME16', 51.27414, 0.49915);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1569, 30, 'Leeds', 'ME17', 51.23484, 0.61021);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1570, 30, 'West Farleigh', 'ME18', 51.24426, 0.42301);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1571, 30, 'West Malling', 'ME19', 51.29307, 0.41123);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1572, 152, 'Strood', 'ME2', 51.39136, 0.4854);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1573, 30, 'Ditton', 'ME20', 51.30467, 0.45919);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1574, 152, 'Hoo St Werburgh', 'ME3', 51.43322, 0.54668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1575, 152, 'Rochester', 'ME4', 51.3805, 0.53081);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1576, 152, 'Rochester', 'ME5', 51.34896, 0.53338);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1577, 30, 'Snodland', 'ME6', 51.32662, 0.4417);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1578, 152, 'Gillingham', 'ME7', 51.37904, 0.5566);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1579, 152, 'Gillingham', 'ME8', 51.36102, 0.5987);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1580, 30, 'Sittingbourne', 'ME9', 51.33297, 0.72491);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1581, 153, 'Bletchley', 'MK1', 52.00522, -0.72659);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1582, 153, '', 'MK10', 52.03908, -0.69792);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1583, 153, 'Stony Stratford', 'MK11', 52.05226, -0.84048);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1584, 153, 'Stony Stratford', 'MK12', 52.05741, -0.81555);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1585, 153, 'Bradwell', 'MK13', 52.05258, -0.78359);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1586, 153, 'Stantonbury', 'MK14', 52.05955, -0.76152);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1587, 153, 'Willen', 'MK15', 52.05739, -0.72802);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1588, 153, 'Newport Pagnell', 'MK16', 52.08879, -0.72129);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1589, 153, 'Bow Brickhill', 'MK17', 51.99235, -0.70074);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1590, 154, '', 'MK18', 51.97972, -0.96904);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1591, 136, 'Cosgrove', 'MK19', 52.07215, -0.85164);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1592, 153, 'Bletchley', 'MK2', 51.98991, -0.72411);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1593, 153, 'Bletchley', 'MK3', 51.99651, -0.75306);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1594, 153, 'Shenley Brook End', 'MK4', 52.00397, -0.77762);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1595, 155, 'Bedford', 'MK40', 52.13797, -0.47145);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1596, 155, 'Bedford', 'MK41', 52.15113, -0.44614);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1597, 155, 'Kempston', 'MK42', 52.12002, -0.47352);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1598, 155, 'Kempston Rural', 'MK43', 52.11837, -0.55684);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1599, 155, 'Wilden', 'MK44', 52.19402, -0.42563);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1600, 144, 'Maulden', 'MK45', 52.02462, -0.46803);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1601, 153, 'Clifton Reynes', 'MK46', 52.15411, -0.69165);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1602, 153, 'Shenley Church End', 'MK5', 52.02021, -0.78301);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1603, 153, 'Woughton On The Green', 'MK6', 52.02967, -0.74193);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1604, 153, 'Walton', 'MK7', 52.01921, -0.68976);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1605, 153, 'Bradwell Abbey', 'MK8', 52.0357, -0.803);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1606, 153, '', 'MK9', 52.04064, -0.75912);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1607, 109, 'Motherwell', 'ML1', 55.79943, -3.97512);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1608, 110, 'Strathaven', 'ML10', 55.68013, -4.06932);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1609, 110, 'New Lanark', 'ML11', 55.66661, -3.78555);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1610, 110, '', 'ML12', 55.56677, -3.59544);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1611, 109, 'Wishaw', 'ML2', 55.77706, -3.91179);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1612, 110, 'Hamilton', 'ML3', 55.77028, -4.05337);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1613, 109, 'Motherwell', 'ML4', 55.81846, -4.02078);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1614, 109, 'Coatbridge', 'ML5', 55.85964, -4.03091);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1615, 109, 'Airdrie', 'ML6', 55.86704, -3.96257);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1616, 109, '', 'ML7', 55.83008, -3.79303);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1617, 110, 'Carluke', 'ML8', 55.7305, -3.84103);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1618, 110, 'Larkhall', 'ML9', 55.72496, -3.96658);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1619, 29, 'Islington', 'N1', 51.53717, -0.09652);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1620, 29, 'Tottenham', 'N10', 51.59368, -0.14325);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1621, 29, 'Enfield', 'N11', 51.61338, -0.13812);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1622, 29, 'Barnet', 'N12', 51.61487, -0.17561);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1623, 29, 'Enfield', 'N13', 51.6191, -0.10176);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1624, 29, 'Enfield', 'N14', 51.63392, -0.1286);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1625, 29, 'Tottenham', 'N15', 51.5819, -0.08166);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1626, 29, 'Hackney', 'N16', 51.5629, -0.07525);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1627, 29, 'Tottenham', 'N17', 51.59791, -0.07088);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1628, 29, 'Enfield', 'N18', 51.61309, -0.06446);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1629, 29, 'Islington', 'N19', 51.56464, -0.12712);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1630, 29, 'Barnet', 'N2', 51.58957, -0.16797);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1631, 29, 'Barnet', 'N20', 51.62923, -0.17359);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1632, 29, 'Enfield', 'N21', 51.63612, -0.09816);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1633, 29, 'Tottenham', 'N22', 51.59944, -0.1098);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1634, 29, 'Barnet', 'N3', 51.59984, -0.1921);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1635, 29, 'Hackney', 'N4', 51.57052, -0.1009);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1636, 29, 'Islington', 'N5', 51.55337, -0.09729);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1637, 29, 'Tottenham', 'N6', 51.57116, -0.14129);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1638, 29, 'Islington', 'N7', 51.55277, -0.11607);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1639, 29, 'Tottenham', 'N8', 51.58335, -0.11625);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1640, 29, 'Enfield', 'N9', 51.62825, -0.05659);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1641, 156, '', 'NE1', 54.97262, -1.61097);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1642, 157, '', 'NE10', 54.94726, -1.55345);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1643, 157, 'Wickham and Dunston', 'NE11', 54.94123, -1.63157);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1644, 158, 'Longbenton', 'NE12', 55.0246, -1.56823);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1645, 156, 'Brunswick', 'NE13', 55.04642, -1.64469);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1646, 156, 'Newburn', 'NE15', 54.9837, -1.72026);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1647, 157, 'Wickham and Dunston', 'NE16', 54.9324, -1.69096);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1648, 157, 'Blaydon', 'NE17', 54.91378, -1.81591);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1649, 159, 'Stamfordham', 'NE18', 55.03787, -1.86072);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1650, 159, 'Elsdon', 'NE19', 55.17901, -2.0958);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1651, 156, 'Byker', 'NE2', 54.98698, -1.60458);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1652, 159, 'Ponteland', 'NE20', 55.05304, -1.78553);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1653, 157, 'Blaydon', 'NE21', 54.95764, -1.71888);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1654, 159, 'Wansbeck', 'NE22', 55.1361, -1.58428);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1655, 159, 'Blyth', 'NE23', 55.08037, -1.58173);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1656, 159, 'Blyth', 'NE24', 55.12238, -1.52013);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1657, 158, '', 'NE25', 55.04945, -1.48656);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1658, 158, '', 'NE26', 55.05201, -1.45679);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1659, 158, '', 'NE27', 55.03247, -1.51025);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1660, 158, '', 'NE28', 55.00015, -1.51846);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1661, 158, '', 'NE29', 55.0116, -1.46359);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1662, 156, '', 'NE3', 55.01043, -1.6325);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1663, 158, '', 'NE30', 55.02138, -1.44);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1664, 160, '', 'NE31', 54.97136, -1.511);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1665, 160, '', 'NE32', 54.96765, -1.48292);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1666, 160, '', 'NE33', 54.99077, -1.42792);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1667, 160, '', 'NE34', 54.97186, -1.42037);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1668, 160, '', 'NE35', 54.95227, -1.4597);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1669, 160, '', 'NE36', 54.94498, -1.43794);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1670, 84, 'Washington', 'NE37', 54.913, -1.52574);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1671, 84, 'Washington', 'NE38', 54.89412, -1.52441);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1672, 157, 'Blaydon', 'NE39', 54.92357, -1.75813);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1673, 156, '', 'NE4', 54.97361, -1.64221);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1674, 157, 'Blaydon', 'NE40', 54.96584, -1.77193);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1675, 159, 'Wylam', 'NE41', 54.9758, -1.81875);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1676, 159, 'Prudhoe', 'NE42', 54.96237, -1.85474);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1677, 159, 'Stocksfield', 'NE43', 54.94804, -1.90475);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1678, 159, 'Broomhaugh and Riding', 'NE44', 54.94268, -1.97814);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1679, 159, 'Corbridge', 'NE45', 54.97683, -2.01563);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1680, 159, 'Hexham', 'NE46', 54.97948, -2.10626);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1681, 159, 'Allendale', 'NE47', 54.92894, -2.25127);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1682, 159, 'Bellingham', 'NE48', 55.13114, -2.25724);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1683, 159, 'Haltwhistle', 'NE49', 54.96698, -2.45927);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1684, 156, 'Newburn', 'NE5', 54.99621, -1.68735);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1685, 156, 'Byker', 'NE6', 54.97695, -1.56405);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1686, 159, 'Morpeth', 'NE61', 55.18045, -1.68905);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1687, 159, 'Wansbeck', 'NE62', 55.16129, -1.59187);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1688, 159, 'Wansbeck', 'NE63', 55.17736, -1.56187);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1689, 159, 'Wansbeck', 'NE64', 55.18437, -1.51467);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1690, 159, 'Newton on the Moor', 'NE65', 55.3127, -1.75104);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1691, 159, 'Denwick', 'NE66', 55.42858, -1.73135);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1692, 159, 'Ellingham', 'NE67', 55.53363, -1.6926);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1693, 159, 'North Sunderland', 'NE68', 55.57398, -1.65739);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1694, 159, 'Bamburgh', 'NE69', 55.60468, -1.71586);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1695, 156, 'Byker', 'NE7', 54.99947, -1.57788);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1696, 159, 'Belford', 'NE70', 55.59409, -1.81591);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1697, 159, 'Akeld', 'NE71', 55.55558, -2.04439);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1698, 157, '', 'NE8', 54.95552, -1.60333);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1699, 157, '', 'NE9', 54.93118, -1.58328);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1700, 156, '', 'NE99', 54.96723, -1.61259);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1701, 161, '', 'NG1', 52.954, -1.147);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1702, 81, 'Ilkeston', 'NG10', 52.90005, -1.28187);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1703, 161, 'Clifton', 'NG11', 52.89934, -1.17335);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1704, 87, 'Cotgrave', 'NG12', 52.91104, -1.05415);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1705, 87, 'Bingham', 'NG13', 52.94767, -0.92087);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1706, 87, 'Lowdham', 'NG14', 53.01519, -1.03696);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1707, 87, 'Sutton in Ashfield', 'NG15', 53.04519, -1.20338);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1708, 87, 'Greasley', 'NG16', 53.02688, -1.29319);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1709, 87, 'Sutton in Ashfield', 'NG17', 53.11569, -1.26035);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1710, 87, 'Mansfield', 'NG18', 53.13766, -1.18373);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1711, 87, 'Mansfield', 'NG19', 53.15933, -1.19678);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1712, 87, 'West Bridgford', 'NG2', 52.935, -1.131);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1713, 87, 'Warsop', 'NG20', 53.20958, -1.18386);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1714, 87, 'Rainworth', 'NG21', 53.14069, -1.10443);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1715, 87, 'Ompton', 'NG22', 53.17826, -0.97046);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1716, 87, 'North Muskham', 'NG23', 53.11553, -0.80012);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1717, 87, 'Newark-on-Trent', 'NG24', 53.06966, -0.79841);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1718, 87, 'Southwell', 'NG25', 53.07294, -0.95506);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1719, 161, '', 'NG3', 52.96735, -1.12887);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1720, 90, 'Grantham', 'NG31', 52.9142, -0.6391);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1721, 90, 'Great Gonerby', 'NG32', 52.94939, -0.64991);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1722, 90, 'Burton Coggles', 'NG33', 52.81819, -0.57829);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1723, 90, 'Sleaford', 'NG34', 52.98753, -0.39096);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1724, 87, 'Carlton', 'NG4', 52.97062, -1.08561);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1725, 161, '', 'NG5', 52.99713, -1.14317);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1726, 161, '', 'NG6', 52.99746, -1.19085);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1727, 161, '', 'NG7', 52.95779, -1.17521);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1728, 161, '', 'NG8', 52.96434, -1.21231);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1729, 87, 'Beeston', 'NG9', 52.92583, -1.23533);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1730, 136, 'Northampton', 'NN1', 52.24154, -0.88682);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1731, 136, 'Rushden', 'NN10', 52.2915, -0.59668);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1732, 136, 'Badby', 'NN11', 52.24033, -1.17833);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1733, 136, 'Towcester', 'NN12', 52.12744, -0.99778);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1734, 136, 'Brackley', 'NN13', 52.0324, -1.14715);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1735, 136, 'Warkton', 'NN14', 52.40948, -0.69145);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1736, 136, 'Kettering', 'NN15', 52.38446, -0.70542);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1737, 136, 'Kettering', 'NN16', 52.40531, -0.72098);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1738, 136, 'Corby', 'NN17', 52.50026, -0.68876);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1739, 136, 'Corby', 'NN18', 52.47986, -0.7144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1740, 136, 'Northampton', 'NN2', 52.2623, -0.89509);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1741, 136, 'Wollaston', 'NN29', 52.2599, -0.66362);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1742, 136, 'Northampton', 'NN3', 52.26182, -0.84528);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1743, 136, 'Northampton', 'NN4', 52.21645, -0.89623);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1744, 136, 'Duston', 'NN5', 52.24732, -0.92916);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1745, 136, 'Spratton', 'NN6', 52.32208, -0.9435);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1746, 136, 'Northampton', 'NN7', 52.20954, -0.92714);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1747, 136, 'Wellingborough', 'NN8', 52.30254, -0.69754);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1748, 136, 'Irthlingborough', 'NN9', 52.33288, -0.59831);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1749, 162, 'Graig', 'NP10', 51.57943, -3.04497);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1750, 69, 'Abercarn', 'NP11', 51.64249, -3.13025);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1751, 69, 'Blackwood', 'NP12', 51.6688, -3.19743);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1752, 163, 'Abertillery', 'NP13', 51.73412, -3.13977);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1753, 164, 'Gwehelog Fawr', 'NP15', 51.72552, -2.88616);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1754, 164, 'St Arvans', 'NP16', 51.64951, -2.68808);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1755, 162, 'Caerleon', 'NP18', 51.60637, -2.94305);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1756, 162, 'Alway', 'NP19', 51.58913, -2.9629);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1757, 162, 'Allt-yr-yn', 'NP20', 51.59057, -3.0048);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1758, 163, 'Tredegar', 'NP22', 51.7707, -3.25665);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1759, 163, 'Ebbw Vale', 'NP23', 51.78482, -3.19615);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1760, 69, 'New Tredegar', 'NP24', 51.71964, -3.23786);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1761, 164, 'Monmouth', 'NP25', 51.80307, -2.72232);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1762, 164, 'Rogiet', 'NP26', 51.59051, -2.77669);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1763, 165, 'Trevethin', 'NP4', 51.71882, -3.04528);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1764, 165, 'Cwmbran', 'NP44', 51.65064, -3.02637);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1765, 164, 'Abergavenny', 'NP7', 51.82884, -3.00864);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1766, 133, 'Llangattock', 'NP8', 51.85996, -3.14586);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1767, 121, 'Norwich', 'NR1', 52.62671, 1.31012);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1768, 121, 'Hevingham', 'NR10', 52.73642, 1.24582);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1769, 121, 'Erpingham', 'NR11', 52.84173, 1.27596);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1770, 121, 'Smallburgh', 'NR12', 52.75971, 1.47144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1771, 121, 'Blofield', 'NR13', 52.63372, 1.47327);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1772, 121, 'Alpington', 'NR14', 52.56445, 1.3807);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1773, 121, 'Hempnall', 'NR15', 52.50639, 1.2701);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1774, 121, 'Old Buckenham', 'NR16', 52.476, 1.06162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1775, 121, 'Attleborough', 'NR17', 52.51544, 0.99655);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1776, 121, 'Wymondham', 'NR18', 52.57095, 1.11105);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1777, 121, 'Scarning', 'NR19', 52.67542, 0.92907);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1778, 121, 'Norwich', 'NR2', 52.6301, 1.28524);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1779, 121, 'Swanton Morley', 'NR20', 52.72449, 0.98124);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1780, 121, 'Fakenham', 'NR21', 52.84097, 0.85257);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1781, 121, 'Walsingham', 'NR22', 52.89366, 0.86793);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1782, 121, 'Wells-next-the-Sea', 'NR23', 52.94872, 0.85966);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1783, 121, 'Briston', 'NR24', 52.85851, 1.05135);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1784, 121, 'Holt', 'NR25', 52.91969, 1.08541);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1785, 121, 'Sheringham', 'NR26', 52.93511, 1.21602);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1786, 121, 'Cromer', 'NR27', 52.92467, 1.30157);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1787, 121, 'North Walsham', 'NR28', 52.82203, 1.40068);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1788, 121, 'Great Yarmouth', 'NR29', 52.6926, 1.63932);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1789, 121, 'Norwich', 'NR3', 52.64332, 1.29511);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1790, 121, 'Great Yarmouth', 'NR30', 52.61874, 1.72926);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1791, 121, 'Great Yarmouth', 'NR31', 52.57614, 1.71087);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1792, 63, 'Oulton Broad', 'NR32', 52.48903, 1.73448);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1793, 63, 'Oulton Broad', 'NR33', 52.45441, 1.71976);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1794, 63, 'Weston', 'NR34', 52.43791, 1.58442);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1795, 63, 'Bungay', 'NR35', 52.46125, 1.43463);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1796, 121, 'Norwich', 'NR4', 52.61357, 1.26479);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1797, 121, 'Norwich', 'NR5', 52.6405, 1.23427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1798, 121, 'Norwich', 'NR6', 52.66074, 1.2831);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1799, 121, 'Taverham', 'NR8', 52.67798, 1.21188);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1800, 121, 'Marlingford', 'NR9', 52.63574, 1.10973);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1801, 29, 'Camden Town', 'NW1', 51.53252, -0.14286);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1802, 29, 'Brent', 'NW10', 51.53951, -0.24641);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1803, 29, 'Barnet', 'NW11', 51.57831, -0.19584);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1804, 29, 'Brent', 'NW2', 51.55797, -0.21829);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1805, 29, 'Camden Town', 'NW3', 51.55184, -0.17093);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1806, 29, 'Barnet', 'NW4', 51.58682, -0.22294);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1807, 29, 'Camden Town', 'NW5', 51.55139, -0.14209);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1808, 29, 'Camden Town', 'NW6', 51.54142, -0.19442);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1809, 29, 'Barnet', 'NW7', 51.61488, -0.23484);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1810, 29, 'Paddington', 'NW8', 51.53117, -0.17175);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1811, 29, 'Brent', 'NW9', 51.5864, -0.25472);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1812, 151, '', 'OL1', 53.54944, -2.10566);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1813, 147, 'Heywood', 'OL10', 53.59064, -2.22211);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1814, 147, '', 'OL11', 53.606, -2.17382);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1815, 147, '', 'OL12', 53.63567, -2.16487);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1816, 16, 'Rawtenstall', 'OL13', 53.70034, -2.20299);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1817, 115, 'Todmorden', 'OL14', 53.71395, -2.0985);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1818, 147, '', 'OL15', 53.64384, -2.09985);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1819, 147, '', 'OL16', 53.61234, -2.13152);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1820, 151, 'Shaw', 'OL2', 53.57191, -2.10874);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1821, 151, 'Saddleworth', 'OL3', 53.55309, -2.00906);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1822, 151, '', 'OL4', 53.54228, -2.07244);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1823, 150, 'Mossley', 'OL5', 53.51712, -2.03771);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1824, 150, 'Ashton-under-Lyne', 'OL6', 53.49372, -2.08593);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1825, 150, 'Ashton-under-Lyne', 'OL7', 53.49011, -2.10552);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1826, 151, '', 'OL8', 53.52606, -2.11616);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1827, 151, '', 'OL9', 53.53952, -2.14186);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1828, 166, 'Oxford', 'OX1', 51.74451, -1.25978);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1829, 166, 'Wallingford', 'OX10', 51.60781, -1.12625);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1830, 166, 'Didcot', 'OX11', 51.59965, -1.24626);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1831, 166, 'Wantage', 'OX12', 51.59437, -1.42537);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1832, 166, 'Marcham', 'OX13', 51.67849, -1.34765);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1833, 166, 'Culham', 'OX14', 51.66728, -1.2755);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1834, 166, 'Tadmarton', 'OX15', 52.03219, -1.40666);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1835, 166, 'Banbury', 'OX16', 52.06241, -1.34061);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1836, 136, 'Middleton Cheney', 'OX17', 52.07291, -1.28938);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1837, 166, 'Carterton', 'OX18', 51.76232, -1.59134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1838, 166, 'Oxford', 'OX2', 51.7644, -1.27685);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1839, 166, 'Woodstock', 'OX20', 51.85659, -1.35814);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1840, 166, 'Chesterton', 'OX25', 51.90067, -1.21216);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1841, 166, 'Bicester', 'OX26', 51.90114, -1.15109);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1842, 166, 'Fringford', 'OX27', 51.93709, -1.14751);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1843, 166, 'Witney', 'OX28', 51.78529, -1.48675);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1844, 166, 'Eynsham', 'OX29', 51.79403, -1.43154);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1845, 166, 'Oxford', 'OX3', 51.76131, -1.21458);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1846, 166, 'Holton', 'OX33', 51.75813, -1.14653);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1847, 166, 'Chinnor', 'OX39', 51.70045, -0.91317);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1848, 166, 'Oxford', 'OX4', 51.72984, -1.21513);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1849, 166, 'Cuddesdon', 'OX44', 51.70046, -1.13025);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1850, 166, 'Watlington', 'OX49', 51.64996, -0.99967);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1851, 166, 'Kidlington', 'OX5', 51.82917, -1.28016);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1852, 166, 'Bicester', 'OX6', 51.90845, -1.16695);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1853, 166, 'Chadlington', 'OX7', 51.91135, -1.52747);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1854, 166, 'South Leigh', 'OX8', 51.78964, -1.4548);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1855, 166, 'Thame', 'OX9', 51.73794, -0.9818);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1856, 167, 'Paisley', 'PA1', 55.84457, -4.41674);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1857, 167, 'Kilbarchan', 'PA10', 55.83375, -4.55184);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1858, 167, 'Ranfurly', 'PA11', 55.85649, -4.5821);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1859, 167, 'Lochwinnoch', 'PA12', 55.7954, -4.62273);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1860, 168, 'Kilmacolm', 'PA13', 55.89235, -4.62927);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1861, 168, 'Greenock', 'PA14', 55.92757, -4.66368);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1862, 168, 'Greenock', 'PA15', 55.94279, -4.74802);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1863, 168, 'Greenock', 'PA16', 55.94351, -4.79613);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1864, 126, 'Skelmorlie', 'PA17', 55.86512, -4.88162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1865, 168, 'Wemyss Bay', 'PA18', 55.88928, -4.88661);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1866, 168, 'Greenock', 'PA19', 55.9528, -4.82244);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1867, 167, 'Paisley', 'PA2', 55.82896, -4.43334);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1868, 111, 'Rothesay', 'PA20', 55.83482, -5.0567);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1869, 111, 'Tighnabruaich', 'PA21', 55.90186, -5.24762);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1870, 111, '', 'PA22', 55.97074, -5.1572);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1871, 111, 'Port Riddell', 'PA23', 55.95474, -4.93154);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1872, 111, 'Lochgoilhead', 'PA24', 56.15675, -4.90504);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1873, 111, '', 'PA25', 56.21553, -5.04017);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1874, 111, 'Cairndow', 'PA26', 56.25758, -4.9369);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1875, 111, 'Strachur', 'PA27', 56.15422, -5.08365);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1876, 111, '', 'PA28', 55.43603, -5.60305);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1877, 111, '', 'PA29', 55.80476, -5.47741);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1878, 167, 'Paisley', 'PA3', 55.85205, -4.44757);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1879, 111, 'Ardrishaig', 'PA30', 56.0133, -5.44799);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1880, 111, '', 'PA31', 56.05245, -5.46273);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1881, 111, '', 'PA32', 56.20284, -5.11658);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1882, 111, '', 'PA33', 56.36978, -5.05569);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1883, 111, '', 'PA34', 56.4021, -5.49931);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1884, 111, '', 'PA35', 56.40507, -5.22391);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1885, 111, 'Bridge of Orchy', 'PA36', 56.52032, -4.77019);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1886, 111, '', 'PA37', 56.46816, -5.38681);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1887, 111, '', 'PA38', 56.59186, -5.33433);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1888, 167, 'Renfrew', 'PA4', 55.87464, -4.39623);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1889, 111, '', 'PA41', 55.6747, -5.74115);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1890, 111, 'Port Ellen', 'PA42', 55.63962, -6.18624);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1891, 111, 'Bowmore', 'PA43', 55.7559, -6.28324);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1892, 111, 'Blackrock', 'PA44', 55.79785, -6.29265);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1893, 111, 'Ballygrant', 'PA45', 55.81932, -6.1656);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1894, 111, 'Port Askaig', 'PA46', 55.86226, -6.11902);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1895, 111, 'Portnahaven', 'PA47', 55.68236, -6.50288);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1896, 111, 'Port Charlotte', 'PA48', 55.73797, -6.38332);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1897, 111, '', 'PA49', 55.7826, -6.39313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1898, 167, 'Johnstone', 'PA5', 55.83105, -4.50854);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1899, 167, '', 'PA6', 55.86377, -4.53462);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1900, 111, '', 'PA60', 55.87979, -5.91287);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1901, 111, 'Scalasaig', 'PA61', 56.07177, -6.20088);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1902, 111, '', 'PA62', 56.35932, -5.85014);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1903, 111, '', 'PA63', 56.38234, -5.71469);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1904, 111, 'Lochdon', 'PA64', 56.43838, -5.67471);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1905, 111, '', 'PA65', 56.46916, -5.72805);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1906, 111, '', 'PA66', 56.32913, -6.35382);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1907, 111, 'Bunessan', 'PA67', 56.31356, -6.23228);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1908, 111, '', 'PA68', 56.43624, -6.14202);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1909, 111, '', 'PA69', 56.38044, -6.08894);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1910, 167, 'Bishopton', 'PA7', 55.90944, -4.49919);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1911, 111, '', 'PA70', 56.36426, -6.03373);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1912, 111, '', 'PA71', 56.48108, -5.98112);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1913, 111, '', 'PA72', 56.51761, -5.96381);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1914, 111, '', 'PA73', 56.49693, -6.18279);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1915, 111, '', 'PA74', 56.53313, -6.22911);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1916, 111, '', 'PA75', 56.61228, -6.12216);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1917, 111, '', 'PA76', 56.33403, -6.39324);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1918, 111, 'Crossapol', 'PA77', 56.49469, -6.8835);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1919, 111, '', 'PA78', 56.62454, -6.54449);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1920, 167, '', 'PA8', 55.9014, -4.45228);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1921, 167, 'Howwood', 'PA9', 55.80948, -4.55184);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1922, 169, '', 'PE1', 52.58704, -0.23885);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1923, 90, 'Bourne', 'PE10', 52.77693, -0.3765);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1924, 90, 'Pinchbeck', 'PE11', 52.80714, -0.16616);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1925, 90, 'Fleet', 'PE12', 52.78328, 0.0286);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1926, 61, 'Wisbech', 'PE13', 52.66895, 0.13868);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1927, 121, 'Emneth', 'PE14', 52.63884, 0.21112);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1928, 61, 'March', 'PE15', 52.53589, 0.08649);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1929, 61, 'Chatteris', 'PE16', 52.45379, 0.05022);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1930, 61, 'St Neots', 'PE19', 52.24203, -0.2584);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1931, 169, '', 'PE2', 52.56043, -0.26352);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1932, 90, 'Swineshead', 'PE20', 52.932, -0.10136);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1933, 90, 'Boston', 'PE21', 52.97477, -0.02203);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1934, 90, 'Old Leake', 'PE22', 53.04826, 0.0455);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1935, 90, 'Spilsby', 'PE23', 53.17244, 0.09181);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1936, 90, 'Burgh Le Marsh', 'PE24', 53.16561, 0.26804);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1937, 90, 'Skegness', 'PE25', 53.15261, 0.33616);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1938, 61, 'Ramsey', 'PE26', 52.45292, -0.1132);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1939, 61, 'St Ives', 'PE27', 52.33361, -0.07572);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1940, 61, 'The Stukeleys', 'PE28', 52.35784, -0.18629);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1941, 61, 'Huntingdon', 'PE29', 52.33345, -0.17848);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1942, 169, '', 'PE3', 52.58758, -0.27573);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1943, 121, 'King\'s Lynn', 'PE30', 52.75978, 0.41884);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1944, 121, 'Snettisham', 'PE31', 52.87538, 0.56647);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1945, 121, 'West Acre', 'PE32', 52.73016, 0.62756);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1946, 121, 'Shouldham', 'PE33', 52.64814, 0.46886);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1947, 121, 'Wiggenhall St Germans', 'PE34', 52.7245, 0.33986);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1948, 121, 'Sandringham', 'PE35', 52.8253, 0.51155);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1949, 121, 'Old Hunstanton', 'PE36', 52.936, 0.50754);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1950, 121, 'Swaffham', 'PE37', 52.64414, 0.69336);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1951, 121, 'Denver', 'PE38', 52.58977, 0.37698);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1952, 169, '', 'PE4', 52.61262, -0.26589);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1953, 169, 'Ailsworth', 'PE5', 52.57867, -0.34398);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1954, 90, 'Deeping St James', 'PE6', 52.65562, -0.25531);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1955, 61, 'Farcet', 'PE7', 52.53877, -0.19801);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1956, 136, 'Tansor', 'PE8', 52.52694, -0.44176);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1957, 90, 'Stamford', 'PE9', 52.65422, -0.48012);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1958, 128, '', 'PH1', 56.42113, -3.47537);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1959, 128, '', 'PH10', 56.60845, -3.36046);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1960, 128, '', 'PH11', 56.63942, -3.23438);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1961, 128, '', 'PH12', 56.57551, -3.15253);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1962, 128, '', 'PH13', 56.53749, -3.27335);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1963, 128, '', 'PH14', 56.45299, -3.18614);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1964, 128, '', 'PH15', 56.60974, -3.94063);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1965, 128, '', 'PH16', 56.70697, -3.81003);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1966, 128, 'Killichonan', 'PH17', 56.68745, -4.3823);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1967, 128, '', 'PH18', 56.7741, -3.88855);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1968, 122, 'Dalwhinnie', 'PH19', 56.93428, -4.255);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1969, 128, '', 'PH2', 56.38691, -3.40439);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1970, 122, '', 'PH20', 57.05377, -4.15504);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1971, 122, '', 'PH21', 57.08834, -4.02169);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1972, 122, 'Aviemore', 'PH22', 57.19857, -3.80587);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1973, 122, '', 'PH23', 57.28761, -3.80028);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1974, 122, 'Boat Of Garten', 'PH24', 57.25419, -3.74891);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1975, 122, 'Nethy Bridge', 'PH25', 57.26187, -3.64646);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1976, 122, 'Grantown-on-Spey', 'PH26', 57.3298, -3.60464);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1977, 128, 'Auchterarder', 'PH3', 56.30228, -3.70355);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1978, 122, '', 'PH30', 56.79185, -4.6002);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1979, 122, '', 'PH31', 56.89234, -4.81575);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1980, 122, 'Fort Augustus', 'PH32', 57.14424, -4.68275);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1981, 122, 'Fort William', 'PH33', 56.82148, -5.11207);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1982, 122, '', 'PH34', 56.92574, -4.92676);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1983, 122, '', 'PH35', 57.07578, -4.93032);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1984, 122, 'Kentra', 'PH36', 56.72124, -5.86584);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1985, 122, '', 'PH38', 56.84536, -5.74736);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1986, 122, 'Arisaig', 'PH39', 56.91265, -5.84124);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1987, 128, 'Blackford', 'PH4', 56.26072, -3.78244);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1988, 122, '', 'PH40', 56.96381, -5.7856);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1989, 122, 'Mallaig', 'PH41', 57.00374, -5.83251);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1990, 122, 'Isle Of Eigg', 'PH42', 56.90217, -6.14094);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1991, 170, 'Isle Of Rum', 'PH43', 57.01529, -6.28049);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1992, 122, 'Isle Of Canna', 'PH44', 57.05693, -6.50319);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1993, 122, 'Glencoe', 'PH49', 56.675, -5.10977);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1994, 128, 'Muthill', 'PH5', 56.32927, -3.8277);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1995, 122, 'Kinlochleven', 'PH50', 56.71451, -4.96427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1996, 128, 'Comrie', 'PH6', 56.37162, -3.99491);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1997, 128, 'Crieff', 'PH7', 56.37332, -3.82657);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1998, 128, '', 'PH8', 56.56249, -3.59805);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(1999, 128, '', 'PH9', 56.65112, -3.69152);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2000, 171, '', 'PL1', 50.37074, -4.15317);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2001, 101, 'Rame', 'PL10', 50.34537, -4.21106);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2002, 101, 'Antony', 'PL11', 50.3725, -4.2503);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2003, 101, 'Saltash', 'PL12', 50.41932, -4.2483);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2004, 101, 'Looe', 'PL13', 50.35715, -4.47456);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2005, 101, 'Liskeard', 'PL14', 50.46351, -4.4646);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2006, 101, 'South Petherwin', 'PL15', 50.63218, -4.39987);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2007, 100, 'Lifton', 'PL16', 50.64562, -4.26757);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2008, 101, 'Callington', 'PL17', 50.51625, -4.3051);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2009, 101, 'Calstock', 'PL18', 50.51523, -4.21899);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2010, 100, 'Tavistock', 'PL19', 50.55602, -4.15454);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2011, 171, '', 'PL2', 50.38856, -4.16242);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2012, 100, 'Horrabridge', 'PL20', 50.50125, -4.09986);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2013, 100, 'Ivybridge', 'PL21', 50.38566, -3.91748);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2014, 101, 'Lostwithiel', 'PL22', 50.40273, -4.65146);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2015, 101, 'Fowey', 'PL23', 50.33653, -4.63513);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2016, 101, 'St Blaise', 'PL24', 50.35461, -4.70925);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2017, 101, 'St Austell', 'PL25', 50.34038, -4.77872);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2018, 101, 'St Mewan', 'PL26', 50.34196, -4.8252);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2019, 101, 'St Breock', 'PL27', 50.52248, -4.87408);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2020, 101, 'Padstow', 'PL28', 50.53366, -4.96651);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2021, 101, 'St Endellion', 'PL29', 50.58564, -4.82988);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2022, 171, '', 'PL3', 50.38744, -4.12578);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2023, 101, 'Helland', 'PL30', 50.49992, -4.72743);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2024, 101, 'Bodmin', 'PL31', 50.46858, -4.7214);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2025, 101, 'Camelford', 'PL32', 50.63282, -4.66015);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2026, 101, 'St Teath', 'PL33', 50.6213, -4.73021);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2027, 101, 'Tintagel', 'PL34', 50.6597, -4.74234);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2028, 101, 'Forrabury and Minster', 'PL35', 50.68444, -4.68431);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2029, 171, '', 'PL4', 50.3748, -4.12803);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2030, 171, '', 'PL5', 50.41008, -4.16621);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2031, 171, '', 'PL6', 50.4173, -4.11586);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2032, 171, 'Plympton', 'PL7', 50.3916, -4.04436);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2033, 100, 'Yealmpton', 'PL8', 50.33548, -4.01243);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2034, 171, 'Plymstock', 'PL9', 50.35394, -4.08773);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2035, 172, '', 'PO1', 50.79903, -1.08749);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2036, 28, 'Hermitage', 'PO10', 50.85074, -0.92878);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2037, 23, 'South Hayling', 'PO11', 50.7918, -0.97553);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2038, 23, 'Gosport', 'PO12', 50.79764, -1.14144);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2039, 23, 'Gosport', 'PO13', 50.81229, -1.17808);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2040, 23, '', 'PO14', 50.83685, -1.21884);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2041, 23, '', 'PO15', 50.86203, -1.21842);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2042, 23, '', 'PO16', 50.84993, -1.15895);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2043, 23, 'Wickham', 'PO17', 50.88957, -1.16819);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2044, 28, 'Funtington', 'PO18', 50.86403, -0.81478);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2045, 28, 'Chichester', 'PO19', 50.83756, -0.7771);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2046, 172, '', 'PO2', 50.81603, -1.07722);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2047, 28, 'Sidlesham', 'PO20', 50.78278, -0.78563);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2048, 28, 'Aldwick', 'PO21', 50.78362, -0.69622);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2049, 28, 'Felpham', 'PO22', 50.79835, -0.64756);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2050, 172, '', 'PO3', 50.81589, -1.05877);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2051, 173, 'Newport', 'PO30', 50.69085, -1.3133);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2052, 173, 'Cowes', 'PO31', 50.75286, -1.30531);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2053, 173, 'Newport', 'PO32', 50.75091, -1.27982);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2054, 173, 'Newport', 'PO33', 50.72139, -1.16976);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2055, 173, 'Nettlestone', 'PO34', 50.71557, -1.11178);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2056, 173, 'Bembridge', 'PO35', 50.68657, -1.08401);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2057, 173, 'Sandown', 'PO36', 50.65748, -1.1624);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2058, 173, 'Shanklin', 'PO37', 50.63151, -1.177);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2059, 173, 'Ventnor', 'PO38', 50.60406, -1.24108);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2060, 173, 'Totland', 'PO39', 50.68027, -1.53853);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2061, 172, '', 'PO4', 50.78983, -1.06213);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2062, 173, 'Freshwater', 'PO40', 50.68199, -1.52011);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2063, 173, 'Yarmouth', 'PO41', 50.69979, -1.47744);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2064, 172, '', 'PO5', 50.78821, -1.08486);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2065, 172, '', 'PO6', 50.84564, -1.06811);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2066, 23, 'Southwick', 'PO7', 50.88227, -1.03753);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2067, 23, 'Horndean', 'PO8', 50.91084, -1.01275);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2068, 23, 'Havant', 'PO9', 50.86291, -0.9825);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2069, 16, 'Preston', 'PR1', 53.75779, -2.70082);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2070, 16, 'Preston', 'PR2', 53.77753, -2.70722);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2071, 16, 'Leyland', 'PR25', 53.69402, -2.69219);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2072, 16, 'Leyland', 'PR26', 53.68743, -2.74054);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2073, 16, 'Claughton', 'PR3', 53.86826, -2.71636);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2074, 16, 'Freckleton', 'PR4', 53.75335, -2.83271);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2075, 16, 'Bamber Bridge', 'PR5', 53.73107, -2.65641);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2076, 16, 'Chorley', 'PR6', 53.66749, -2.61001);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2077, 16, 'Chorley', 'PR7', 53.6448, -2.65205);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2078, 130, 'Southport', 'PR8', 53.62613, -3.01016);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2079, 130, 'Southport', 'PR9', 53.65974, -2.96859);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2080, 174, '', 'RG1', 51.45366, -0.96942);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2081, 175, 'Twyford', 'RG10', 51.48055, -0.86224);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2082, 113, 'Bracknell', 'RG12', 51.40655, -0.74904);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2083, 176, 'Newbury', 'RG14', 51.39957, -1.32143);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2084, 176, 'Hungerford', 'RG17', 51.43998, -1.48775);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2085, 176, 'Bucklebury', 'RG18', 51.43326, -1.2418);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2086, 176, 'Thatcham', 'RG19', 51.39368, -1.24102);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2087, 174, '', 'RG2', 51.42655, -0.95421);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2088, 176, 'Newbury', 'RG20', 51.40325, -1.33575);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2089, 23, 'Basingstoke', 'RG21', 51.2658, -1.08974);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2090, 23, 'Basingstoke', 'RG22', 51.24986, -1.12159);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2091, 23, 'Basingstoke', 'RG23', 51.26083, -1.14574);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2092, 23, 'Basingstoke', 'RG24', 51.28094, -1.0708);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2093, 23, 'Dummer', 'RG25', 51.22767, -1.16211);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2094, 23, 'Pamber', 'RG26', 51.34966, -1.11824);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2095, 23, 'Hook', 'RG27', 51.29963, -0.94132);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2096, 23, 'Whitchurch', 'RG28', 51.23327, -1.33391);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2097, 23, 'Odiham', 'RG29', 51.24751, -0.94538);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2098, 174, '', 'RG30', 51.45133, -1.01265);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2099, 174, '', 'RG31', 51.45607, -1.04134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2100, 174, '', 'RG4', 51.48063, -0.96882);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2101, 175, '', 'RG40', 51.39933, -0.83406);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2102, 175, '', 'RG41', 51.41574, -0.85666);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2103, 113, 'Warfield', 'RG42', 51.42729, -0.75423);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2104, 175, 'Wokingham Without', 'RG45', 51.37471, -0.8002);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2105, 175, 'Woodley', 'RG5', 51.45219, -0.90612);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2106, 175, 'Earley', 'RG6', 51.43893, -0.9309);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2107, 176, 'Sulhamstead', 'RG7', 51.3979, -1.07706);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2108, 166, 'Whitchurch-on-Thames', 'RG8', 51.50513, -1.10516);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2109, 166, 'Rotherfield Greys', 'RG9', 51.54407, -0.92267);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2110, 73, 'Reigate and Banstead', 'RH1', 51.23683, -0.15623);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2111, 28, 'Crawley', 'RH10', 51.11724, -0.15813);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2112, 28, 'Crawley', 'RH11', 51.11079, -0.20554);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2113, 28, 'Horsham', 'RH12', 51.07579, -0.33254);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2114, 28, 'Southwater', 'RH13', 51.03701, -0.32537);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2115, 28, 'Wisborough Green', 'RH14', 51.03197, -0.48245);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2116, 28, 'Burgess Hill', 'RH15', 50.95675, -0.13316);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2117, 28, 'Haywards Heath', 'RH16', 51.00204, -0.09713);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2118, 28, 'Cuckfield Rural', 'RH17', 51.02122, -0.11488);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2119, 27, 'Forest Row', 'RH18', 51.09702, 0.03104);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2120, 28, 'East Grinstead', 'RH19', 51.12474, -0.01205);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2121, 73, 'Reigate and Banstead', 'RH2', 51.23485, -0.20215);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2122, 28, 'Storrington', 'RH20', 50.93647, -0.4699);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2123, 73, 'Brockham', 'RH3', 51.23242, -0.2796);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2124, 73, 'Dorking', 'RH4', 51.22871, -0.33418);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2125, 73, 'Capel', 'RH5', 51.19463, -0.34113);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2126, 73, 'Horley', 'RH6', 51.17126, -0.1617);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2127, 73, 'Lingfield', 'RH7', 51.17427, -0.01564);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2128, 73, 'Limpsfield', 'RH8', 51.2513, 0.00344);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2129, 73, 'Godstone', 'RH9', 51.23543, -0.06889);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2130, 29, 'Romford', 'RM1', 51.58175, 0.18395);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2131, 29, 'Barking', 'RM10', 51.54443, 0.15909);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2132, 29, 'Romford', 'RM11', 51.56939, 0.21944);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2133, 29, 'Romford', 'RM12', 51.55251, 0.20852);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2134, 29, 'Romford', 'RM13', 51.52397, 0.19561);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2135, 29, 'Romford', 'RM14', 51.55593, 0.26496);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2136, 177, '', 'RM15', 51.508, 0.27843);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2137, 177, '', 'RM16', 51.49148, 0.341);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2138, 177, '', 'RM17', 51.4791, 0.33029);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2139, 177, '', 'RM18', 51.46646, 0.37716);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2140, 177, '', 'RM19', 51.4825, 0.24835);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2141, 29, 'Romford', 'RM2', 51.5832, 0.20279);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2142, 177, '', 'RM20', 51.47812, 0.28847);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2143, 29, 'Romford', 'RM3', 51.60163, 0.22679);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2144, 62, 'Stapleford Abbotts', 'RM4', 51.63255, 0.16038);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2145, 29, 'Romford', 'RM5', 51.59917, 0.16602);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2146, 29, 'Barking', 'RM6', 51.57549, 0.13313);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2147, 29, 'Romford', 'RM7', 51.5748, 0.17063);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2148, 29, 'Barking', 'RM8', 51.55662, 0.13225);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2149, 29, 'Barking', 'RM9', 51.54036, 0.13582);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2150, 178, 'Norton', 'S1', 53.3802, -1.46777);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2151, 178, 'Norton', 'S10', 53.37681, -1.51742);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2152, 178, 'Norton', 'S11', 53.36148, -1.50557);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2153, 178, 'Norton', 'S12', 53.34844, -1.40507);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2154, 178, 'Norton', 'S13', 53.36451, -1.3823);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2155, 178, 'Norton', 'S14', 53.34592, -1.44266);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2156, 178, 'Norton', 'S17', 53.32111, -1.52556);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2157, 81, 'Dronfield', 'S18', 53.29931, -1.47178);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2158, 178, 'Norton', 'S2', 53.36932, -1.44686);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2159, 178, 'Norton', 'S20', 53.33467, -1.35119);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2160, 81, 'Eckington', 'S21', 53.31213, -1.33802);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2161, 179, 'Dinnington', 'S25', 53.36891, -1.21389);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2162, 179, 'Todwick', 'S26', 53.35678, -1.28624);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2163, 178, 'Norton', 'S3', 53.38741, -1.47219);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2164, 81, 'Grindleford', 'S32', 53.29454, -1.63839);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2165, 81, 'Aston', 'S33', 53.3415, -1.72061);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2166, 178, 'Ecclesfield', 'S35', 53.45763, -1.49542);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2167, 180, 'Hunshelf', 'S36', 53.50302, -1.61249);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2168, 178, 'Norton', 'S4', 53.399, -1.44949);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2169, 81, 'Chesterfield', 'S40', 53.23356, -1.44562);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2170, 81, 'Chesterfield', 'S41', 53.24696, -1.42746);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2171, 81, 'Wingerworth', 'S42', 53.20019, -1.42209);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2172, 81, 'Staveley', 'S43', 53.2672, -1.34172);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2173, 81, 'Bolsover', 'S44', 53.22478, -1.31241);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2174, 81, 'Clay Cross', 'S45', 53.16602, -1.42106);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2175, 178, 'Norton', 'S5', 53.42152, -1.46124);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2176, 178, 'Norton', 'S6', 53.40195, -1.50962);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2177, 179, '', 'S60', 53.41376, -1.34698);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2178, 179, '', 'S61', 53.44367, -1.3932);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2179, 179, 'Rawmarsh', 'S62', 53.465, -1.34619);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2180, 180, '', 'S63', 53.51794, -1.32879);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2181, 179, '', 'S64', 53.4908, -1.29907);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2182, 179, '', 'S65', 53.43518, -1.31955);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2183, 179, 'Bramley', 'S66', 53.42033, -1.24153);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2184, 178, 'Norton', 'S7', 53.35422, -1.48913);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2185, 180, '', 'S70', 53.54114, -1.4733);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2186, 180, '', 'S71', 53.57342, -1.45629);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2187, 180, 'Brierley', 'S72', 53.57851, -1.39127);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2188, 180, 'Darfield', 'S73', 53.52458, -1.39355);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2189, 180, 'Hoyland', 'S74', 53.50053, -1.43913);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2190, 180, '', 'S75', 53.56201, -1.51985);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2191, 178, 'Norton', 'S8', 53.33978, -1.47578);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2192, 87, 'Clumber and Hardwick', 'S80', 53.29205, -1.14928);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2193, 87, 'Carlton in Lindrick', 'S81', 53.3377, -1.12134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2194, 178, 'Norton', 'S9', 53.39794, -1.41641);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2195, 181, 'Landore', 'SA1', 51.62742, -3.93905);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2196, 182, 'Blaenhonddan', 'SA10', 51.68722, -3.79836);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2197, 182, 'Tonna', 'SA11', 51.67428, -3.76168);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2198, 182, 'Baglan', 'SA12', 51.60725, -3.79375);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2199, 182, 'Bryn', 'SA13', 51.60559, -3.72436);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2200, 183, 'Llannon', 'SA14', 51.73245, -4.10721);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2201, 183, 'Llanelli Rural', 'SA15', 51.69989, -4.16648);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2202, 183, 'Cefn Sidan', 'SA16', 51.68922, -4.25569);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2203, 183, 'Kidwelly', 'SA17', 51.7579, -4.2852);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2204, 183, 'Betws', 'SA18', 51.79798, -3.95796);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2205, 183, 'Talley', 'SA19', 51.95284, -3.94723);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2206, 181, 'Sketty', 'SA2', 51.62021, -3.99364);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2207, 183, 'Llandovery', 'SA20', 52.01025, -3.78651);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2208, 181, 'Bishopston', 'SA3', 51.57965, -4.05105);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2209, 183, 'Carmarthen', 'SA31', 51.85639, -4.30762);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2210, 183, 'Llanegwad', 'SA32', 51.88597, -4.17106);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2211, 183, 'Meidrim', 'SA33', 51.85022, -4.4351);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2212, 183, 'Llanfallteg', 'SA34', 51.85258, -4.61822);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2213, 184, 'Clydau', 'SA35', 51.97349, -4.55974);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2214, 184, 'Crymych', 'SA36', 51.95717, -4.60684);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2215, 184, 'Boncath', 'SA37', 52.01684, -4.59282);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2216, 183, 'Newcastle Emlyn', 'SA38', 52.0401, -4.47312);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2217, 183, 'Llanfihangel-Ar-Arth', 'SA39', 52.01955, -4.24166);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2218, 181, 'Gorseinon', 'SA4', 51.67054, -4.04792);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2219, 185, 'Llanwenog', 'SA40', 52.08378, -4.17335);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2220, 184, 'Eglwyswrw', 'SA41', 51.99718, -4.70679);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2221, 184, 'Newport', 'SA42', 52.01534, -4.8522);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2222, 185, 'Llangoedmor', 'SA43', 52.08619, -4.62896);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2223, 185, 'Troedyraur', 'SA44', 52.08625, -4.37201);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2224, 185, 'New Quay', 'SA45', 52.20794, -4.358);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2225, 185, 'Aberaeron', 'SA46', 52.23254, -4.24945);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2226, 185, 'Llanarth', 'SA47', 52.19028, -4.29561);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2227, 185, 'Llangybi', 'SA48', 52.14338, -4.11048);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2228, 181, 'Penderry', 'SA5', 51.64851, -3.96886);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2229, 181, 'Morriston', 'SA6', 51.67539, -3.92084);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2230, 184, 'Haverfordwest', 'SA61', 51.79916, -4.97345);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2231, 184, 'Nolton', 'SA62', 51.84093, -5.06333);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2232, 184, 'Wiston', 'SA63', 51.87409, -4.85342);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2233, 184, 'Pencaer', 'SA64', 52.00147, -5.01162);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2234, 184, 'Fishguard', 'SA65', 51.98818, -4.96848);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2235, 184, 'Maenclochog', 'SA66', 51.88121, -4.74342);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2236, 184, 'Narberth', 'SA67', 51.78165, -4.73157);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2237, 184, 'Jeffreyston', 'SA68', 51.72867, -4.76603);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2238, 184, 'Saundersfoot', 'SA69', 51.71029, -4.70555);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2239, 181, 'Llansamlet', 'SA7', 51.6615, -3.88989);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2240, 184, 'Penally', 'SA70', 51.67176, -4.73797);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2241, 184, 'Pembroke', 'SA71', 51.66716, -4.92863);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2242, 184, 'Pembroke Dock', 'SA72', 51.6913, -4.93453);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2243, 184, 'Milford Haven', 'SA73', 51.71634, -5.01146);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2244, 182, 'Pontardawe', 'SA8', 51.72153, -3.8475);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2245, 133, 'Ystradgynlais', 'SA9', 51.78122, -3.76729);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2246, 29, 'Camberwell', 'SE1', 51.49838, -0.08949);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2247, 29, 'Greenwich', 'SE10', 51.48162, -0.00089);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2248, 29, 'Lambeth', 'SE11', 51.4888, -0.10862);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2249, 29, 'Greenwich', 'SE12', 51.4443, 0.02483);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2250, 29, 'Lewisham', 'SE13', 51.45837, -0.0091);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2251, 29, 'Lewisham', 'SE14', 51.47511, -0.0415);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2252, 29, 'Camberwell', 'SE15', 51.47189, -0.06468);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2253, 29, 'Camberwell', 'SE16', 51.49597, -0.05213);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2254, 29, 'Camberwell', 'SE17', 51.48764, -0.09282);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2255, 29, 'Eltham', 'SE18', 51.48391, 0.07412);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2256, 29, 'Croydon', 'SE19', 51.41735, -0.08424);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2257, 29, 'Eltham', 'SE2', 51.48943, 0.11759);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2258, 29, 'Bromley', 'SE20', 51.41151, -0.05716);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2259, 29, 'Camberwell', 'SE21', 51.43807, -0.08626);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2260, 29, 'Camberwell', 'SE22', 51.45401, -0.07119);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2261, 29, 'Lewisham', 'SE23', 51.44015, -0.04875);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2262, 29, 'Camberwell', 'SE24', 51.45446, -0.09853);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2263, 29, 'Croydon', 'SE25', 51.39742, -0.07501);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2264, 29, 'Lewisham', 'SE26', 51.42674, -0.05364);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2265, 29, 'Lambeth', 'SE27', 51.43022, -0.10097);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2266, 29, 'Eltham', 'SE28', 51.50219, 0.10809);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2267, 29, 'Greenwich', 'SE3', 51.46866, 0.02015);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2268, 29, 'Lewisham', 'SE4', 51.46058, -0.03348);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2269, 29, 'Camberwell', 'SE5', 51.47322, -0.09055);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2270, 29, 'Lewisham', 'SE6', 51.43777, -0.01432);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2271, 29, 'Greenwich', 'SE7', 51.48369, 0.03521);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2272, 29, 'Lewisham', 'SE8', 51.48118, -0.02828);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2273, 29, 'Eltham', 'SE9', 51.44465, 0.05651);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2274, 4, 'Stevenage', 'SG1', 51.91103, -0.19417);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2275, 4, 'Much Hadham', 'SG10', 51.8446, 0.07178);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2276, 4, 'Standon', 'SG11', 51.88125, 0.03278);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2277, 4, 'Ware', 'SG12', 51.81375, -0.01669);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2278, 186, '', 'SG13', 51.78673, -0.06863);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2279, 186, '', 'SG14', 51.80688, -0.09098);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2280, 144, 'Arlesey', 'SG15', 52.01276, -0.26149);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2281, 144, 'Henlow', 'SG16', 52.01507, -0.29638);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2282, 144, 'Shefford', 'SG17', 52.03445, -0.33063);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2283, 144, 'Biggleswade', 'SG18', 52.08208, -0.26609);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2284, 144, 'Everton', 'SG19', 52.13925, -0.24049);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2285, 4, 'Stevenage', 'SG2', 51.8962, -0.16569);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2286, 4, 'Knebworth', 'SG3', 51.86046, -0.18022);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2287, 4, 'Ippollitts', 'SG4', 51.921, -0.25922);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2288, 4, 'Ickleford', 'SG5', 51.96727, -0.28654);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2289, 4, 'Hitchin', 'SG6', 51.97888, -0.22057);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2290, 4, 'Bygrave', 'SG7', 52.00335, -0.17443);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2291, 61, 'Melbourn', 'SG8', 52.06369, -0.01293);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2292, 4, 'Buntingford', 'SG9', 51.9458, -0.00796);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2293, 187, '', 'SK1', 53.40736, -2.15044);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2294, 76, 'Macclesfield', 'SK10', 53.27793, -2.12899);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2295, 76, 'Macclesfield', 'SK11', 53.24646, -2.14238);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2296, 76, 'Poynton', 'SK12', 53.35169, -2.09165);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2297, 81, 'Glossop', 'SK13', 53.4479, -1.96386);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2298, 150, 'Ashton-under-Lyne', 'SK14', 53.45149, -2.05422);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2299, 150, '', 'SK15', 53.48655, -2.04672);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2300, 150, 'Ashton-under-Lyne', 'SK16', 53.47395, -2.08137);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2301, 81, 'King Sterndale', 'SK17', 53.24378, -1.87861);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2302, 187, '', 'SK2', 53.3948, -2.13235);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2303, 81, 'New Mills', 'SK22', 53.3724, -1.98497);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2304, 81, 'Chapel-en-le-Frith', 'SK23', 53.32744, -1.94895);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2305, 187, '', 'SK3', 53.39835, -2.16996);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2306, 187, '', 'SK4', 53.41901, -2.17908);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2307, 187, '', 'SK5', 53.43433, -2.15204);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2308, 187, '', 'SK6', 53.40563, -2.07973);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2309, 187, 'Cheadle', 'SK7', 53.36962, -2.14129);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2310, 187, '', 'SK8', 53.37941, -2.20748);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2311, 76, 'Macclesfield', 'SK9', 53.32723, -2.22975);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2312, 116, 'Iver', 'SL0', 51.52431, -0.51371);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2313, 188, 'Colnbrook with Poyle', 'SL1', 51.51751, -0.61916);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2314, 188, 'Colnbrook with Poyle', 'SL2', 51.5335, -0.60281);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2315, 188, 'Colnbrook with Poyle', 'SL3', 51.49961, -0.55198);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2316, 189, 'Windsor', 'SL4', 51.4753, -0.62475);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2317, 189, 'Sunninghill', 'SL5', 51.40468, -0.66138);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2318, 189, 'Maidenhead', 'SL6', 51.52231, -0.72569);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2319, 116, 'Marlow', 'SL7', 51.57411, -0.7762);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2320, 116, 'Wooburn', 'SL8', 51.57786, -0.70682);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2321, 116, 'Chalfont St Peter', 'SL9', 51.59677, -0.55467);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2322, 29, 'Sutton', 'SM1', 51.36599, -0.19127);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2323, 29, 'Sutton', 'SM2', 51.35258, -0.19611);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2324, 29, 'Sutton', 'SM3', 51.36992, -0.21267);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2325, 29, 'Merton', 'SM4', 51.39219, -0.19886);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2326, 29, 'Sutton', 'SM5', 51.36741, -0.16679);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2327, 29, 'Sutton', 'SM6', 51.35984, -0.14267);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2328, 73, 'Reigate and Banstead', 'SM7', 51.32296, -0.20014);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2329, 190, '', 'SN1', 51.55689, -1.77351);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2330, 14, 'Roundway', 'SN10', 51.33589, -1.98708);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2331, 14, 'Calne', 'SN11', 51.43931, -1.99856);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2332, 14, 'Melksham', 'SN12', 51.37178, -2.13649);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2333, 14, 'Corsham', 'SN13', 51.42383, -2.21001);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2334, 14, 'Yatton Keynell', 'SN14', 51.47511, -2.1944);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2335, 14, 'Bremhill', 'SN15', 51.47255, -2.0792);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2336, 14, 'Malmesbury', 'SN16', 51.59304, -2.08951);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2337, 190, '', 'SN2', 51.57939, -1.78206);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2338, 190, 'Haydon Wick', 'SN25', 51.5911, -1.79644);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2339, 190, 'Blunsdon St Andrew', 'SN26', 51.61086, -1.78335);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2340, 190, '', 'SN3', 51.56132, -1.74319);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2341, 190, 'Wroughton', 'SN4', 51.53089, -1.81978);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2342, 190, '', 'SN5', 51.56509, -1.83696);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2343, 190, 'Stanton Fitzwarren', 'SN6', 51.62067, -1.74141);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2344, 166, 'Shellingford', 'SN7', 51.64892, -1.56345);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2345, 14, 'Savernake', 'SN8', 51.40741, -1.6851);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2346, 14, 'Manningford', 'SN9', 51.324, -1.78614);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2347, 191, '', 'SO14', 50.90805, -1.39546);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2348, 191, '', 'SO15', 50.91629, -1.42381);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2349, 191, '9 Arcadia Close', 'SO16', 50.93521, -1.43069);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2350, 191, '', 'SO17', 50.92603, -1.3938);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2351, 191, '', 'SO18', 50.92405, -1.35968);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2352, 191, '', 'SO19', 50.90244, -1.35429);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2353, 23, 'Longstock', 'SO20', 51.11361, -1.50422);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2354, 23, 'Winchester', 'SO21', 51.07488, -1.31334);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2355, 23, 'Winchester', 'SO22', 51.06509, -1.33204);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2356, 23, 'Winchester', 'SO23', 51.06765, -1.30774);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2357, 23, 'Bishops Sutton', 'SO24', 51.08367, -1.14615);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2358, 23, 'Hedge End', 'SO30', 50.91924, -1.30568);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2359, 23, 'Locks Heath', 'SO31', 50.86882, -1.29506);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2360, 23, 'Bishops Waltham', 'SO32', 50.9474, -1.20845);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2361, 23, 'Totton', 'SO40', 50.91484, -1.50065);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2362, 23, 'Lymington', 'SO41', 50.75502, -1.56473);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2363, 23, 'Denny Lodge', 'SO42', 50.80976, -1.53442);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2364, 23, 'Lyndhurst', 'SO43', 50.88729, -1.58341);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2365, 23, 'Hythe', 'SO45', 50.84778, -1.3934);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2366, 23, 'Eastleigh', 'SO50', 50.9689, -1.33912);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2367, 23, 'Romsey', 'SO51', 50.994, -1.50407);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2368, 23, 'North Baddesley', 'SO52', 50.97663, -1.44015);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2369, 23, 'Eastleigh', 'SO53', 50.98442, -1.38022);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2370, 14, 'Salisbury', 'SP1', 51.074, -1.78873);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2371, 23, 'Andover', 'SP10', 51.21065, -1.48314);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2372, 23, 'Charlton', 'SP11', 51.22696, -1.51303);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2373, 14, 'Salisbury', 'SP2', 51.07406, -1.82441);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2374, 14, 'Dinton', 'SP3', 51.10117, -2.00571);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2375, 14, 'Amesbury', 'SP4', 51.16479, -1.764);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2376, 14, 'Downton', 'SP5', 51.02271, -1.77185);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2377, 23, 'Fordingbridge', 'SP6', 50.93553, -1.80074);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2378, 22, 'Shaftesbury', 'SP7', 51.0039, -2.18245);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2379, 22, 'Gillingham', 'SP8', 51.03696, -2.28956);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2380, 23, 'South Tidworth', 'SP9', 51.23018, -1.66053);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2381, 84, '', 'SR1', 54.90695, -1.37919);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2382, 84, '', 'SR2', 54.88716, -1.37638);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2383, 84, 'Houghton-le-Spring', 'SR3', 54.87747, -1.41549);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2384, 84, 'Houghton-le-Spring', 'SR4', 54.90088, -1.42451);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2385, 84, 'Castletown', 'SR5', 54.92334, -1.42419);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2386, 84, '', 'SR6', 54.9348, -1.37876);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2387, 83, 'Dalton-le-Dale', 'SR7', 54.83046, -1.36168);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2388, 83, 'Peterlee', 'SR8', 54.7665, -1.33471);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2389, 84, '', 'SR9', 54.90243, -1.37458);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2390, 192, '', 'SS0', 51.54602, 0.69146);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2391, 192, '', 'SS1', 51.53697, 0.73275);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2392, 62, 'Wickford', 'SS11', 51.6151, 0.53807);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2393, 62, 'Wickford', 'SS12', 51.60556, 0.52164);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2394, 62, 'Basildon', 'SS13', 51.57433, 0.50981);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2395, 62, 'Basildon', 'SS14', 51.57507, 0.47521);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2396, 62, 'Basildon', 'SS15', 51.57687, 0.432);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2397, 62, 'Basildon', 'SS16', 51.56201, 0.4543);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2398, 177, 'Corringham', 'SS17', 51.52093, 0.44055);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2399, 192, '', 'SS2', 51.54991, 0.71766);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2400, 192, '', 'SS3', 51.54276, 0.79224);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2401, 62, 'Rochford', 'SS4', 51.59406, 0.71452);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2402, 62, 'Hockley', 'SS5', 51.60722, 0.6503);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2403, 62, 'Rayleigh', 'SS6', 51.58746, 0.60872);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2404, 62, 'Canvey Island', 'SS7', 51.56202, 0.57984);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2405, 62, 'Canvey Island', 'SS8', 51.5222, 0.59057);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2406, 192, '', 'SS9', 51.55409, 0.65298);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2407, 193, '', 'ST1', 53.02616, -2.17148);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2408, 11, 'Cheadle', 'ST10', 52.98942, -1.96275);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2409, 11, 'Forsbrook', 'ST11', 52.96693, -2.06552);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2410, 11, 'Barlaston', 'ST12', 52.94795, -2.17117);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2411, 11, 'Leek', 'ST13', 53.1009, -2.01793);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2412, 11, 'Uttoxeter', 'ST14', 52.90304, -1.86767);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2413, 11, 'Stone', 'ST15', 52.90033, -2.14719);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2414, 11, 'Stafford', 'ST16', 52.81315, -2.11871);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2415, 11, 'Stafford', 'ST17', 52.7889, -2.09936);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2416, 11, 'Hopton', 'ST18', 52.81408, -2.08161);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2417, 11, 'Penkridge', 'ST19', 52.71243, -2.14656);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2418, 193, '', 'ST2', 53.02711, -2.1357);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2419, 11, 'Gnosall', 'ST20', 52.79854, -2.26255);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2420, 11, 'Eccleshall', 'ST21', 52.86777, -2.25851);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2421, 193, '', 'ST3', 52.98037, -2.12214);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2422, 193, '', 'ST4', 52.99468, -2.18328);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2423, 11, 'Newcastle-under-Lyme', 'ST5', 53.01526, -2.23703);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2424, 193, '', 'ST6', 53.0576, -2.18951);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2425, 11, 'Kidsgrove', 'ST7', 53.08802, -2.2658);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2426, 11, 'Biddulph', 'ST8', 53.11517, -2.16735);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2427, 11, 'Bagnall', 'ST9', 53.05052, -2.09847);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2428, 194, 'Westminster', 'SW1', 51.49558, -0.1386);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2429, 29, 'Kensington', 'SW10', 51.48365, -0.18086);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2430, 29, 'Wandsworth', 'SW11', 51.4663, -0.16427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2431, 29, 'Wandsworth', 'SW12', 51.44536, -0.14784);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2432, 29, 'Richmond', 'SW13', 51.47473, -0.24458);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2433, 29, 'Richmond', 'SW14', 51.46514, -0.26511);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2434, 29, 'Wandsworth', 'SW15', 51.45734, -0.22509);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2435, 29, 'Lambeth', 'SW16', 51.42165, -0.12722);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2436, 29, 'Wandsworth', 'SW17', 51.4303, -0.16283);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2437, 29, 'Wandsworth', 'SW18', 51.4496, -0.18941);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2438, 29, 'Merton', 'SW19', 51.42284, -0.20341);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2439, 194, 'Westminster', 'SW1A', 51.50265, -0.13111);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2440, 194, 'Westminster', 'SW1E', 51.49737, -0.13853);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2441, 194, 'Westminster', 'SW1H', 51.49818, -0.13273);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2442, 194, 'Westminster', 'SW1P', 51.49548, -0.13284);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2443, 194, 'Westminster', 'SW1V', 51.49016, -0.13738);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2444, 194, 'Westminster', 'SW1W', 51.49302, -0.14735);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2445, 194, 'Westminster', 'SW1X', 51.4976, -0.15293);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2446, 194, 'Westminster', 'SW1Y', 51.50539, -0.13388);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2447, 29, 'Lambeth', 'SW2', 51.44939, -0.11889);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2448, 29, 'Merton', 'SW20', 51.41058, -0.22547);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2449, 29, 'Kensington', 'SW3', 51.48969, -0.16477);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2450, 29, 'Lambeth', 'SW4', 51.46045, -0.13571);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2451, 29, 'Kensington', 'SW5', 51.49005, -0.18781);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2452, 29, 'Hammersmith', 'SW6', 51.47675, -0.19986);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2453, 29, 'Kensington', 'SW7', 51.49614, -0.1746);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2454, 29, 'Lambeth', 'SW8', 51.47566, -0.13077);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2455, 29, 'Lambeth', 'SW9', 51.46907, -0.11232);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2456, 92, 'Shrewsbury', 'SY1', 52.7228, -2.74039);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2457, 92, 'Oswestry Rural', 'SY10', 52.83579, -3.12089);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2458, 92, 'Oswestry', 'SY11', 52.8663, -3.02808);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2459, 92, 'Ellesmere', 'SY12', 52.90335, -2.89364);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2460, 92, 'Whitchurch Rural', 'SY13', 52.95147, -2.68921);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2461, 70, 'Malpas', 'SY14', 53.02924, -2.76203);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2462, 133, 'Montgomery', 'SY15', 52.55518, -3.12995);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2463, 133, 'Llanllwchaiarn', 'SY16', 52.52004, -3.31183);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2464, 133, 'Caersws', 'SY17', 52.51644, -3.46501);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2465, 133, 'Llanidloes', 'SY18', 52.44076, -3.54784);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2466, 133, 'Llanbrynmair', 'SY19', 52.57388, -3.61156);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2467, 92, 'Shrewsbury', 'SY2', 52.70669, -2.72827);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2468, 133, 'Glantwymyn', 'SY20', 52.61405, -3.81838);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2469, 133, 'Castle Caereinion', 'SY21', 52.65784, -3.20505);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2470, 133, 'Llansantffraid', 'SY22', 52.75604, -3.18553);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2471, 185, 'Llanfarian', 'SY23', 52.38184, -4.05129);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2472, 185, 'Geneur Glyn', 'SY24', 52.47045, -4.02302);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2473, 185, 'Tregaron', 'SY25', 52.2381, -3.93626);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2474, 92, 'Shrewsbury', 'SY3', 52.69923, -2.76959);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2475, 92, 'Myddle', 'SY4', 52.79556, -2.75052);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2476, 92, 'Longden', 'SY5', 52.65299, -2.82791);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2477, 92, 'Church Stretton', 'SY6', 52.53906, -2.79038);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2478, 92, 'Hopesay', 'SY7', 52.42508, -2.88688);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2479, 92, 'Ludlow', 'SY8', 52.36523, -2.69474);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2480, 92, 'Lydham', 'SY9', 52.49803, -2.98558);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2481, 13, 'Taunton', 'TA1', 51.01234, -3.10203);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2482, 13, 'Langport', 'TA10', 51.03262, -2.82438);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2483, 13, 'Somerton', 'TA11', 51.06039, -2.70214);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2484, 13, 'Martock', 'TA12', 50.97452, -2.77207);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2485, 13, 'South Petherton', 'TA13', 50.94638, -2.81004);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2486, 13, 'Norton Sub Hamdon', 'TA14', 50.94588, -2.75024);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2487, 13, 'Montacute', 'TA15', 50.95058, -2.71757);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2488, 13, 'Merriott', 'TA16', 50.90693, -2.79229);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2489, 13, 'Hinton St George', 'TA17', 50.90753, -2.83497);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2490, 13, 'Crewkerne', 'TA18', 50.88269, -2.78619);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2491, 13, 'Ilminster', 'TA19', 50.93392, -2.91373);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2492, 13, 'Staplegrove', 'TA2', 51.03303, -3.10109);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2493, 13, 'Chard', 'TA20', 50.87329, -2.96087);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2494, 13, 'Wellington', 'TA21', 50.97673, -3.24507);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2495, 13, 'Dulverton', 'TA22', 51.0451, -3.54509);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2496, 13, 'Williton', 'TA23', 51.16171, -3.3516);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2497, 13, 'Wootton Courtenay', 'TA24', 51.18137, -3.50957);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2498, 13, 'Stoke St Mary', 'TA3', 50.99403, -3.03889);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2499, 13, 'Lydeard St Lawrence', 'TA4', 51.07092, -3.26758);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2500, 13, 'Spaxton', 'TA5', 51.14633, -3.10379);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2501, 13, 'Bridgwater', 'TA6', 51.12479, -2.99895);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2502, 13, 'Stawell', 'TA7', 51.12999, -2.91187);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2503, 13, 'Burnham-on-Sea', 'TA8', 51.24445, -2.99294);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2504, 13, 'Burnham Without', 'TA9', 51.22588, -2.9553);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2505, 98, 'Galashiels', 'TD1', 55.6239, -2.80997);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2506, 98, 'Greenlaw', 'TD10', 55.71203, -2.44887);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2507, 98, '', 'TD11', 55.78792, -2.31578);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2508, 195, 'Cornhill-on-Tweed', 'TD12', 55.65331, -2.2384);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2509, 98, 'Cockburnspath', 'TD13', 55.92975, -2.36975);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2510, 98, '', 'TD14', 55.86735, -2.12305);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2511, 195, 'Berwick-upon-Tweed', 'TD15', 55.74699, -2.01275);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2512, 98, '', 'TD2', 55.733, -2.7533);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2513, 98, '', 'TD3', 55.70073, -2.57127);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2514, 98, 'Earlston', 'TD4', 55.64182, -2.67051);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2515, 98, '', 'TD5', 55.58723, -2.41571);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2516, 98, 'Newtown St Boswells', 'TD6', 55.58238, -2.6933);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2517, 98, '', 'TD7', 55.53631, -2.87156);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2518, 98, 'Jedburgh', 'TD8', 55.47531, -2.54111);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2519, 98, '', 'TD9', 55.39766, -2.77533);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2520, 196, 'Wellington', 'TF1', 52.70246, -2.50323);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2521, 196, 'Newport', 'TF10', 52.76943, -2.38541);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2522, 92, 'Shifnal', 'TF11', 52.66253, -2.35933);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2523, 92, 'Broseley', 'TF12', 52.61175, -2.48003);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2524, 92, 'Much Wenlock', 'TF13', 52.57803, -2.5815);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2525, 196, 'St Georges and Priorslee', 'TF2', 52.70002, -2.43956);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2526, 196, 'Hollinswood', 'TF3', 52.66404, -2.44363);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2527, 196, 'Telford', 'TF4', 52.66125, -2.46726);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2528, 196, 'Wellington', 'TF5', 52.7149, -2.53594);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2529, 196, 'Rodington', 'TF6', 52.7355, -2.55397);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2530, 196, 'Madeley', 'TF7', 52.63525, -2.44925);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2531, 196, 'The Gorge', 'TF8', 52.62974, -2.47875);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2532, 92, 'Sutton upon Tern', 'TF9', 52.8977, -2.46832);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2533, 30, 'Royal Tunbridge Wells', 'TN1', 51.1349, 0.27002);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2534, 30, 'Tonbridge', 'TN10', 51.21013, 0.28661);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2535, 30, 'Tonbridge', 'TN11', 51.20597, 0.26922);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2536, 30, 'Yalding', 'TN12', 51.17194, 0.44067);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2537, 30, 'Sevenoaks', 'TN13', 51.27593, 0.18519);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2538, 30, 'Dunton Green', 'TN14', 51.29525, 0.16172);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2539, 30, 'Wrotham', 'TN15', 51.29951, 0.26953);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2540, 29, '', 'TN16', 51.29362, 0.05262);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2541, 30, 'Cranbrook', 'TN17', 51.0961, 0.5381);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2542, 30, 'Four Throws', 'TN18', 51.04328, 0.52665);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2543, 27, 'Burwash', 'TN19', 51.00262, 0.40754);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2544, 30, 'Royal Tunbridge Wells', 'TN2', 51.13726, 0.28729);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2545, 27, 'Mayfield', 'TN20', 51.02633, 0.25615);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2546, 27, 'Heathfield', 'TN21', 50.95871, 0.26427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2547, 27, 'Uckfield', 'TN22', 50.98067, 0.10005);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2548, 30, 'Ashford', 'TN23', 51.13902, 0.86075);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2549, 30, 'Ashford', 'TN24', 51.14917, 0.88712);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2550, 30, 'Wye', 'TN25', 51.14426, 0.93972);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2551, 30, 'Shadoxhurst', 'TN26', 51.09988, 0.80547);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2552, 30, 'Smarden', 'TN27', 51.16519, 0.70642);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2553, 30, 'New Romney', 'TN28', 50.98202, 0.95226);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2554, 30, 'St Mary In The Marsh', 'TN29', 50.99327, 0.93444);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2555, 30, 'Royal Tunbridge Wells', 'TN3', 51.12265, 0.25227);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2556, 30, 'Tenterden', 'TN30', 51.06195, 0.69753);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2557, 27, 'Peasmarsh', 'TN31', 50.96233, 0.68748);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2558, 27, 'Salehurst', 'TN32', 50.9793, 0.4904);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2559, 27, 'Battle', 'TN33', 50.91032, 0.47676);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2560, 27, 'Hastings', 'TN34', 50.86393, 0.58374);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2561, 27, 'Hastings', 'TN35', 50.88036, 0.61309);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2562, 27, 'Icklesham', 'TN36', 50.92061, 0.70216);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2563, 27, 'Hastings', 'TN37', 50.87168, 0.55858);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2564, 27, 'Hastings', 'TN38', 50.86297, 0.54531);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2565, 27, 'Bexhill', 'TN39', 50.84602, 0.45488);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2566, 30, 'Royal Tunbridge Wells', 'TN4', 51.1459, 0.25912);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2567, 27, 'Bexhill', 'TN40', 50.84449, 0.48463);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2568, 27, 'Wadhurst', 'TN5', 51.06471, 0.36223);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2569, 27, 'Crowborough', 'TN6', 51.05216, 0.17464);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2570, 27, 'Hartfield', 'TN7', 51.09204, 0.10938);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2571, 30, 'Edenbridge', 'TN8', 51.1942, 0.07969);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2572, 30, 'Tonbridge', 'TN9', 51.19053, 0.27705);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2573, 197, 'Torquay', 'TQ1', 50.47156, -3.52209);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2574, 100, 'South Brent', 'TQ10', 50.42412, -3.81906);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2575, 100, 'Buckfast', 'TQ11', 50.48137, -3.78179);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2576, 100, 'Newton Abbot', 'TQ12', 50.52882, -3.61142);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2577, 100, 'Bovey Tracey', 'TQ13', 50.59296, -3.71817);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2578, 100, 'Teignmouth', 'TQ14', 50.55002, -3.50626);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2579, 197, 'Torquay', 'TQ2', 50.47398, -3.54331);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2580, 197, 'Torquay', 'TQ3', 50.44298, -3.57469);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2581, 197, 'Torquay', 'TQ4', 50.42326, -3.56982);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2582, 197, '', 'TQ5', 50.39151, -3.52234);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2583, 100, 'Dartmouth', 'TQ6', 50.34655, -3.58837);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2584, 100, 'Kingsbridge', 'TQ7', 50.28256, -3.78278);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2585, 100, 'Salcombe', 'TQ8', 50.23686, -3.77125);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2586, 100, 'Totnes', 'TQ9', 50.41619, -3.68924);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2587, 101, 'Truro', 'TR1', 50.26241, -5.05347);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2588, 101, 'Penryn', 'TR10', 50.16624, -5.11736);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2589, 101, 'Falmouth', 'TR11', 50.14907, -5.08684);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2590, 101, 'St Keverne', 'TR12', 50.0431, -5.17923);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2591, 101, 'Helston', 'TR13', 50.10945, -5.28435);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2592, 101, 'Camborne', 'TR14', 50.20987, -5.29686);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2593, 101, 'Redruth', 'TR15', 50.23225, -5.23669);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2594, 101, 'Redruth', 'TR16', 50.23272, -5.21988);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2595, 101, 'Marazion', 'TR17', 50.12482, -5.46735);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2596, 101, 'Penzance', 'TR18', 50.1163, -5.54089);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2597, 101, 'Sancreed', 'TR19', 50.10012, -5.62783);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2598, 101, 'Tregoney', 'TR2', 50.25334, -4.95186);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2599, 101, 'Ludgvan', 'TR20', 50.13138, -5.48882);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2600, 198, 'Isles of Scilly', 'TR21', 49.92936, -6.25622);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2601, 198, 'Isles of Scilly', 'TR22', 49.89192, -6.34346);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2602, 198, 'Isles of Scilly', 'TR23', 49.95281, -6.35174);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2603, 198, 'Isles of Scilly', 'TR24', 49.95528, -6.33383);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2604, 198, 'Isles of Scilly', 'TR25', 49.96401, -6.29276);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2605, 101, 'St Ives', 'TR26', 50.20276, -5.4786);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2606, 101, 'Hayle', 'TR27', 50.18162, -5.4028);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2607, 101, 'Perranarworthal', 'TR3', 50.21684, -5.10944);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2608, 101, 'Kenwyn', 'TR4', 50.28359, -5.13626);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2609, 101, 'St Agnes', 'TR5', 50.30819, -5.19127);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2610, 101, 'Perranporth', 'TR6', 50.34167, -5.15134);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2611, 101, 'Newquay', 'TR7', 50.41304, -5.073);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2612, 101, 'Colan', 'TR8', 50.39869, -5.03689);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2613, 101, 'St Columb Major', 'TR9', 50.41387, -4.93648);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2614, 199, '', 'TS1', 54.57179, -1.23733);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2615, 200, 'Redcar', 'TS10', 54.60656, -1.06791);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2616, 200, 'Saltburn Marske and New Marske', 'TS11', 54.58734, -1.02501);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2617, 200, 'Skelton', 'TS12', 54.56258, -0.96528);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2618, 200, 'Loftus', 'TS13', 54.54989, -0.85427);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2619, 200, 'Guisborough', 'TS14', 54.53189, -1.06034);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2620, 201, 'Kirklevington', 'TS15', 54.49144, -1.32992);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2621, 201, 'Egglescliffe', 'TS16', 54.52393, -1.35257);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2622, 201, 'Thornaby', 'TS17', 54.53713, -1.30289);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2623, 201, '', 'TS18', 54.56241, -1.32257);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2624, 201, '', 'TS19', 54.57781, -1.34398);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2625, 199, '', 'TS2', 54.58436, -1.23555);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2626, 201, '', 'TS20', 54.58572, -1.3129);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2627, 83, 'Sedgefield', 'TS21', 54.62676, -1.42529);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2628, 201, 'Grindon', 'TS22', 54.61809, -1.3139);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2629, 201, '', 'TS23', 54.60803, -1.28465);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2630, 202, '', 'TS24', 54.69655, -1.21016);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2631, 202, '', 'TS25', 54.66338, -1.22321);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2632, 202, '', 'TS26', 54.68768, -1.22895);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2633, 83, 'Monk Hesleden', 'TS27', 54.72309, -1.28728);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2634, 83, 'Hutton Henry', 'TS28', 54.72536, -1.37265);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2635, 83, 'Trimdon', 'TS29', 54.71032, -1.41945);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2636, 199, '', 'TS3', 54.56073, -1.19578);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2637, 199, '', 'TS4', 54.55551, -1.22217);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2638, 199, '', 'TS5', 54.5512, -1.25008);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2639, 200, 'Redcar', 'TS6', 54.56583, -1.15236);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2640, 199, '', 'TS7', 54.53369, -1.18394);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2641, 199, 'Stainton', 'TS8', 54.52141, -1.23054);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2642, 19, 'Great and Little Broughton', 'TS9', 54.46614, -1.16368);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2643, 29, 'Richmond', 'TW1', 51.44982, -0.3247);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2644, 29, 'Richmond', 'TW10', 51.44949, -0.30168);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2645, 29, 'Richmond', 'TW11', 51.42653, -0.33131);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2646, 29, 'Richmond', 'TW12', 51.42166, -0.36888);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2647, 29, 'Hounslow', 'TW13', 51.43828, -0.39995);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2648, 29, 'Hounslow', 'TW14', 51.45202, -0.41818);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2649, 73, 'Staines', 'TW15', 51.43002, -0.45491);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2650, 73, 'Staines', 'TW16', 51.4151, -0.41514);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2651, 73, 'Staines', 'TW17', 51.39753, -0.44594);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2652, 73, 'Staines', 'TW18', 51.428, -0.50677);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2653, 73, '', 'TW19', 51.45221, -0.50166);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2654, 29, 'Richmond', 'TW2', 51.44657, -0.34929);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2655, 73, 'Egham', 'TW20', 51.42674, -0.54997);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2656, 29, 'Hounslow', 'TW3', 51.46742, -0.36149);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2657, 29, 'Hounslow', 'TW4', 51.46593, -0.38314);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2658, 29, 'Hounslow', 'TW5', 51.48029, -0.3812);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2659, 29, 'Hillingdon', 'TW6', 51.46948, -0.44638);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2660, 29, 'Hounslow', 'TW7', 51.47331, -0.33248);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2661, 29, 'Hounslow', 'TW8', 51.48552, -0.30611);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2662, 29, 'Richmond', 'TW9', 51.46736, -0.29382);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2663, 29, 'Southall', 'UB1', 51.51435, -0.37278);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2664, 29, 'Hillingdon', 'UB10', 51.5478, -0.45236);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2665, 29, 'Hillingdon', 'UB11', 51.51909, -0.45766);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2666, 29, 'Southall', 'UB2', 51.49915, -0.37909);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2667, 29, 'Hillingdon', 'UB3', 51.50513, -0.42211);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2668, 29, 'Hillingdon', 'UB4', 51.52381, -0.40704);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2669, 29, 'Southall', 'UB5', 51.54315, -0.37464);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2670, 29, 'Southall', 'UB6', 51.53911, -0.34306);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2671, 29, 'Hillingdon', 'UB7', 51.50576, -0.46964);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2672, 29, 'Hillingdon', 'UB8', 51.53458, -0.473);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2673, 116, 'Denham Green', 'UB9', 51.58157, -0.49019);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2674, 194, 'Westminster', 'W1', 51.51452, -0.14215);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2675, 29, 'Kensington', 'W10', 51.52103, -0.21397);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2676, 29, 'Kensington', 'W11', 51.51189, -0.20424);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2677, 29, 'Hammersmith', 'W12', 51.50777, -0.2289);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2678, 29, 'Ealing', 'W13', 51.5127, -0.31951);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2679, 29, 'Hammersmith', 'W14', 51.49488, -0.20923);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2680, 194, 'Westminster', 'W1B', 51.51357, -0.13931);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2681, 194, 'Westminster', 'W1C', 51.51371, -0.14795);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2682, 194, 'Westminster', 'W1D', 51.51344, -0.13066);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2683, 194, 'Westminster', 'W1F', 51.51261, -0.13502);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2684, 29, 'Paddington', 'W1G', 51.51818, -0.14633);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2685, 29, 'Paddington', 'W1H', 51.51659, -0.15936);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2686, 194, 'Westminster', 'W1J', 51.50735, -0.14388);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2687, 194, 'Westminster', 'W1K', 51.51104, -0.1495);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2688, 29, 'Paddington', 'W1M', 51.51823, -0.14921);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2689, 194, 'Westminster', 'W1S', 51.5109, -0.14086);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2690, 29, 'Camden Town', 'W1T', 51.5198, -0.13473);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2691, 29, 'Paddington', 'W1U', 51.51827, -0.15209);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2692, 29, 'Paddington', 'W1W', 51.51897, -0.13909);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2693, 29, 'Paddington', 'W2', 51.51508, -0.17816);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2694, 29, 'Ealing', 'W3', 51.50925, -0.26775);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2695, 29, 'Hounslow', 'W4', 51.49118, -0.26268);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2696, 29, 'Ealing', 'W5', 51.51243, -0.30078);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2697, 29, 'Hammersmith', 'W6', 51.49246, -0.22805);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2698, 29, 'Ealing', 'W7', 51.5111, -0.33398);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2699, 29, 'Kensington', 'W8', 51.50003, -0.19317);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2700, 29, 'Paddington', 'W9', 51.52607, -0.1907);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2701, 203, 'Birchwood', 'WA1', 53.39442, -2.5685);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2702, 132, '', 'WA10', 53.45362, -2.75454);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2703, 132, '', 'WA11', 53.47721, -2.71879);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2704, 132, '', 'WA12', 53.45343, -2.63104);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2705, 203, 'Lymm', 'WA13', 53.38226, -2.46911);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2706, 146, '', 'WA14', 53.38624, -2.35788);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2707, 146, '', 'WA15', 53.38364, -2.32478);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2708, 76, 'Knutsford', 'WA16', 53.3026, -2.37068);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2709, 203, 'Birchwood', 'WA2', 53.41054, -2.58075);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2710, 203, 'Croft', 'WA3', 53.45384, -2.54821);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2711, 203, 'Appleton', 'WA4', 53.36472, -2.57412);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2712, 203, 'Great Sankey', 'WA5', 53.39857, -2.63624);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2713, 70, 'Frodsham', 'WA6', 53.27222, -2.72285);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2714, 204, 'Runcorn', 'WA7', 53.32987, -2.7028);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2715, 204, 'Runcorn', 'WA8', 53.37189, -2.74107);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2716, 132, '', 'WA9', 53.43676, -2.71811);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2717, 29, 'Camden Town', 'WC1', 51.52139, -0.12169);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2718, 29, 'Camden Town', 'WC1A', 51.51694, -0.12475);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2719, 29, 'Camden Town', 'WC1B', 51.51876, -0.12612);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2720, 29, 'Camden Town', 'WC1E', 51.52065, -0.13181);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2721, 29, 'Camden Town', 'WC1H', 51.52415, -0.1259);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2722, 29, 'Camden Town', 'WC1N', 51.52136, -0.12025);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2723, 29, 'Camden Town', 'WC1R', 51.5186, -0.11604);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2724, 29, 'Camden Town', 'WC1V', 51.51685, -0.11899);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2725, 29, 'Camden Town', 'WC1X', 51.52489, -0.11578);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2726, 194, 'Westminster', 'WC2', 51.51332, -0.12346);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2727, 29, 'Camden Town', 'WC2A', 51.51588, -0.11471);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2728, 194, 'Westminster', 'WC2B', 51.5151, -0.12195);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2729, 194, 'Westminster', 'WC2E', 51.51242, -0.1235);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2730, 29, 'Camden Town', 'WC2H', 51.51339, -0.12778);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2731, 194, 'Westminster', 'WC2N', 51.50975, -0.12505);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2732, 194, 'Westminster', 'WC2R', 51.51145, -0.11921);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2733, 4, 'Watford', 'WD1', 51.64692, -0.39984);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2734, 4, 'Watford', 'WD17', 51.66138, -0.40512);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2735, 4, 'Watford', 'WD18', 51.64801, -0.41426);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2736, 4, 'Watford Rural', 'WD19', 51.6315, -0.39027);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2737, 4, 'Potters Bar', 'WD2', 51.6673, -0.37743);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2738, 4, 'Potters Bar', 'WD23', 51.64554, -0.3652);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2739, 4, 'Watford', 'WD24', 51.67027, -0.39757);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2740, 4, 'Watford', 'WD25', 51.68363, -0.38842);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2741, 4, 'Chorleywood', 'WD3', 51.6453, -0.48085);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2742, 4, 'Kings Langley', 'WD4', 51.70882, -0.45556);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2743, 4, 'Abbots Langley', 'WD5', 51.7047, -0.41662);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2744, 4, 'Borehamwood', 'WD6', 51.65684, -0.27514);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2745, 4, 'Radlett', 'WD7', 51.68611, -0.30876);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2746, 205, '', 'WF1', 53.68684, -1.49117);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2747, 205, '', 'WF10', 53.72388, -1.3437);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2748, 205, '', 'WF11', 53.71078, -1.25602);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2749, 18, 'Dewsbury', 'WF12', 53.68373, -1.61992);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2750, 18, 'Dewsbury', 'WF13', 53.69279, -1.64559);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2751, 18, 'Mirfield', 'WF14', 53.68034, -1.69263);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2752, 18, 'Dewsbury', 'WF15', 53.70822, -1.69849);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2753, 18, 'Dewsbury', 'WF16', 53.70994, -1.66817);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2754, 18, 'Dewsbury', 'WF17', 53.71885, -1.64082);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2755, 205, '', 'WF2', 53.67254, -1.51102);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2756, 142, '', 'WF3', 53.72294, -1.52408);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2757, 205, 'Crigglestone', 'WF4', 53.64741, -1.51888);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2758, 205, '', 'WF5', 53.67998, -1.57605);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2759, 205, 'Normanton', 'WF6', 53.69997, -1.41375);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2760, 205, 'Featherstone', 'WF7', 53.66639, -1.35065);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2761, 205, '', 'WF8', 53.68497, -1.29887);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2762, 205, 'North Elmsall', 'WF9', 53.60599, -1.31983);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2763, 149, 'Pemberton', 'WN1', 53.55414, -2.6265);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2764, 149, 'Pemberton', 'WN2', 53.53639, -2.58248);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2765, 149, 'Pemberton', 'WN3', 53.52888, -2.64423);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2766, 149, 'Pemberton', 'WN4', 53.49473, -2.64221);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2767, 149, 'Pemberton', 'WN5', 53.53135, -2.68501);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2768, 149, 'Pemberton', 'WN6', 53.57369, -2.66908);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2769, 149, 'Leigh', 'WN7', 53.49803, -2.51712);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2770, 16, 'Ormskirk', 'WN8', 53.55242, -2.76838);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2771, 206, '', 'WR1', 52.19713, -2.21656);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2772, 9, 'Wick', 'WR10', 52.11459, -2.06426);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2773, 9, 'Evesham', 'WR11', 52.09481, -1.92847);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2774, 9, 'Broadway', 'WR12', 52.04261, -1.87314);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2775, 117, 'Colwall', 'WR13', 52.09433, -2.34161);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2776, 9, 'Great Malvern', 'WR14', 52.11328, -2.31839);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2777, 9, 'Tenbury', 'WR15', 52.30476, -2.56764);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2778, 206, '', 'WR2', 52.18989, -2.24139);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2779, 206, '', 'WR3', 52.21603, -2.21079);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2780, 206, '', 'WR4', 52.20438, -2.1844);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2781, 206, '', 'WR5', 52.17738, -2.19891);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2782, 9, 'Martley', 'WR6', 52.22732, -2.37045);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2783, 9, 'North Piddle', 'WR7', 52.19642, -2.05268);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2784, 9, 'Worcester', 'WR8', 52.08207, -2.20287);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2785, 9, 'Droitwich', 'WR9', 52.26826, -2.15682);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2786, 207, '', 'WS1', 52.57945, -1.97786);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2787, 7, 'West Bromwich', 'WS10', 52.56057, -2.02065);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2788, 11, 'Cannock', 'WS11', 52.68914, -2.01776);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2789, 11, 'Cannock', 'WS12', 52.70623, -1.99852);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2790, 11, 'Lichfield', 'WS13', 52.6917, -1.818);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2791, 11, 'Swinfen and Packington', 'WS14', 52.66292, -1.81368);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2792, 11, 'Brereton', 'WS15', 52.75834, -1.91701);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2793, 207, '', 'WS2', 52.58845, -2.00148);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2794, 207, 'Willenhall', 'WS3', 52.61812, -1.98966);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2795, 207, '', 'WS4', 52.60552, -1.95865);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2796, 207, '', 'WS5', 52.56776, -1.95869);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2797, 11, 'Great Wyrley', 'WS6', 52.65767, -2.02218);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2798, 11, 'Burntwood', 'WS7', 52.68012, -1.91272);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2799, 207, 'Brownhills', 'WS8', 52.64597, -1.93348);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2800, 207, 'Aldridge', 'WS9', 52.6091, -1.91729);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2801, 208, '', 'WV1', 52.58569, -2.11514);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2802, 208, 'Wednesfield', 'WV10', 52.61716, -2.11227);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2803, 208, 'Wednesfield', 'WV11', 52.61, -2.07089);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2804, 207, 'Willenhall', 'WV12', 52.60552, -2.03987);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2805, 207, 'Willenhall', 'WV13', 52.58484, -2.06052);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2806, 208, 'Wednesfield', 'WV14', 52.55695, -2.07818);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2807, 92, 'Bridgnorth', 'WV15', 52.51593, -2.37435);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2808, 92, 'Chetton', 'WV16', 52.5112, -2.44062);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2809, 208, '', 'WV2', 52.574, -2.11806);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2810, 208, '', 'WV3', 52.57936, -2.15054);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2811, 208, '', 'WV4', 52.56229, -2.14163);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2812, 11, 'Wombourne', 'WV5', 52.53342, -2.20936);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2813, 208, '', 'WV6', 52.5955, -2.18161);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2814, 92, 'Albrighton', 'WV7', 52.63309, -2.27043);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2815, 11, 'Bilbrook', 'WV8', 52.62337, -2.1832);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2816, 208, '', 'WV9', 52.63332, -2.14039);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2817, 209, '', 'YO1', 53.95857, -1.0809);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2818, 209, 'Heslington', 'YO10', 53.95031, -1.05822);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2819, 19, 'Scarborough', 'YO11', 54.26511, -0.39535);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2820, 19, 'Scarborough', 'YO12', 54.27356, -0.42267);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2821, 19, 'Stainton Dale', 'YO13', 54.28798, -0.49587);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2822, 19, 'Muston', 'YO14', 54.19903, -0.29672);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2823, 88, 'Bridlington', 'YO15', 54.0939, -0.17715);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2824, 88, 'Bridlington', 'YO16', 54.09514, -0.20004);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2825, 19, 'Settrington', 'YO17', 54.13631, -0.75397);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2826, 19, 'Pickering', 'YO18', 54.2587, -0.76717);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2827, 209, 'Wheldrake', 'YO19', 53.91046, -1.02105);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2828, 19, 'Hutton Mulgrave', 'YO21', 54.47654, -0.71123);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2829, 19, 'Snainton', 'YO22', 54.45038, -0.62104);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2830, 209, 'Copmanthorpe', 'YO23', 53.92562, -1.12122);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2831, 209, '', 'YO24', 53.94624, -1.11469);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2832, 88, 'Driffield', 'YO25', 54.00465, -0.41302);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2833, 209, 'Upper Poppleton', 'YO26', 53.97452, -1.17204);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2834, 209, 'Rawcliffe', 'YO30', 53.98579, -1.11385);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2835, 209, '', 'YO31', 53.96923, -1.06389);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2836, 209, 'Earswick', 'YO32', 54.01143, -1.05837);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2837, 88, 'Catton', 'YO41', 53.96966, -0.90227);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2838, 88, 'Barmby Moor', 'YO42', 53.92274, -0.7908);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2839, 88, 'Market Weighton', 'YO43', 53.84976, -0.68952);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2840, 19, 'Boroughbridge', 'YO51', 54.08182, -1.37628);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2841, 19, 'Thornton-le-Clay', 'YO60', 54.08237, -0.94057);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2842, 19, 'Easingwold', 'YO61', 54.11579, -1.1937);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2843, 19, 'Nawton', 'YO62', 54.24282, -0.99325);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2844, 19, 'Sowerby', 'YO7', 54.2237, -1.3496);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2845, 19, 'Selby', 'YO8', 53.7813, -1.05745);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2846, 210, 'Sound', 'ZE1', 60.15232, -1.16779);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2847, 210, '', 'ZE2', 60.33047, -1.22484);");
$wpdb->query("INSERT INTO `{$wpdb->prefix}improveseo_uk_cities` (`id`, `region_id`, `name`, `postcode`, `latitude`, `longitude`) VALUES
	(2848, 210, 'Toab', 'ZE3', 59.88369, -1.30316);"); */